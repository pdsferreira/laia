# Migration from the public beta

This candidate starts from public commit
`4bb0d4a2fefe4d39c34acb84e352848a6d62844b`. It adds no private survey pipeline.
The old code remains recoverable in that Git history; no scientific input data
are removed. Repeated numerical implementations and automatic production driver
loops are replaced by small shared functions and explicit examples.

## Preferred API

Import `compute_maps`, `measurement_from_map`, `generate_mock`,
`spatial_block_bootstrap` and the optional diagnostics from `laia`. FITS I/O lives
in `laia.io`. Installing the checkout with `python -m pip install -e .` makes
these imports available from scripts and notebooks.

Common beta names remain in `estimator.laia_maps`,
`estimator.laia_maps_alt_it`, and `mock_generation.mock_generator` as adapters.
Legacy Portuguese argument/function names are retained only where they preserve
calling compatibility; all new API, comments and documentation are in English.

## Deliberate changes

- Importing a module never reads placeholder maps or starts a large batch.
- File writes require an explicit call. Existing products are not overwritten
  unless `overwrite=True` / `--overwrite` is supplied.
- One validated kernel computes all grids, including optional refinement. The
  nominal chunk defaults are smaller and both dimensions are chunked.
- Invalid vectors/uncertainties raise errors. NaNs do not acquire maximum weight.
- Missing PA errors require an explicit weighting choice. Noiseless toy examples
  use `sigma_pa=None, weights="uniform"`, giving `c_bar=1`.
- `recover_alpha` now delegates to `theta_ia_from_peak`. It no longer silently
  clips an out-of-domain peak. Historical solver-tuning keywords do not configure
  a second solver. Invalid amplitudes can be requested as flagged NaNs through
  the new API. A signal-scaled endpoint tolerance of `32 * float64_epsilon * c_bar`
  handles machine roundoff only and is exposed by `amplitude_roundoff_adjusted`.
  Numerically collapsed raw-map amplitude domains are rejected.
- The 1-degree weight floor and the beta's effective-sigma attenuation convention
  remain the defaults. `attenuation_uses_floor=False` explicitly separates the
  physical PA scatter from weight stabilization; this is not switched implicitly.
- Unevaluated/singular pixels are masked, not stored as an apparent zero signal.
  `Ea+Eb=1` applies only to valid raw fields for the same catalog/weights.
- FITS outputs are standard HEALPix binary tables with masks and ordering/C_BAR
  metadata, not just primary-HDU image arrays. Prefer `read_maps`, `read_field`
  or `healpy.read_map` over assuming `fits.getdata` returns a flat numeric image.
- `read_field` accepts old primary-image files with declared ordering. Supply
  an explicit evaluation mask for zero-padded centered/PSF analyses. The raw
  a/b compatibility adapter recognizes jointly zero padding using both fields;
  a zero in an individual field remains valid.
- `run_estimator_new` now also returns its maps and writes a combined bundle.
- `analyze_with_psf_corrections` follows the centered map-level paper algebra.
  Its default is `de_leak_mode="centered"`; the old arbitrary-baseline mode is
  rejected. Corrected real fields are contrasts and must be inverted with
  `centered=True`. A missing empirical-null mean is not synthesized.
- Extra complex quantities are named `A_complex` in the new API. The beta
  `D_IA`/`A_IA` result keys remain compatibility aliases, never angular theta_IA.
- The public bootstrap defaults to occupied NSIDE8 blocks and 1000 draws, both
  configurable. The FITS adapter analyzes one explicit tracer (`a` by default)
  and saves all draws/flags; use `tracer="b"` for the perpendicular field.
- Bootstrap direction summaries are axial, avoiding RA-wrap and antipodal means.
  Empirical percentiles are not the paper's KDE central-value/significance chain.
- The old bootstrap `lensing=True` flag is retained with a warning: it requests
  a stochastic axial perturbation of user-supplied amplitude, not physical shear.
  The new API names it `extra_rotation_rad`, default zero; random axes are drawn
  continuously and isotropically, so `lensing_nside_dir` is no longer used.
- Automatic per-realization map dumps and the old batch-PSF/aggregate-production
  drivers are not retained. Use the per-map helpers and the returned full
  bootstrap samples explicitly. They are not hidden substitutes for the private
  calibration pipeline.
- The iterative adapter uses modest default resolutions and calls the same
  estimator at each step. Its historical `chi2` name means E, not chi-square.

The former catalog-organizing notebook has been replaced by a short synthetic
schema example. Repeated DES-specific selections and author-machine paths are
not required to use the public estimator.
