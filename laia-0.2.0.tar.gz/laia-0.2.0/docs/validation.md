# Validation record — 0.2.0

Original validation on 2026-11-23, starting from public commit
`4bb0d4a2fefe4d39c34acb84e352848a6d62844b`. The release was prepared locally;
no GitHub push, release or Zenodo deposit was performed.

The original validation is retained below. A separate section records the
metadata and packaging refresh on 2026-11-24; historical private-harness
results are not presented as newly rerun checks.

## Environment

Python 3.12.14 on Linux. The principal package versions were:

| Dependency | Version |
| --- | --- |
| NumPy | 2.3.5 |
| SciPy | 1.17.0 |
| Healpy | 1.20.1 |
| Astropy | 8.0.3 |
| Matplotlib | 3.10.8 |
| Pytest | 9.2.0 |
| Ruff | 0.17.6 |
| build | 1.6.1 |

`requirements-validation.txt` records these optional exact constraints. The
package declares broader minimum requirements, but other Python/dependency
combinations have not been claimed as tested here.

## Completed source checks

- Public source suite: **279 tests passed**.
- Public suite plus seven private masked-input regressions: **286 tests passed**.
  The private verification bundle is not included in this source distribution.
- Ruff check: passed for the package, compatibility modules, examples and tests.
- `git diff --check`: passed.
- Source distribution and wheel build: passed in isolated build environments.
- `CITATION.cff`: validated against Citation File Format schema 1.2.0.
- All five example scripts executed with actual Healpy/Astropy, not substitute
  grids or stubbed dependencies. No external survey inputs were needed.
- The unchanged data-independent notebook's code cells had already executed
  successfully during the candidate review, including vector/FITS checks.
- The quickstart's optional plot and both ensemble plots were generated and
  visually inspected.

The initial development environment inherited an unrelated AnyIO/Pytest-plugin
deprecation warning. It was not a LAIA test failure; independent installation
checks are recorded separately below.

## Independent wheel installation

A second virtual environment was created without inherited system packages. The
0.2.0 wheel and its declared extras were installed there with the recorded
validation constraints. Imports were checked to resolve to the installed
`site-packages`, not the source checkout.

- Installed-wheel public suite plus the private regressions: **286 tests passed**,
  with no warnings, using isolated Python and Pytest's importlib mode from
  outside the checkout. This comprises 279 public tests and seven private checks.
- `pip check`: **no broken requirements found**.
- All 13 Python modules inside the checked wheel were byte-for-byte identical
  to the release's corresponding source modules.

This checks the distributable package as well as an editable source installation.

## Numerical checks covered

The suite tests unit/tangent geometry, PA conventions, headless and antipodal
symmetries, exact injection ties, near-parallel numerical stability, zero
injection, full saturation, analytic amplitude roundtrips, signal-scaled endpoint
roundoff, genuinely out-of-domain amplitudes, uncertainty/weight validation,
masked inputs, reproducible random sampling, masks and zero overdensity, RING and
NESTED ordering, chunk-size invariance, FITS metadata, centered PSF projection,
matched-row block bootstrap, optional stochastic perturbations, complex-field
separation, compatibility adapters and safe imports.

These tests validate implementation and controlled examples. They are not a
rerun of the paper's catalog-specific bias, survey-systematics, null-calibration
or significance analysis, and do not certify a full scientific error budget.

## Reproducible quickstart result

Command:

```bash
python examples/quickstart.py --output example_output --plot
```

With seed 20261123, 10,000 objects, NSIDE8, a 10-degree injection at
RA60/Dec30 degrees and 2-degree Gaussian PA noise:

| Quantity | Value |
| --- | ---: |
| Injected theta_IA | 10 degrees |
| Recovered theta_IA | 10.3714495098 degrees |
| Recovered RA | 61.875 degrees |
| Recovered Dec | 30 degrees |
| Axial separation from injection | 1.6237795166 degrees |
| Peak raw Ea | 0.613710444632 |
| C_bar | 0.997566027568 |
| Maximum valid-pixel absolute error in Ea+Eb=1 | 2.22e-16 |

The injected signal is deliberately illustrative. Finite sampling and grid
resolution explain why recovery is not exact. These are not the paper's numbers.

## Full 64-by-100000 north-pole experiment

The complete default ensemble was executed, not only the reduced unit-test
configuration:

```bash
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python examples/quickstart.py --ensemble --output north_pole_output
```

The 64 independent catalogs use a root seed of 20261123, 100,000 objects each,
a 60-arcmin injection toward `(0,0,1)`, no added PA noise, explicit equal
weights and a northern NSIDE32 search grid. Chunks are 1000 objects by 64
directions. The known axis does not restrict the maximization.

| Quantity | Result |
| --- | ---: |
| Valid recovered amplitudes | 64 / 64 |
| Mean recovered grid-peak theta_IA | 60.1433034159 arcmin |
| Sample standard deviation (ddof=1) | 5.4838801747 arcmin |
| Standard error of the mean | 0.6854850218 arcmin |
| Mean fixed-true-axis theta_IA (separate control) | 59.5002994171 arcmin |
| Sample standard deviation of that control | 5.5537269057 arcmin |
| Mean axial separation from the injected axis | 3.1760079621 degrees |
| Recovered declination range | 81.2198 to 88.5380 degrees |
| Count-map sum in the northern hemisphere | 64 |

The standard deviation is scatter among independent simulated catalogs, not
the uncertainty of their mean. The recovered map peak and the exact-pole
control are different estimators. A searched peak may be biased by selection;
the pole also does not coincide with a HEALPix pixel center.

As an independent control, the mean of E at the pre-specified true axis was
0.5110174448866, compared with the analytic expectation 0.5111099829672.
Using the analytic first and second moments of the saturated-injection model,
the Monte Carlo standard error of that mean is 0.0001396858620. The residual
is -0.6625 of this standard error, within the pre-specified six-standard-error
implementation check. This is not a survey detection significance.

The CSV, JSON, FITS count map and both inspected figures are retained in
`examples/reference_north_pole/`. Every recovered axis is represented by its
complete northern antipode. RA of the injected pole is undefined; no arithmetic
mean RA is used. The Mollweide figure shows a distribution of recovered axes,
not a posterior or a significance map.

An independent review reconstructed three reduced catalogs from the child
seeds and compared the literal weighted estimator and a separate nonlinear
inversion with the stored measurements. Stream-prefix reproducibility, ddof,
axis folding and count-map normalization also passed. A one-catalog NSIDE
16/32/64 comparison showed small amplitude changes; it is not a universal
grid-convergence certification.

The private harness's 12 ordinary checks plus its new ensemble wrapper also
passed with a reduced 4-by-1000 ensemble. The full default data above were
independently checked after saving, including the analytic fixed-axis moment.
Private harness files remain outside the public release.

## Metadata and packaging refresh — 2026-11-24

The README, citation metadata and package URLs now include the author-supplied
software DOI `10.5281/zenodo.24500241`. An optional `README_GITHUB.md` is
provided for archive-only GitHub hosting. No numerical implementation was
changed in that initial refresh. The software license was still pending at
that stage; the subsequent author-confirmed MIT update is recorded below.

A fresh Python 3.12.14 virtual environment, without inherited system packages,
was installed using `requirements-validation.txt` and the package's `plot,dev`
extras. The following public-source checks were rerun successfully:

- Public suite: **279 tests passed**.
- Ruff: **all checks passed**.
- `pip check`: **no broken requirements found**.
- The plotted single-catalog quickstart and FITS-to-measurement examples for
  fields `a` and `b` completed successfully.
- The bootstrap example completed with **128/128 valid amplitude draws**.
  Its coarse-grid directional-spread warning is expected, not a zero-error
  measurement.
- The map-level PSF example and the reduced 4-by-1000 ensemble completed.

The seven private regressions and the private local-validation harness were
not rerun as part of this public-archive refresh and are not included here.
The original full-ensemble reference outputs remain bundled above.

## Author-confirmed MIT update — 2026-11-24

The author selected MIT. The source distribution now contains the full
`LICENSE` text, the package metadata declares `license = "MIT"` and includes
that license file, and `CITATION.cff` and both README files identify MIT.
The earlier pending-license file has been removed.

The full README no longer embeds the recovered-axes Mollweide figure. Its
reference PNG and the code that generates it remain available. Both README
variants retain the introductory cosmic-compass illustration, with a relative
path suitable for GitHub when the corresponding image is uploaded.

No Python implementation changes were made in this update.

## Publication checklist

Confirm the intended software-author list and finalize the GitHub/Zenodo
publication. Select MIT in Zenodo, consistently with the archive. The
author-supplied DOI has been recorded; this packaging step does not itself
publish or verify the archival deposit.
