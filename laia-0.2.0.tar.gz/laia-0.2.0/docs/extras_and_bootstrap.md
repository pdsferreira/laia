# Optional diagnostics, PSF-map projection, and spatial bootstrap

These functions are retained as useful parts of the public implementation.
They do not require the private survey pipeline. Their roles are different:

| Component | Public operation | What it does not establish |
| --- | --- | --- |
| Real LAIA map | Maximize the selected `Ea` or `Eb` and invert its peak to `theta_IA` | A detection significance without an appropriate null calibration |
| Complex-field extra | Maximize the modulus of `(Ea-Eb) + 1j*Eab` | An alternative name for the paper's real-map axis or `theta_IA` |
| PSF-map projection | Remove the component of a centered estimator map correlated with a supplied PSF-template map | Catalogue-level residualisation or a complete survey-systematics correction |
| Spatial block bootstrap | Resample occupied sky blocks and remeasure the estimator | All survey-specific calibration errors, a cosmological null, or an extreme-tail probability |

## Complex-field extra

```python
from laia.estimator import compute_maps
from laia.extras import complex_diagnostic

# a, n, and sigma_pa are matched catalogue arrays; PA errors are radians.
maps = compute_maps(a, n, sigma_pa=sigma_pa, nside=8)
extra = complex_diagnostic(maps)
print(extra["ra_deg"], extra["dec_deg"], extra["A_complex"])
```

`complex_diagnostic` reports the axial direction maximizing the complex
modulus and the **dimensionless** value
`A_complex = abs(complex_peak) / c_bar`. It does not call the nonlinear
`theta_IA` inversion. Its result is kept separate from the paper's selected
real-map measurement. The returned `pixel` is the actual grid peak; the
reported direction uses the package's canonical axial representative and can
therefore be the antipode of that pixel.

The additional `project_complex_psf` function performs centered complex
least squares with the complex conjugate in the inner product. This is also
an extra diagnostic, not the real-template projection used to define the
paper's reported real-map amplitude.

## Estimator-level PSF projection

The real helper `project_psf_map` follows the estimator-map projection
described in the paper: subtract a supplied mean null map if available,
remove grid means over common valid directions, fit
`eta = cov(observed, template) / var(template)`, and subtract the fitted
template component. Input map conventions must be consistent:

- `centered=False`: observed, PSF, and any mean-null map are **raw** estimator
  maps, whose isotropic reference is `1/2`.
- `centered=True`: all supplied maps already have that isotropic reference
  removed.
- Output is always a **centered contrast**, regardless of the input mode.
  Pass `centered=True` to `measurement_from_map`; do not subtract `1/2` again.
- A constant PSF template has no identifiable slope. The helper reports
  `status="constant_template"`, `fit_applied=False`, and `eta=0`; it does not
  divide by an arbitrary variance floor.
- The mask is explicit. Zeros are valid; masked, non-finite, and
  `healpy.UNSEEN` pixels are not.

For existing, matched maps on the same grid and in the same ordering:

```python
from laia.extras import project_psf_map
from laia.estimator import measurement_from_map

corrected = project_psf_map(
    observed_map,
    psf_map,
    null_mean=mean_null_map,  # omit if no such calibration is available
    valid_mask=valid_mask,
)
measurement = measurement_from_map(
    corrected["corrected_map"],
    c_bar,
    nest=True,
    valid_mask=corrected["valid_mask"],
    centered=True,
)
```

This operation alone does **not** reproduce the full paper correction. The
caller must provide appropriate input catalogues, matched PSF orientations,
weights, grid metadata, and any empirical-null calibration. The public helper
does not implement the catalogue-level cross-fit residualisation or generate
the survey-specific empirical nulls. Removing a template can also remove a
chance projection of a real signal; application to a survey needs validation.

The legacy beta's `de_leak_mode="baseline"` and its implicit treatment of
centered residuals are not interchangeable with the explicit centered
projection. The compatibility interface reports unsupported legacy choices
instead of silently changing the map's reference level.

## Spatial block bootstrap

The public bootstrap uses the occupied-pixel resampling construction in the
paper. By default the blocks are equal-area HEALPix pixels at `NSIDE=8`.
Each realization draws the original number of occupied blocks uniformly with
replacement, including **all** members of every drawn block. A repeatedly
selected block contributes its full object list repeatedly. Thus object
counts can vary between realizations. PA uncertainties, explicit weights,
and any matched PSF entries always follow the same selected rows, and weights
are renormalized in each realization.

Objects with explicitly zero weight are excluded before defining the occupied
blocks; the excluded count is recorded. At least two occupied blocks are
required. This method retains within-block correlations but does not retain
all cross-block correlations. Block size and resolution are scientific
choices to check, not universally calibrated defaults.

The following small, self-contained example uses a deliberately strong toy
signal, **not the measured amplitude of the paper**:

```python
import numpy as np
from laia.mock import generate_mock
from laia.bootstrap import spatial_block_bootstrap

mock = generate_mock(
    2000,
    direction=np.array([1.0, 1.0, 1.0]) / np.sqrt(3.0),
    theta_ia_rad=np.deg2rad(10.0),
    sigma_pa_rad=np.deg2rad(2.0),
    seed=314,
)
result = spatial_block_bootstrap(
    mock["a"], mock["n"], sigma_pa=mock["sigma_pa"],
    tracer="a", n_resamples=32, nside_blocks=4, nside=4,
    seed=2718, include_complex=True,
)
print(result["summary"]["theta_ia_arcmin"])
print(result["summary"]["axial_separation_deg"])
```

Thirty-two realizations keep this example short. The function's configurable
default is 1000, and a scientific application should check that its reported
quantiles are stable with the number and size of the blocks and the number
of resamples. The original sample is measured separately and returned as
`result["reference"]`; every bootstrap draw is retained in `result["samples"]`.

### Reading the uncertainty outputs

- `summary["theta_ia_arcmin"]` contains empirical 15.865th, 50th, and 84.135th
  percentiles. `theta_minus_arcmin` and `theta_plus_arcmin` are distances from
  that empirical median to the bounds. This is **not** the paper's additional
  KDE-based central-value convention for full-sample amplitude comparisons.
- Axial spread is the angle `acos(abs(dot(axis, reference_axis)))`, evaluated
  through its numerically stable equivalent `atan2` expression, never a linear
  average of RA or of antipodal vectors. The separation quantiles are ordered
  by `summary["axial_separation_percentiles"]`: 15.865, 50, 68.27, 84.135, 95.
  They describe spread around the full-sample axis; they are not automatically
  calibrated frequentist confidence cones.
- A coarse direction grid can place many or all bootstrap maxima at the same
  pixel. A zero separation quantile then does **not** imply zero angular
  uncertainty. `direction_spread_grid_limited` flags an effectively zero
  68.27th-percentile separation, and a warning recommends increasing grid
  resolution or refining each realization. `n_unique_axes` counts distinct
  canonical axes (rounded to 12 Cartesian decimals); `n_unique_grid_pixels`
  and `most_common_grid_pixel_fraction` describe the selected pixels. Antipodal
  pixels can represent the same axis, so the two counts need not agree.
- `samples["axis"]` retains all Cartesian axes for an axial-aware analysis of
  broad or multimodal distributions. `axial_dyad_eigenvalues` provides a
  sign-invariant concentration diagnostic, not a detection significance.
- A genuine out-of-domain amplitude inversion is a flagged NaN. Only endpoint
  roundoff within `32 * float64_epsilon * c_bar` may be rounded to the boundary;
  full-sample measurements expose `amplitude_roundoff_adjusted`. It is not clipped
  to zero or saturation. The sample row and axis are retained, valid/invalid
  counts are reported, and a warning is issued before finite-amplitude
  percentiles are used. Investigate such draws before quoting intervals.

### Optional corrections and perturbations

With `psf_a`, matched PSF vectors are resampled together with the observations
and the real-map leakage coefficient is refitted in each draw. A provided
`null_mean` is a **raw mean-null map of the selected real tracer**, held fixed
across draws. The resulting uncertainty is conditional on that fixed map;
the routine does not propagate finite-null calibration uncertainty or refit
catalogue-level residualisation.

If `include_complex=True` and `psf_a` is supplied, the separate complex
diagnostic is complex-template-projected too. The selected real-tracer
`null_mean` does not define a complex null field and is **not** subtracted
from that extra diagnostic; metadata records this distinction.

`extra_rotation_rad` optionally applies the shared saturated axial injection
towards a new isotropic axis in each bootstrap draw, affecting observed
orientations only. Default is zero. This preserves the type of stochastic
rotation used in the paper to propagate a separately calibrated
lensing--footprint contribution, without supplying or assuming that survey
calibration. For example, `np.deg2rad(1.0 / 60.0)` requests a one-arcminute
perturbation explicitly. It is **not** a physical weak-shear simulator.
The same seeded random generator drives all draws, and
`samples["extra_rotation_axis"]` records the perturbation axes. The full-sample
reference remains unperturbed.

The bootstrap does not provide the paper's empirical-null significance,
direction-bias calibration, morphology correction, or full systematic-error
budget. These require the appropriate survey-specific analysis.
