# Archival release checklist

This is a locally prepared software release. The author-supplied software DOI
is `10.5281/zenodo.24500241`; the packaging step does not publish the Zenodo
record or update GitHub. The author has confirmed the MIT software license.

## Scientific and technical review

- Review the public scope and distinguish real theta_IA, complex extras and errors.
- Run the tests and all examples in the intended installation environment.
- Confirm the floor/attenuation convention for scientific catalogs.
- For actual data, check direction-grid and spatial-block convergence; numerical
  toy tests are not survey-specific systematics validation.
- Review `docs/migration.md` for deliberate beta behavior changes.

## Author decisions before publication

- Verify that the Zenodo license selection is MIT, matching `LICENSE`,
  `pyproject.toml` and `CITATION.cff`.
- Confirm software authors/contributors. `CITATION.cff` currently identifies the
  repository owner as software author and separately lists the paper authors in
  the preferred scientific citation. These are not assumed to be identical lists.
- The package version is `0.2.0`. Keep this version consistent across the source
  archive and the Zenodo record.
- Review the changes locally before manual upload or the normal Git workflow.
  For archive-only GitHub hosting, use `README_GITHUB.md` as the repository's
  `README.md`, but retain the full `README.md` inside the source archive.
  Upload `LICENSE`, `CITATION.cff`, `laia-0.2.0.tar.gz` and the remaining
  illustration at `figures_readme/galaxies_compass_v2.jpg` alongside that README.
  Files inside a compressed archive do not satisfy README image paths.
- Finalize the archive record using the intended license and author list.
- Verify the existing DOI in the README, `CITATION.cff` and package URLs against
  the intended Zenodo record. Do not substitute the article DOI.
- Update the data-availability statement or referee response only after the
  archival deposit and its link actually exist.

The package does not require releasing the private DES/SDSS analysis pipeline.
