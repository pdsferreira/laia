"""Regression checks for the deliberately minimal synthetic-catalog API."""

import importlib

import healpy as hp
import numpy as np
import pytest

from laia.geometry import axial_separation
from laia.mock import (
    add_pa_noise,
    generate_mock,
    inject_alignment,
    sample_positions,
    uniform_catalog,
)


def test_uniform_positions_are_units_and_reproducible():
    first = sample_positions(12000, seed=1)
    second = sample_positions(12000, seed=1)
    np.testing.assert_array_equal(first, second)
    np.testing.assert_allclose(np.linalg.norm(first, axis=1), 1, atol=3e-15)
    np.testing.assert_allclose(first.mean(axis=0), 0, atol=0.02)
    np.testing.assert_allclose((first * first).mean(axis=0), 1 / 3, atol=0.02)


@pytest.mark.parametrize("count", [0, -1, 2.5, True])
def test_count_must_be_positive_integer(count):
    with pytest.raises(ValueError):
        sample_positions(count, seed=1)


def test_no_global_random_state_is_used():
    np.random.seed(812)
    expected = np.random.uniform(size=4)
    np.random.seed(812)
    generate_mock(100, direction=[1, 0, 0], theta_ia_rad=0.2, sigma_pa_rad=0.1, seed=3)
    np.testing.assert_array_equal(np.random.uniform(size=4), expected)


def test_rng_and_seed_cannot_be_combined():
    with pytest.raises(ValueError, match="either rng or seed"):
        sample_positions(3, seed=2, rng=np.random.default_rng(1))
    with pytest.raises(TypeError, match="Generator"):
        sample_positions(3, rng=np.random.RandomState(1))


def test_uniform_catalog_axes_are_tangent_and_unit():
    catalog = uniform_catalog(12000, seed=2)
    np.testing.assert_allclose(np.linalg.norm(catalog["a"], axis=1), 1, atol=5e-15)
    np.testing.assert_allclose(np.sum(catalog["a"] * catalog["n"], axis=1), 0, atol=5e-15)
    direction = np.array([1.0, 0.0, 0.0])
    fixed_axis_values = (catalog["a"] @ direction) ** 2 / (1 - (catalog["n"] @ direction) ** 2)
    assert abs(fixed_axis_values.mean() - 0.5) < 0.012


def test_zero_overdensity_and_small_catalog_are_valid():
    nside = 4
    mask = np.ones(hp.nside2npix(nside))
    positions = sample_positions(3, mask=mask, overdensity=np.zeros(mask.size), seed=5)
    assert positions.shape == (3, 3)
    assert np.all(np.isfinite(positions))


@pytest.mark.parametrize("nest", [False, True])
def test_masked_children_stay_inside_selected_pixels(nest):
    nside = 2
    mask = np.zeros(hp.nside2npix(nside))
    # The last parent catches the historical child-index upper-bound error.
    parents = [3, len(mask) - 1]
    mask[parents] = [1, 0.5]
    result = sample_positions(10000, mask=mask, nest=nest, subpixel_factor=2, seed=2)
    actual = hp.vec2pix(nside, *result.T, nest=nest)
    assert set(actual).issubset(set(parents))
    # Fractional mask amplitudes select support; they are not count weights.
    assert abs(np.mean(actual == parents[0]) - 0.5) < 0.025


def test_factor_one_does_not_select_next_parent():
    mask = np.zeros(12)
    mask[-1] = 1
    positions = sample_positions(1000, mask=mask, subpixel_factor=1, seed=2)
    np.testing.assert_array_equal(hp.vec2pix(1, *positions.T, nest=True), np.full(1000, 11))


def test_overdensity_is_not_direct_density():
    mask = np.zeros(12)
    mask[[0, 1]] = 1
    delta = np.zeros(12)
    delta[1] = 2
    result = sample_positions(12000, mask=mask, overdensity=delta, seed=8)
    pixels = hp.vec2pix(1, *result.T, nest=True)
    assert abs(np.mean(pixels == 1) - 0.75) < 0.025


def test_negative_one_overdensity_has_zero_probability():
    delta = np.full(12, -1.0)
    delta[5] = 0.0
    result = sample_positions(100, overdensity=delta, seed=1)
    np.testing.assert_array_equal(hp.vec2pix(1, *result.T, nest=True), np.full(100, 5))


def test_mask_sentinels_are_excluded_and_outside_density_is_ignored():
    mask = np.zeros(12)
    mask[0], mask[1], mask[2] = np.nan, hp.UNSEEN, 1
    delta = np.full(12, np.nan)
    delta[2] = 0
    result = sample_positions(8, mask=mask, overdensity=delta, seed=8)
    np.testing.assert_array_equal(hp.vec2pix(1, *result.T, nest=True), np.full(8, 2))


@pytest.mark.parametrize(
    "kwargs",
    [
        {"mask": np.ones(11)},
        {"mask": np.ones((3, 4))},
        {"mask": np.zeros(12)},
        {"mask": -np.ones(12)},
        {"mask": np.ones(12), "overdensity": np.ones(48)},
        {"overdensity": np.full(12, -1.0)},
        {"overdensity": np.full(12, -2.0)},
        {"overdensity": np.full(12, np.nan)},
        {"overdensity": np.full(12, hp.UNSEEN)},
        {"mask": np.ones(12), "nside": 2},
        {"subpixel_factor": 3},
        {"subpixel_factor": 0},
        {"nside": 3},
        {"mask": np.ones(12), "subpixel_factor": 2**30},
    ],
)
def test_invalid_sampling_inputs_fail_explicitly(kwargs):
    with pytest.raises(ValueError):
        sample_positions(2, seed=1, **kwargs)


def test_injection_saturates_and_preserves_geometry():
    catalog = uniform_catalog(10000, seed=11)
    a, n = catalog["a"], catalog["n"]
    d = np.array([1, 2, 3], dtype=float)
    d /= np.linalg.norm(d)
    target = d - (n @ d)[:, None] * n
    target /= np.linalg.norm(target, axis=1, keepdims=True)
    before = axial_separation(a, target, degrees=False)
    rotated = inject_alignment(a, n, d, 0.12)
    after = axial_separation(rotated, target, degrees=False)
    np.testing.assert_allclose(after, np.maximum(before - 0.12, 0), atol=1e-12)
    np.testing.assert_allclose(np.linalg.norm(rotated, axis=1), 1, atol=5e-15)
    np.testing.assert_allclose(np.sum(rotated * n, axis=1), 0, atol=1e-12)


def test_zero_injection_is_identity_and_inputs_are_not_mutated():
    catalog = uniform_catalog(20, seed=12)
    a, n = catalog["a"].copy(), catalog["n"].copy()
    result = inject_alignment(a, n, [1, 0, 0], 0)
    np.testing.assert_allclose(result, a, atol=1e-14)
    np.testing.assert_array_equal(a, catalog["a"])
    np.testing.assert_array_equal(n, catalog["n"])


def test_integer_input_rotation_and_nonunit_target_are_correct():
    a, n = [[1, 0, 0]], [[0, 0, 1]]
    d = np.array([0.5, np.sqrt(3) / 2, 0])
    rotated = inject_alignment(a, n, 10 * d, np.pi / 3)
    np.testing.assert_allclose(rotated[0], d, atol=1e-14)
    assert rotated.dtype.kind == "f"


def test_target_antipode_and_input_axis_signs_do_not_change_physics():
    catalog = uniform_catalog(1000, seed=4)
    a, n = catalog["a"], catalog["n"]
    d = [2, 3, 4]
    original = inject_alignment(a, n, d, 0.3)
    antipode = inject_alignment(a, n, -np.asarray(d), 0.3)
    negative_axes = inject_alignment(-a, n, d, 0.3)
    np.testing.assert_allclose(original, antipode, atol=1e-14)
    np.testing.assert_allclose(original, -negative_axes, atol=1e-14)


def test_exact_orthogonal_tie_has_deterministic_axial_sign_policy():
    a, n, d = np.array([[1, 0, 0]]), np.array([[0, 0, 1]]), np.array([0, 1, 0])
    first = inject_alignment(a, n, d, np.pi / 4)
    np.testing.assert_allclose(first, [[np.sqrt(0.5), np.sqrt(0.5), 0]], atol=1e-14)
    np.testing.assert_allclose(inject_alignment(a, n, -d, np.pi / 4), first, atol=1e-14)
    np.testing.assert_allclose(inject_alignment(-a, n, d, np.pi / 4), -first, atol=1e-14)


def test_undefined_target_projection_leaves_axis_unchanged():
    a, n = np.array([[1, 0, 0]]), np.array([[0, 0, 1]])
    np.testing.assert_allclose(inject_alignment(a, n, [0, 0, 1], 0.5), a)


@pytest.mark.parametrize("theta", [-0.1, np.pi, np.nan, np.inf, [0.1]])
def test_invalid_injection_amplitudes_are_rejected(theta):
    with pytest.raises(ValueError):
        inject_alignment([[1, 0, 0]], [[0, 0, 1]], [0, 1, 0], theta)


@pytest.mark.parametrize("direction", [[0, 0, 0], [np.nan, 1, 0], [1, 0], [[1, 0, 0]]])
def test_invalid_injection_targets_are_rejected(direction):
    with pytest.raises(ValueError):
        inject_alignment([[1, 0, 0]], [[0, 0, 1]], direction, 0.2)


def test_nonunit_and_nontangent_inputs_are_rejected():
    with pytest.raises(ValueError):
        inject_alignment([[2, 0, 0]], [[0, 0, 1]], [0, 1, 0], 0.2)
    with pytest.raises(ValueError):
        inject_alignment([[0, 0, 1]], [[0, 0, 1]], [0, 1, 0], 0.2)


def test_pa_noise_has_requested_scatter_and_preserves_tangency():
    catalog = uniform_catalog(15000, seed=2)
    sigma = np.deg2rad(5)
    noisy = add_pa_noise(catalog["a"], catalog["n"], sigma, seed=11)
    sine = np.sum(catalog["n"] * np.cross(catalog["a"], noisy), axis=1)
    cosine = np.sum(catalog["a"] * noisy, axis=1)
    angle = np.arctan2(sine, cosine)
    assert abs(angle.mean()) < 0.002
    assert abs(angle.std() - sigma) < 0.002
    np.testing.assert_allclose(np.sum(noisy * catalog["n"], axis=1), 0, atol=1e-14)


@pytest.mark.parametrize("sigma", [-1, np.nan, np.inf, [0.1, 0.2]])
def test_invalid_noise_values_are_rejected(sigma):
    with pytest.raises(ValueError):
        add_pa_noise([[1, 0, 0]], [[0, 0, 1]], sigma, seed=1)


def test_all_mock_stages_reproduce_and_sigma_metadata_is_retained():
    kwargs = dict(direction=[1, 2, 3], theta_ia_rad=0.15, sigma_pa_rad=0.04, seed=98)
    first, second = generate_mock(300, **kwargs), generate_mock(300, **kwargs)
    for key in ("a", "n", "sigma_pa"):
        np.testing.assert_array_equal(first[key], second[key])
    np.testing.assert_array_equal(first["sigma_pa"], np.full(300, 0.04))
    assert first["metadata"]["seed"] == 98
    assert first["metadata"]["has_pa_noise"]


def test_noiseless_mock_does_not_invent_pa_uncertainty():
    mock = generate_mock(20, direction=[1, 2, 3], theta_ia_rad=0.1, seed=1)
    assert mock["sigma_pa"] is None
    assert not mock["metadata"]["has_pa_noise"]


def test_seeded_mock_recovers_injected_signal_with_actual_healpix():
    from laia.estimator import compute_maps, measurement_from_map

    direction = np.array([0.75, np.sqrt(3) / 4, 0.5])
    mock = generate_mock(
        10000,
        direction=direction,
        theta_ia_rad=np.deg2rad(10),
        sigma_pa_rad=np.deg2rad(2),
        seed=20261123,
    )
    maps = compute_maps(mock["a"], mock["n"], sigma_pa=mock["sigma_pa"], nside=8)
    measurement = measurement_from_map(
        maps["Ea"], maps["c_bar"], nest=maps["nest"], valid_mask=maps["valid_mask"]
    )
    assert abs(np.rad2deg(measurement["theta_ia_rad"]) - 10) < 1.5
    assert axial_separation(measurement["axis"], direction) < 10


def test_legacy_module_import_has_no_io(monkeypatch, tmp_path):
    def unexpected_io(*args, **kwargs):
        pytest.fail("Importing mock_generator attempted map I/O.")

    monkeypatch.setattr(hp, "read_map", unexpected_io)
    monkeypatch.chdir(tmp_path)
    module = importlib.import_module("mock_generation.mock_generator")
    importlib.reload(module)
    assert list(tmp_path.iterdir()) == []


def test_legacy_wrappers_delegate_and_accept_default_full_sky():
    from mock_generation.mock_generator import (
        astrometry_sim,
        direcoes_g,
        rotate_tangent_vectors_no_error,
    )

    positions = astrometry_sim(10, seed=2)
    assert positions.shape == (10, 3)
    first_n, first_a = direcoes_g(10, seed=3)
    second_n, second_a = direcoes_g(10, seed=3)
    np.testing.assert_array_equal(first_n, second_n)
    np.testing.assert_array_equal(first_a, second_a)
    np.testing.assert_allclose(
        rotate_tangent_vectors_no_error(first_a, first_n, [1, 2, 3], 0.2),
        inject_alignment(first_a, first_n, [1, 2, 3], 0.2),
    )


def test_cli_without_output_creates_no_files(tmp_path, monkeypatch, capsys):
    from mock_generation.mock_generator import main

    monkeypatch.chdir(tmp_path)
    assert main(["--n-objects", "20", "--seed", "3"]) == 0
    assert "No output requested" in capsys.readouterr().out
    assert list(tmp_path.iterdir()) == []


def test_cli_fits_output_retains_sigma_and_protects_existing_file(tmp_path):
    from laia.io import read_catalog
    from mock_generation.mock_generator import main

    destination = tmp_path / "toy.fits"
    arguments = ["--n-objects", "20", "--seed", "3", "--output", str(destination)]
    assert main(arguments) == 0
    result = read_catalog(destination)
    assert result["a"].shape == (20, 3)
    np.testing.assert_allclose(result["sigma_pa"], np.deg2rad(2))
    with pytest.raises(FileExistsError):
        main(arguments)
    assert main(arguments + ["--overwrite"]) == 0


def test_legacy_noisy_rotation_reuses_shared_injection_and_noise():
    from mock_generation.mock_generator import rotate_tangent_vectors

    catalog = uniform_catalog(50, seed=2)
    sigma = 0.05
    first = rotate_tangent_vectors(
        catalog["a"],
        catalog["n"],
        [1, 2, 3],
        0.2,
        np.full(12, sigma),
        rng=np.random.default_rng(9),
    )
    aligned = inject_alignment(catalog["a"], catalog["n"], [1, 2, 3], 0.2)
    expected = add_pa_noise(aligned, catalog["n"], sigma, seed=9)
    np.testing.assert_allclose(first, expected, atol=1e-14)


@pytest.mark.parametrize("which_map", ["mask", "overdensity", "both"])
def test_explicit_masked_map_entries_are_never_sampled(which_map):
    mask = np.ones(12)
    delta = np.zeros(12)
    missing = np.zeros(12, dtype=bool)
    missing[0] = True
    if which_map in ("mask", "both"):
        mask = np.ma.array(mask, mask=missing)
    if which_map in ("overdensity", "both"):
        delta = np.ma.array(delta, mask=missing)
    positions = sample_positions(10000, mask=mask, overdensity=delta, nside=1, seed=3)
    pixels = hp.vec2pix(1, *positions.T, nest=True)
    assert np.count_nonzero(pixels == 0) == 0
    assert set(pixels) == set(range(1, 12))


def test_masked_overdensity_alone_defines_excluded_support():
    delta = np.ma.array(np.zeros(12), mask=[True] + [False] * 11)
    positions = sample_positions(1000, overdensity=delta, seed=3)
    assert not np.any(hp.vec2pix(1, *positions.T, nest=True) == 0)


@pytest.mark.parametrize("separation", [1e-9, 1e-11])
def test_nearly_parallel_target_projection_remains_tangent(separation):
    from laia.estimator import compute_maps
    from laia.geometry import canonical_axis, validate_vectors

    direction = canonical_axis([0.3, 0.4, 0.5])
    tangent = np.cross(direction, [0, 0, 1])
    tangent /= np.linalg.norm(tangent)
    sightline = direction * np.cos(separation) + tangent * np.sin(separation)
    sightline /= np.linalg.norm(sightline)
    initial = np.cross(sightline, [0, 0, 1])
    initial /= np.linalg.norm(initial)
    rotated = inject_alignment(initial[None, :], sightline[None, :], direction, np.pi / 2)
    assert abs(float(rotated[0] @ sightline)) < 1e-14
    validate_vectors(rotated, sightline[None, :])
    maps = compute_maps(rotated, sightline[None, :], weights="uniform", nside=2)
    assert np.all(np.isfinite(maps["Ea"][maps["valid_mask"]]))
    np.testing.assert_allclose(
        maps["Ea"][maps["valid_mask"]] + maps["Eb"][maps["valid_mask"]],
        1,
        atol=1e-12,
    )


@pytest.mark.parametrize("sigma", [np.ma.array(0.1, mask=True), np.ma.array([0.1], mask=[True])])
def test_masked_pa_noise_is_not_silently_unmasked(sigma):
    with pytest.raises(ValueError, match="masked"):
        add_pa_noise([[1, 0, 0]], [[0, 0, 1]], sigma, seed=1)
    with pytest.raises(ValueError, match="masked"):
        generate_mock(1, direction=[1, 0, 0], theta_ia_rad=0.1, sigma_pa_rad=sigma, seed=1)


def test_masked_target_and_amplitude_are_rejected():
    with pytest.raises(ValueError, match="[Mm]asked"):
        inject_alignment(
            [[1, 0, 0]],
            [[0, 0, 1]],
            np.ma.array([0, 1, 0], mask=[False, True, False]),
            0.1,
        )
    with pytest.raises(ValueError, match="masked"):
        inject_alignment([[1, 0, 0]], [[0, 0, 1]], [0, 1, 0], np.ma.array(0.1, mask=True))


def test_legacy_noise_map_preserves_sampled_pixel_mask():
    from mock_generation.mock_generator import rotate_tangent_vectors

    sightline = np.asarray(hp.pix2vec(1, 0, nest=True))
    axis = np.cross(sightline, [0, 0, 1])
    axis /= np.linalg.norm(axis)
    errors = np.ma.array(np.full(12, 0.05), mask=[True] + [False] * 11)
    with pytest.raises(ValueError, match="masked"):
        rotate_tangent_vectors(
            axis[None, :],
            sightline[None, :],
            [1, 0, 0],
            0.1,
            errors,
            rng=np.random.default_rng(2),
        )
