"""Small ensemble checks; the public 64 x 100k run is an explicit example."""

import csv
import inspect
import json
import subprocess
import sys
from pathlib import Path

import healpy as hp
import numpy as np
import pytest
from astropy.io import fits

import laia.ensemble as ensemble
from laia import compute_maps, generate_mock, measurement_from_map


@pytest.fixture
def small_result():
    return ensemble.run_north_pole_ensemble(
        n_simulations=4, n_objects=300, theta_ia_arcmin=1200, nside=2, seed=45
    )


def test_requested_public_defaults():
    defaults = inspect.signature(ensemble.run_north_pole_ensemble).parameters
    for name, expected in {
        "n_simulations": 64,
        "n_objects": 100_000,
        "theta_ia_arcmin": 60.0,
        "nside": 32,
        "sigma_pa_deg": 0.0,
        "gal_chunk": 1000,
        "direction_chunk": 64,
    }.items():
        assert defaults[name].default == expected


def test_scatter_mean_sem_and_fixed_direction_are_separate(small_result):
    samples, summary = small_result["samples"], small_result["summary"]
    theta = samples["theta_ia_arcmin"]
    assert summary["n_amplitude_valid"] == 4
    assert summary["std_ddof"] == 1
    assert summary["theta_ia_mean_arcmin"] == pytest.approx(np.mean(theta))
    assert summary["theta_ia_std_arcmin"] == pytest.approx(np.std(theta, ddof=1))
    assert summary["theta_ia_sem_arcmin"] == pytest.approx(np.std(theta, ddof=1) / 2)
    fixed = samples["theta_ia_at_injected_axis_arcmin"]
    fixed_stats = summary["fixed_axis_control"]["theta_ia_arcmin"]
    assert fixed_stats["mean"] == pytest.approx(np.mean(fixed))
    assert fixed_stats["std"] == pytest.approx(np.std(fixed, ddof=1))
    assert fixed_stats["std_ddof"] == 1
    assert small_result["metadata"]["injected_ra_deg"] is None
    assert small_result["metadata"]["injected_dec_deg"] == 90
    assert "ra_mean" not in summary
    assert "ra_std" not in summary


def test_streams_are_independent_reproducible_and_reconstructible(small_result):
    same = ensemble.run_north_pole_ensemble(
        n_simulations=4, n_objects=300, theta_ia_arcmin=1200, nside=2, seed=45
    )
    prefix = ensemble.run_north_pole_ensemble(
        n_simulations=2, n_objects=300, theta_ia_arcmin=1200, nside=2, seed=45
    )
    other = ensemble.run_north_pole_ensemble(
        n_simulations=4, n_objects=300, theta_ia_arcmin=1200, nside=2, seed=46
    )
    for key in small_result["samples"]:
        np.testing.assert_array_equal(small_result["samples"][key], same["samples"][key])
        np.testing.assert_array_equal(small_result["samples"][key][:2], prefix["samples"][key])
    assert not np.array_equal(other["samples"]["E_peak"], same["samples"]["E_peak"])
    assert np.unique(same["samples"]["E_peak"]).size > 1
    np.testing.assert_array_equal(same["samples"]["seed_spawn_index"], np.arange(4))
    child = np.random.SeedSequence(45, spawn_key=(2,))
    mock = generate_mock(
        300, direction=[0, 0, 1], theta_ia_rad=np.deg2rad(20), rng=np.random.default_rng(child)
    )
    maps = compute_maps(mock["a"], mock["n"], weights="uniform", nside=2)
    expected = measurement_from_map(maps["Ea"], maps["c_bar"], valid_mask=maps["valid_mask"])
    assert same["samples"]["theta_ia_arcmin"][2] == pytest.approx(expected["theta_ia_arcmin"])


def test_northern_fold_and_count_map(small_result):
    samples = small_result["samples"]
    axes = np.column_stack([samples[key] for key in ("axis_x", "axis_y", "axis_z")])
    assert np.all(axes[:, 2] >= 0)
    assert np.all(samples["dec_deg"] >= 0)
    assert np.all(samples["ra_deg"] >= 0) and np.all(samples["ra_deg"] < 360)
    np.testing.assert_allclose(np.linalg.norm(axes, axis=1), 1, atol=1e-14)
    counts = small_result["direction_counts"]
    assert counts.sum() == 4
    assert np.all(counts[~small_result["north_support"]] == 0)
    expected = np.bincount(hp.vec2pix(2, *axes.T, nest=True), minlength=48)
    np.testing.assert_array_equal(counts, expected)
    np.testing.assert_allclose(samples["axial_separation_deg"], 90 - samples["dec_deg"], atol=1e-12)


def test_southern_measurement_representation_flips_whole_vector(monkeypatch, small_result):
    original = ensemble.measurement_from_map

    def southern(*args, **kwargs):
        measured = original(*args, **kwargs)
        measured["axis"] = -measured["axis"]
        return measured

    monkeypatch.setattr(ensemble, "measurement_from_map", southern)
    flipped = ensemble.run_north_pole_ensemble(
        n_simulations=4, n_objects=300, theta_ia_arcmin=1200, nside=2, seed=45
    )
    for key in ("axis_x", "axis_y", "axis_z", "ra_deg", "dec_deg"):
        np.testing.assert_array_equal(flipped["samples"][key], small_result["samples"][key])


def test_progress_is_complete_and_cannot_mutate_saved_rows():
    calls = []

    def progress(completed, total, row):
        calls.append((completed, total))
        row["theta_ia_arcmin"] = -999

    result = ensemble.run_north_pole_ensemble(
        n_simulations=4, n_objects=100, theta_ia_arcmin=600, nside=1, seed=5, progress=progress
    )
    assert calls == [(1, 4), (2, 4), (3, 4), (4, 4)]
    assert np.all(result["samples"]["theta_ia_arcmin"] != -999)


def test_noiseless_and_optional_physical_noise_conventions(small_result):
    assert small_result["metadata"]["weighting"] == "uniform"
    assert small_result["metadata"]["attenuation_convention"] == "noiseless"
    np.testing.assert_allclose(small_result["samples"]["c_bar"], 1)
    noisy = ensemble.run_north_pole_ensemble(
        n_simulations=2,
        n_objects=200,
        theta_ia_arcmin=1200,
        nside=1,
        sigma_pa_deg=0.3,
        seed=7,
    )
    assert noisy["metadata"]["attenuation_convention"] == "input_sigma"
    np.testing.assert_allclose(noisy["samples"]["c_bar"], np.exp(-2 * np.deg2rad(0.3) ** 2))


def test_global_rng_is_not_modified():
    before = np.random.get_state()
    ensemble.run_north_pole_ensemble(n_simulations=2, n_objects=20, nside=1, seed=1)
    after = np.random.get_state()
    assert before[0] == after[0]
    np.testing.assert_array_equal(before[1], after[1])
    assert before[2:] == after[2:]


@pytest.mark.parametrize(
    "kwargs",
    [
        {"n_simulations": 1},
        {"n_simulations": True},
        {"n_objects": 0},
        {"n_objects": 2.5},
        {"nside": 3},
        {"nside": False},
        {"theta_ia_arcmin": -1},
        {"theta_ia_arcmin": 5401},
        {"sigma_pa_deg": -1},
        {"sigma_pa_deg": np.nan},
        {"seed": -1},
        {"seed": 1.2},
        {"seed": True},
        {"gal_chunk": 0},
        {"direction_chunk": 0},
    ],
)
def test_invalid_configuration_is_rejected_before_computation(kwargs):
    with pytest.raises(ValueError):
        ensemble.run_north_pole_ensemble(**kwargs)


def test_invalid_progress_is_rejected():
    with pytest.raises(TypeError, match="progress"):
        ensemble.run_north_pole_ensemble(progress=1)


def test_written_rows_json_count_map_and_overwrite_protection(small_result, tmp_path):
    output = tmp_path / "ensemble"
    paths = ensemble.write_ensemble(output, small_result, plots=False)
    assert set(paths) == {"realizations.csv", "summary.json", "recovered_axis_counts.fits"}
    with paths["realizations.csv"].open(newline="") as stream:
        rows = list(csv.DictReader(stream))
    assert len(rows) == 4
    assert all(float(row["dec_deg"]) >= 0 for row in rows)
    details = json.loads(paths["summary.json"].read_text())
    assert details["summary"]["std_ddof"] == 1
    assert (
        details["summary"]["theta_ia_mean_arcmin"]
        == small_result["summary"]["theta_ia_mean_arcmin"]
    )
    field = hp.read_map(paths["recovered_axis_counts.fits"], field=0, nest=True)
    north = hp.read_map(paths["recovered_axis_counts.fits"], field=1, nest=True).astype(bool)
    assert field[hp.mask_good(field)].sum() == 4
    assert np.all(hp.mask_bad(field[~north]))
    with fits.open(paths["recovered_axis_counts.fits"]) as hdul:
        assert hdul[1].header["COORDSYS"] == "C"
        assert hdul[1].header["ORDERING"] == "NESTED"
        assert hdul[1].header["N_SIM"] == 4
    with pytest.raises(FileExistsError):
        ensemble.write_ensemble(output, small_result, plots=False)
    keep = output / "unrelated.txt"
    keep.write_text("preserve this")
    ensemble.write_ensemble(output, small_result, plots=False, overwrite=True)
    assert keep.read_text() == "preserve this"


def test_stale_plot_files_cannot_be_reused_for_no_plot_overwrite(tmp_path):
    output = tmp_path / "old_output"
    output.mkdir()
    (output / "recovered_axes_mollweide.png").write_bytes(b"old plot")
    with pytest.raises(FileExistsError, match="Old plots"):
        ensemble.validate_ensemble_output(output, plots=False, overwrite=True)


def test_optional_plots_are_written(small_result, tmp_path):
    pytest.importorskip("matplotlib")
    paths = ensemble.write_ensemble(tmp_path / "plotted", small_result, plots=True)
    for name in ("recovered_axes_mollweide.png", "theta_ia_distribution.png"):
        assert paths[name].read_bytes().startswith(b"\x89PNG")


def test_cli_smoke_and_preflight(tmp_path):
    script = Path(__file__).resolve().parents[1] / "examples" / "north_pole_ensemble.py"
    output = tmp_path / "cli"
    command = [
        sys.executable,
        str(script),
        "--n-simulations",
        "4",
        "--n-objects",
        "100",
        "--theta-arcmin",
        "600",
        "--nside",
        "1",
        "--no-plot",
        "--output",
        str(output),
    ]
    run = subprocess.run(command, capture_output=True, text=True, check=False, timeout=30)
    assert run.returncode == 0, run.stderr
    assert "[04/04]" in run.stdout
    assert (output / "summary.json").exists()
    again = subprocess.run(
        [sys.executable, str(script), "--output", str(output), "--no-plot"],
        capture_output=True,
        text=True,
        check=False,
        timeout=10,
    )
    assert again.returncode != 0
    assert "exists" in again.stderr
    assert "[01/64]" not in again.stdout
