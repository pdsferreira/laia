"""Small integration and bookkeeping checks for the occupied-block bootstrap."""

import healpy as hp
import numpy as np
import pytest

import laia.bootstrap as module
from laia.bootstrap import (
    build_spatial_blocks,
    spatial_block_bootstrap,
    summarize_bootstrap,
)
from laia.geometry import sky_to_vectors


def catalog(seed=15, size=90):
    rng = np.random.default_rng(seed)
    return sky_to_vectors(
        rng.uniform(0, 360, size),
        np.degrees(np.arcsin(rng.uniform(-1, 1, size))),
        rng.uniform(0, 180, size),
    )


def test_blocks_group_whole_occupied_pixels():
    _, n = catalog()
    ids, groups = build_spatial_blocks(n, nside_blocks=1, nest=True)
    pixels = hp.vec2pix(1, *n.T, nest=True)
    assert len(ids) == len(np.unique(pixels))
    np.testing.assert_array_equal(np.sort(np.concatenate(groups)), np.arange(len(n)))
    for pixel, group in zip(ids, groups):
        assert np.all(pixels[group] == pixel)


def test_bootstrap_is_seeded_and_retains_all_samples():
    a, n = catalog()
    kwargs = dict(
        weights="uniform",
        n_resamples=6,
        nside_blocks=1,
        nside=2,
        seed=42,
        include_complex=True,
        gal_chunk=40,
        direction_chunk=16,
    )
    first = spatial_block_bootstrap(a, n, **kwargs)
    second = spatial_block_bootstrap(a, n, **kwargs)
    for key in first["samples"]:
        np.testing.assert_array_equal(first["samples"][key], second["samples"][key])
    assert first["samples"]["axis"].shape == (6, 3)
    assert first["samples"]["complex_axis"].shape == (6, 3)
    assert first["samples"]["amplitude_valid"].all()
    assert first["metadata"]["nside_blocks"] == 1
    assert first["metadata"]["n_resamples"] == 6
    assert first["metadata"]["complex_null_subtracted"] is False
    assert first["summary"]["n_amplitude_valid"] == 6
    np.testing.assert_allclose(np.linalg.norm(first["samples"]["axis"], axis=1), 1)


def test_paired_psf_uncertainty_and_whole_blocks_are_kept(monkeypatch):
    a, n = catalog(size=48)
    sigma = 0.03 + 0.0001 * np.arange(len(a))
    psf_a = np.cross(n, a)
    calls = []
    original = module.compute_maps

    def capture(aa, nn, **kwargs):
        calls.append((aa.copy(), nn.copy(), np.asarray(kwargs["sigma_pa"]).copy()))
        return original(aa, nn, **kwargs)

    monkeypatch.setattr(module, "compute_maps", capture)
    result = spatial_block_bootstrap(
        a,
        n,
        sigma_pa=sigma,
        psf_a=psf_a,
        n_resamples=4,
        nside_blocks=1,
        nside=1,
        seed=93,
    )
    assert len(calls) == 2 * (1 + 4)  # full sample, then every paired draw
    original_pixels = hp.vec2pix(1, *n.T, nest=True)
    for observed_call, psf_call in zip(calls[0::2], calls[1::2]):
        aa, nn, ss = observed_call
        pp, pn, ps = psf_call
        np.testing.assert_allclose(pp, np.cross(nn, aa), atol=1e-14)
        np.testing.assert_array_equal(nn, pn)
        np.testing.assert_array_equal(ss, ps)
        # Each object's unique uncertainty identifies its original row.  Every
        # member of a selected block must occur the same number of times.
        selected_ids = np.rint((ss - 0.03) / 0.0001).astype(int)
        multiplicity = np.bincount(selected_ids, minlength=len(a))
        for pixel in np.unique(original_pixels):
            count = multiplicity[original_pixels == pixel]
            assert np.all(count == count[0])
    assert result["metadata"]["psf_projection"] is True
    assert np.all(np.isfinite(result["samples"]["eta_psf"]))


def test_constant_raw_null_preserves_uncorrected_measurements():
    a, n = catalog()
    common = dict(weights="uniform", n_resamples=4, nside_blocks=1, nside=2, seed=8)
    raw = spatial_block_bootstrap(a, n, **common)
    corrected = spatial_block_bootstrap(a, n, null_mean=np.full(48, 0.5), **common)
    np.testing.assert_allclose(
        raw["samples"]["theta_ia_rad"], corrected["samples"]["theta_ia_rad"], atol=1e-13
    )
    np.testing.assert_allclose(raw["samples"]["axis"], corrected["samples"]["axis"])
    assert corrected["metadata"]["fixed_null_mean_subtracted"] is True


def test_invalid_amplitude_is_flagged_and_not_deleted(monkeypatch):
    a, n = catalog()
    original = module.measurement_from_map
    count = 0

    def one_invalid(*args, **kwargs):
        nonlocal count
        result = original(*args, **kwargs)
        count += 1
        if count == 3:
            result["theta_ia_rad"] = np.nan
            result["theta_ia_arcmin"] = np.nan
            result["amplitude_valid"] = False
        return result

    monkeypatch.setattr(module, "measurement_from_map", one_invalid)
    with pytest.warns(RuntimeWarning, match="1 of 4 amplitudes are invalid"):
        result = spatial_block_bootstrap(
            a, n, weights="uniform", n_resamples=4, nside_blocks=1, nside=1, seed=8
        )
    assert result["samples"]["axis"].shape == (4, 3)
    assert result["summary"]["n_amplitude_invalid"] == 1
    assert result["summary"]["n_amplitude_valid"] == 3
    assert result["summary"]["n_axis_valid"] == 4
    assert np.isnan(result["samples"]["theta_ia_rad"][1])
    expected = np.percentile(result["samples"]["theta_ia_rad"][[0, 2, 3]], [15.865, 50, 84.135])
    np.testing.assert_allclose(result["summary"]["theta_ia_rad"], expected)


def test_axial_summary_handles_antipodes_and_ra_wrap():
    _, axes = sky_to_vectors([359.0, 0.0, 1.0], [30.0, 30.0, 30.0], [0, 0, 0])
    axes[1] *= -1
    _, reference = sky_to_vectors(0, 30, 0)
    result = summarize_bootstrap(dict(axis=axes, theta_ia_rad=[0.1, 0.11, 0.09]), reference[0])
    assert max(result["axial_separation_deg"]) < 1.0
    assert result["axial_dyad_eigenvalues"][0] > 0.999
    assert "ra_deg" not in result


def test_repeated_grid_maxima_do_not_report_spurious_zero_uncertainty():
    _, reference = sky_to_vectors(17, 37, 0)
    axes = np.repeat(reference, 4, axis=0)
    axes[2:] *= -1
    result = summarize_bootstrap(
        dict(
            axis=axes,
            theta_ia_rad=[0.1, 0.11, 0.09, 0.12],
            pixel=[5, 5, 9, 9],  # two antipodal grid representatives
        ),
        reference[0],
    )
    assert result["n_unique_axes"] == 1
    assert result["n_unique_grid_pixels"] == 2
    assert result["most_common_grid_pixel_fraction"] == 0.5
    assert result["direction_spread_grid_limited"] is True
    assert result["axial_separation_deg"][2] < 1e-7
    assert any("do not imply zero angular uncertainty" in note for note in result["warnings"])


def test_numeric_weights_zero_rows_are_explicitly_excluded():
    a, n = catalog(size=30)
    weights = np.ones(len(a))
    weights[:3] = 0
    result = spatial_block_bootstrap(
        a, n, weights=weights, n_resamples=3, nside_blocks=1, nside=1, seed=7
    )
    assert result["metadata"]["n_zero_weight_excluded"] == 3
    assert result["metadata"]["n_input_objects"] == 30
    assert result["metadata"]["n_used_objects"] == 27
    assert "zero-weight" in result["summary"]["warnings"][-1]


def test_optional_stochastic_rotation_is_seeded_and_documented():
    a, n = catalog(size=60)
    common = dict(
        weights="uniform",
        n_resamples=4,
        nside_blocks=1,
        nside=1,
        seed=52,
        extra_rotation_rad=np.deg2rad(1.0 / 60.0),
    )
    first = spatial_block_bootstrap(a, n, **common)
    second = spatial_block_bootstrap(a, n, **common)
    np.testing.assert_array_equal(
        first["samples"]["extra_rotation_axis"], second["samples"]["extra_rotation_axis"]
    )
    np.testing.assert_allclose(np.linalg.norm(first["samples"]["extra_rotation_axis"], axis=1), 1)
    assert first["metadata"]["extra_rotation_rad"] == common["extra_rotation_rad"]
    assert first["metadata"]["extra_rotation_rad"] > 0


@pytest.mark.parametrize("n_resamples", [0, 1, 2.5, True])
def test_invalid_number_of_resamples(n_resamples):
    a, n = catalog(size=12)
    with pytest.raises(ValueError, match="n_resamples"):
        spatial_block_bootstrap(a, n, weights="uniform", n_resamples=n_resamples)


def test_single_block_is_not_a_usable_bootstrap():
    a, n = sky_to_vectors([10, 10.1], [40, 40.1], [0, 30])
    with pytest.raises(ValueError, match="at least two occupied"):
        spatial_block_bootstrap(a, n, weights="uniform", n_resamples=3, nside_blocks=1)


def test_invalid_tracer_and_rotation_are_rejected():
    a, n = catalog()
    with pytest.raises(ValueError, match="tracer"):
        spatial_block_bootstrap(a, n, weights="uniform", tracer="combined")
    with pytest.raises(ValueError, match="extra_rotation_rad"):
        spatial_block_bootstrap(a, n, weights="uniform", extra_rotation_rad=-0.1)


def test_bootstrap_retains_inverse_variance_weighting_and_floor_metadata():
    a, n = catalog(size=50)
    sigma = np.deg2rad(np.linspace(0.2, 3.0, 50))
    result = spatial_block_bootstrap(
        a,
        n,
        sigma_pa=sigma,
        n_resamples=3,
        nside_blocks=1,
        nside=1,
        seed=5,
        attenuation_uses_floor=False,
    )
    assert result["metadata"]["weighting"] == "inverse_variance"
    assert result["metadata"]["attenuation_uses_floor"] is False
    assert result["metadata"]["sigma_floor_rad"] == pytest.approx(np.deg2rad(1))
