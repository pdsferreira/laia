"""Small real-FITS integration checks of the historical public entry points."""

import importlib
import json

import healpy as hp
import numpy as np
import pytest
from astropy.io import fits
from astropy.table import Table

from laia import (
    complex_diagnostic,
    compute_maps,
    evaluate_directions,
    measurement_from_map,
    project_psf_map,
    spatial_block_bootstrap,
    theta_ia_from_peak,
)
from laia.io import read_catalog, read_field, read_maps, write_catalog
from laia.mock import add_pa_noise, generate_mock


@pytest.fixture
def fits_catalog(tmp_path):
    mock = generate_mock(
        180,
        direction=[0.75, np.sqrt(3) / 4, 0.5],
        theta_ia_rad=np.deg2rad(15),
        sigma_pa_rad=np.deg2rad(2),
        seed=501,
    )
    path = tmp_path / "catalog.fits"
    write_catalog(path, mock["a"], mock["n"], sigma_pa=mock["sigma_pa"])
    return path, mock


@pytest.mark.parametrize("nest", [False, True])
def test_run_estimator_writes_honest_ordering_and_baselines(fits_catalog, tmp_path, nest):
    from estimator.laia_maps import run_estimator_new

    path, _ = fits_catalog
    out = tmp_path / "maps"
    result = run_estimator_new(
        path,
        nside=2,
        nest=nest,
        output_dir=out,
        gal_chunk=37,
        direction_chunk=9,
    )
    stored = read_maps(out / "catalog_maps.fits")
    assert stored["nest"] is nest
    assert stored["ordering"] == ("NESTED" if nest else "RING")
    for key in ("Ea", "Eb", "Eab", "Eam"):
        np.testing.assert_allclose(stored[key], result[key], equal_nan=True)
    assert stored["c_bar"] == pytest.approx(result["c_bar"])
    for suffix, centered in (("Ea", False), ("Eb", False), ("Eab", True), ("Ea_minus_b", True)):
        field = read_field(out / f"catalog_{suffix}.fits")
        assert field["nest"] is nest
        assert field["centered"] is centered
        assert field["c_bar"] == pytest.approx(result["c_bar"])
        np.testing.assert_array_equal(field["valid_mask"], result["valid_mask"])
    assert "C_BAR" in (out / "catalog_stats.txt").read_text()
    with pytest.raises(FileExistsError):
        run_estimator_new(path, nside=2, nest=nest, output_dir=out)


def test_uncertainty_map_ordering_is_independent_of_output_order(fits_catalog, tmp_path):
    from estimator.laia_maps import run_estimator_new

    _, mock = fits_catalog
    path = tmp_path / "without_sigma.fits"
    write_catalog(path, mock["a"], mock["n"])
    error_map = np.linspace(0.03, 0.12, hp.nside2npix(2))
    pixel = hp.vec2pix(2, *mock["n"].T, nest=False)
    expected = compute_maps(mock["a"], mock["n"], sigma_pa=error_map[pixel], nside=2, nest=True)
    actual = run_estimator_new(
        path,
        error_map=error_map,
        error_map_nest=False,
        nside=2,
        nest=True,
        output_dir=tmp_path / "map_results",
    )
    np.testing.assert_allclose(actual["Ea"], expected["Ea"], equal_nan=True, atol=1e-14)
    assert actual["c_bar"] == pytest.approx(expected["c_bar"])


def test_missing_uncertainty_requires_explicit_uniform_mode(fits_catalog, tmp_path):
    from estimator.laia_maps import run_estimator_new

    _, mock = fits_catalog
    path = tmp_path / "noiseless.fits"
    write_catalog(path, mock["a"], mock["n"])
    with pytest.raises(ValueError):
        run_estimator_new(path, nside=2, output_dir=tmp_path / "missing")
    result = run_estimator_new(
        path,
        nside=2,
        weights="uniform",
        output_dir=tmp_path / "explicit",
    )
    assert result["c_bar"] == 1


def test_dual_adapter_returns_both_real_measurements_and_separate_complex_extra(fits_catalog):
    from estimator.laia_maps import analyze_dual_and_DIA

    _, mock = fits_catalog
    maps = compute_maps(mock["a"], mock["n"], sigma_pa=mock["sigma_pa"], nside=2)
    result = analyze_dual_and_DIA(
        *(maps[key] for key in ("Ea", "Eb", "Eab", "Eam")),
        nside=2,
        c_bar=maps["c_bar"],
        valid_mask=maps["valid_mask"],
    )
    for tracer in ("a", "b"):
        expected = measurement_from_map(
            maps["E" + tracer],
            maps["c_bar"],
            nside=2,
            valid_mask=maps["valid_mask"],
            on_invalid="nan",
        )
        assert result[f"d_IA_{tracer}"]["pix"] == expected["pixel"]
        assert result[f"d_IA_{tracer}"]["ra_deg"] == expected["ra_deg"]
        assert result[f"theta_IA_{tracer}_arcmin"] == pytest.approx(expected["theta_ia_arcmin"])
    diagnostic = complex_diagnostic(maps)
    assert result["D_IA"]["pix"] == diagnostic["pixel"]
    assert result["A_IA"] == pytest.approx(diagnostic["A_complex"])


def test_dual_adapter_supports_old_joint_zero_padding(fits_catalog):
    from estimator.laia_maps import analyze_dual_and_DIA

    _, mock = fits_catalog
    maps = compute_maps(mock["a"], mock["n"], sigma_pa=mock["sigma_pa"], nside=2)
    fields = [np.where(maps["valid_mask"], maps[key], 0.0) for key in ("Ea", "Eb", "Eab", "Eam")]
    result = analyze_dual_and_DIA(*fields, nside=2, c_bar=maps["c_bar"])
    assert maps["valid_mask"][result["d_IA_a"]["pix"]]
    assert maps["valid_mask"][result["D_IA"]["pix"]]


def _psf_fields():
    phi = 2 * np.pi * np.arange(48) / 48
    clean = 0.10 * np.cos(phi)
    template = 0.04 * np.sin(phi)
    null = 0.01 * np.cos(2 * phi)
    observed = 0.5 + clean + 0.3 * template + null
    psf = 0.5 + template
    return observed, psf, 0.5 + null


def test_psf_adapter_converts_centered_residual_without_subtracting_half_twice():
    from estimator.laia_maps import analyze_with_psf_corrections

    observed, psf, null_mean = _psf_fields()
    cross = 0.01 * np.sin(4 * np.pi * np.arange(48) / 48)
    result = analyze_with_psf_corrections(
        observed,
        1 - observed,
        cross,
        psf,
        1 - psf,
        np.zeros(48),
        nside=2,
        c_bar=1,
        valid_mask=np.ones(48, dtype=bool),
        null_mean_a=null_mean,
        null_mean_b=1 - null_mean,
    )
    expected = project_psf_map(observed, psf, null_mean=null_mean)
    np.testing.assert_allclose(result["Ea_res_ax"], expected["corrected_map"], atol=1e-14)
    assert result["eta_a"] == pytest.approx(0.3, abs=1e-12)
    assert result["real_residuals_centered"] is True
    theta = theta_ia_from_peak(np.max(expected["corrected_map"]), 1, centered=True)
    assert result["theta_IA_a_arcmin"] == pytest.approx(np.rad2deg(theta) * 60)
    assert result["theta_IA_a_arcmin"] > 100


def test_psf_returned_mask_respects_missing_null_template_pixels():
    from estimator.laia_maps import analyze_with_psf_corrections

    observed, psf, null_mean = _psf_fields()
    null_mean[3] = np.nan
    result = analyze_with_psf_corrections(
        observed,
        1 - observed,
        np.zeros(48),
        psf,
        1 - psf,
        np.zeros(48),
        nside=2,
        c_bar=1,
        null_mean_a=null_mean,
    )
    assert np.isnan(result["Ea_res_ax"][3])
    assert not result["valid_mask"][3]


def test_legacy_arbitrary_baseline_is_not_silently_accepted():
    from estimator.laia_maps import analyze_with_psf_corrections

    observed, psf, _ = _psf_fields()
    with pytest.raises(ValueError, match="centered"):
        analyze_with_psf_corrections(
            observed,
            1 - observed,
            np.zeros(48),
            psf,
            1 - psf,
            np.zeros(48),
            nside=2,
            c_bar=1,
            de_leak_mode="baseline",
        )


@pytest.mark.parametrize("extra_rotation", [False, True])
def test_matched_psf_bootstrap_adapter_retains_every_draw(fits_catalog, tmp_path, extra_rotation):
    from estimator.laia_maps import bootstrap_errors_from_catalog

    path, mock = fits_catalog
    psf_a = add_pa_noise(mock["a"], mock["n"], 0.8, seed=73)
    psf_path = tmp_path / "psf.fits"
    write_catalog(psf_path, psf_a, mock["n"])
    kwargs = dict(
        arquivo_fits_psf=psf_path,
        with_psf=True,
        lensing=extra_rotation,
        B=4,
        nside_blocks=2,
        nside_eval=2,
        seed=33,
        outdir=tmp_path / "bootstrap",
        include_complex=True,
    )
    if extra_rotation:
        with pytest.warns(UserWarning, match="not physical shear"):
            output = bootstrap_errors_from_catalog(path, **kwargs)
    else:
        output = bootstrap_errors_from_catalog(path, **kwargs)
    actual = Table.read(output, hdu="SAMPLES")
    with fits.open(output) as hdul:
        details = json.loads(hdul["SUMMARY"].data["JSON"][0])
    assert len(actual) == 4
    assert details["metadata"]["psf_projection"]
    assert details["metadata"]["include_complex"]
    assert details["metadata"]["tracer"] == "a"
    assert "amplitude_valid" in actual.colnames
    assert "complex_axis" in actual.colnames
    data = read_catalog(path)
    matched = read_catalog(psf_path)
    expected = spatial_block_bootstrap(
        data["a"],
        data["n"],
        sigma_pa=data["sigma_pa"],
        psf_a=matched["a"],
        n_resamples=4,
        nside_blocks=2,
        nside=2,
        seed=33,
        include_complex=True,
        extra_rotation_rad=np.deg2rad(1 / 60) if extra_rotation else 0,
    )
    for key in ("theta_ia_rad", "axis", "eta_psf", "A_complex", "extra_rotation_axis"):
        decoded = np.ma.asarray(actual[key]).filled(np.nan)
        np.testing.assert_allclose(decoded, expected["samples"][key], equal_nan=True, atol=1e-13)
    rotation_axes = np.ma.asarray(actual["extra_rotation_axis"]).filled(np.nan)
    if extra_rotation:
        assert np.all(np.isfinite(rotation_axes))
    else:
        assert np.all(np.isnan(rotation_axes))


def test_bootstrap_rejects_unmatched_psf_rows(fits_catalog, tmp_path):
    from estimator.laia_maps import bootstrap_errors_from_catalog

    path, mock = fits_catalog
    psf_path = tmp_path / "misordered_psf.fits"
    write_catalog(psf_path, np.roll(mock["a"], 1, axis=0), np.roll(mock["n"], 1, axis=0))
    with pytest.raises(ValueError, match="row by row"):
        bootstrap_errors_from_catalog(
            path,
            arquivo_fits_psf=psf_path,
            with_psf=True,
            B=4,
            nside_eval=2,
            outdir=tmp_path / "invalid",
        )


def test_iterative_compatibility_uses_shared_e_kernel(fits_catalog, tmp_path):
    from estimator.laia_maps_alt_it import compute_chi2_for_pixels, run_estimator_g_rot

    path, mock = fits_catalog
    initial, levels = run_estimator_g_rot(
        path,
        nside1=2,
        nside2=4,
        nside3=None,
        output_dir=tmp_path / "iterative",
        chunk_size=50,
    )
    coarse = compute_maps(mock["a"], mock["n"], sigma_pa=mock["sigma_pa"], nside=2)
    np.testing.assert_allclose(initial, coarse["Ea"], equal_nan=True, atol=1e-14)
    for level in levels:
        direction = np.asarray(hp.pix2vec(level["nside"], level["max_pixel"], nest=True))[None, :]
        expected = evaluate_directions(mock["a"], mock["n"], direction, sigma_pa=mock["sigma_pa"])
        assert level["max_value"] == pytest.approx(expected["Ea"][0], abs=1e-14)
        assert level["theta_ia"] == pytest.approx(
            theta_ia_from_peak(expected["Ea"][0], expected["c_bar"])
        )
    error_map = np.full(48, np.deg2rad(2))
    selected = np.array([0, 9, 23])
    compat = compute_chi2_for_pixels(2, selected, mock["a"], mock["n"], error_map, 50)
    expected = evaluate_directions(
        mock["a"],
        mock["n"],
        np.column_stack(hp.pix2vec(2, selected, nest=True)),
        sigma_pa=mock["sigma_pa"],
    )
    np.testing.assert_allclose(compat, expected["Ea"], atol=1e-14)


def test_iterative_helper_requires_explicit_weights_when_sigma_absent(fits_catalog):
    from estimator.laia_maps_alt_it import compute_chi2_for_pixels

    _, mock = fits_catalog
    with pytest.raises(ValueError):
        compute_chi2_for_pixels(2, [0, 1], mock["a"], mock["n"], None)


def test_importing_compatibility_modules_has_no_catalog_io(monkeypatch, tmp_path):
    def forbidden(*args, **kwargs):
        pytest.fail("Compatibility module import attempted file I/O.")

    monkeypatch.setattr(hp, "read_map", forbidden)
    monkeypatch.setattr(Table, "read", forbidden)
    monkeypatch.chdir(tmp_path)
    for name in ("estimator.laia_maps", "estimator.laia_maps_alt_it"):
        module = importlib.import_module(name)
        importlib.reload(module)
    assert list(tmp_path.iterdir()) == []
