"""Run the documented examples as real commands against synthetic data only."""

import json
import os
from pathlib import Path
import subprocess
import sys

import numpy as np
import pytest
from astropy.table import Table

from laia.io import read_maps, write_field


ROOT = Path(__file__).resolve().parents[1]


def _run_example(name, arguments, working_directory, *, check=True):
    environment = os.environ.copy()
    environment["PYTHONPATH"] = str(ROOT) + os.pathsep + environment.get("PYTHONPATH", "")
    environment["MPLBACKEND"] = "Agg"
    environment["OPENBLAS_NUM_THREADS"] = "1"
    result = subprocess.run(
        [sys.executable, str(ROOT / "examples" / name), *map(str, arguments)],
        cwd=working_directory,
        env=environment,
        text=True,
        capture_output=True,
        timeout=60,
    )
    if check:
        assert result.returncode == 0, result.stdout + result.stderr
    return result


@pytest.mark.parametrize("noise,ring", [(0, False), (2, True)])
def test_quickstart_and_saved_maps_recover_identical_measurement(tmp_path, noise, ring):
    destination = tmp_path / "quickstart"
    arguments = [
        "--n-objects",
        "1000",
        "--nside",
        "4",
        "--noise-deg",
        noise,
        "--theta-deg",
        "15",
        "--seed",
        "3",
        "--output",
        destination,
    ]
    if ring:
        arguments.append("--ring")
    run = _run_example("quickstart.py", arguments, tmp_path)
    report = json.loads(run.stdout)
    saved = json.loads((destination / "recovery.json").read_text())
    assert report == saved
    assert report["max_complement_error"] < 1e-12
    assert report["nest"] is not ring
    assert report["c_bar"] == pytest.approx(np.exp(-2 * np.deg2rad(noise) ** 2))
    assert (destination / "mock.fits").exists()
    readback = _run_example(
        "maps_to_measurement.py",
        [destination / "maps.fits", "--field", "a"],
        tmp_path,
    )
    measurement = json.loads(readback.stdout)
    assert measurement["pixel"] == report["recovered"]["pixel"]
    assert measurement["theta_ia_arcmin"] == pytest.approx(report["recovered"]["theta_ia_arcmin"])
    duplicate = _run_example("quickstart.py", arguments, tmp_path, check=False)
    assert duplicate.returncode != 0
    assert "exists" in duplicate.stderr


def test_maps_example_respects_centered_single_field_metadata(tmp_path):
    destination = tmp_path / "quickstart"
    _run_example(
        "quickstart.py",
        ["--n-objects", "1000", "--nside", "4", "--output", destination],
        tmp_path,
    )
    maps = read_maps(destination / "maps.fits")
    centered_path = tmp_path / "centered.fits"
    write_field(
        centered_path,
        maps["Ea"] - 0.5,
        c_bar=maps["c_bar"],
        nest=maps["nest"],
        valid_mask=maps["valid_mask"],
        centered=True,
    )
    centered = json.loads(
        _run_example(
            "maps_to_measurement.py",
            [centered_path, "--single"],
            tmp_path,
        ).stdout
    )
    raw = json.loads(
        _run_example(
            "maps_to_measurement.py",
            [destination / "maps.fits"],
            tmp_path,
        ).stdout
    )
    assert centered["centered"]
    assert centered["theta_ia_arcmin"] == pytest.approx(raw["theta_ia_arcmin"])
    assert centered["pixel"] == raw["pixel"]


def test_bootstrap_example_saves_all_draws_and_complex_extra(tmp_path):
    destination = tmp_path / "bootstrap.fits"
    result = _run_example(
        "bootstrap_example.py",
        [
            "--n-objects",
            "150",
            "--n-resamples",
            "4",
            "--nside",
            "2",
            "--nside-blocks",
            "2",
            "--output",
            destination,
        ],
        tmp_path,
    )
    samples = Table.read(destination, hdu="SAMPLES")
    assert len(samples) == 4
    assert "amplitude_valid" in samples.colnames
    assert "complex_axis" in samples.colnames
    assert "not a detection significance" in result.stdout


def test_psf_example_runs_without_external_inputs_or_outputs(tmp_path):
    result = _run_example("psf_map_example.py", [], tmp_path)
    assert '"fitted_eta"' in result.stdout
    assert "not a replacement" in result.stdout
    assert list(tmp_path.iterdir()) == []


def test_quickstart_ensemble_saves_recovered_axes_and_summary(tmp_path):
    destination = tmp_path / "ensemble"
    arguments = [
        "--ensemble", "--n-simulations", "4", "--n-objects", "500",
        "--nside", "2", "--no-plots", "--output", destination,
    ]
    run = _run_example("quickstart.py", arguments, tmp_path)
    assert "[04/04]" in run.stdout
    assert (destination / "summary.json").exists()
    assert (destination / "recovered_axis_counts.fits").exists()
    rows = np.genfromtxt(destination / "realizations.csv", delimiter=",", names=True)
    assert len(rows) == 4
    assert np.all(rows["dec_deg"] >= 0)
    duplicate = _run_example("quickstart.py", arguments, tmp_path, check=False)
    assert duplicate.returncode != 0
    assert "exists" in duplicate.stderr
    assert "[01/04]" not in duplicate.stdout


def test_quickstart_ensemble_defaults_are_distinct_from_single_mock(tmp_path, monkeypatch):
    import runpy

    import laia.ensemble

    calls = {}

    def fake_run(**kwargs):
        calls["run"] = kwargs
        return {"summary": {"test": "no simulations executed"}}

    def fake_write(output, result, **kwargs):
        calls["write"] = (output, result, kwargs)

    monkeypatch.setattr(laia.ensemble, "run_north_pole_ensemble", fake_run)
    monkeypatch.setattr(laia.ensemble, "write_ensemble", fake_write)
    monkeypatch.setattr(sys, "argv", [str(ROOT / "examples" / "quickstart.py"), "--ensemble", "--output", str(tmp_path / "default_ensemble")])
    runpy.run_path(str(ROOT / "examples" / "quickstart.py"), run_name="__main__")
    assert calls["run"]["n_simulations"] == 64
    assert calls["run"]["n_objects"] == 100_000
    assert calls["run"]["theta_ia_arcmin"] == 60
    assert calls["run"]["sigma_pa_deg"] == 0
    assert calls["run"]["nside"] == 32
    assert calls["write"][2]["plots"] is True


def test_quickstart_single_mock_accepts_explicit_arcminutes(tmp_path):
    run = _run_example(
        "quickstart.py",
        ["--n-objects", "500", "--nside", "2", "--theta-arcmin", "60", "--output", tmp_path / "arcmin"],
        tmp_path,
    )
    report = json.loads(run.stdout)
    assert report["injected"]["theta_ia_deg"] == 1


def test_quickstart_rejects_incompatible_ensemble_geometry(tmp_path):
    result = _run_example(
        "quickstart.py", ["--ensemble", "--dec-deg", "30"], tmp_path, check=False
    )
    assert result.returncode != 0
    assert "north--south axis" in result.stderr
    assert list(tmp_path.iterdir()) == []
