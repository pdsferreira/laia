import numpy as np
import pytest

from laia.geometry import (
    axial_separation,
    canonical_axis,
    sky_to_vectors,
    validate_vectors,
    vector_to_radec,
)


def test_integer_inputs_are_float_copies():
    a = np.array([[0, 1, 0]])
    n = np.array([[1, 0, 0]])
    checked_a, checked_n = validate_vectors(a, n)
    assert checked_a.dtype == checked_n.dtype == np.float64
    checked_a[0, 1] = -1
    assert a[0, 1] == 1
    np.testing.assert_array_equal(checked_n, n)


def test_only_small_roundoff_is_corrected():
    a, n = validate_vectors([[1e-9, 1, 0]], [[1 + 1e-9, 0, 0]])
    np.testing.assert_allclose(np.sum(a * n, axis=1), 0, atol=1e-15)
    np.testing.assert_allclose(np.linalg.norm(a, axis=1), 1)
    np.testing.assert_allclose(np.linalg.norm(n, axis=1), 1)


def test_loose_tolerance_does_not_allow_zero_vectors():
    with pytest.raises(ValueError, match="nonzero"):
        validate_vectors([[0, 0, 0]], [[1, 0, 0]], atol=2)


@pytest.mark.parametrize(
    "a,n",
    [
        ([], []),
        ([[1, 0, 0]], [[1, 0, 0]]),
        ([[0, 2, 0]], [[1, 0, 0]]),
        ([[0, 1, 0]], [[0, 0, 0]]),
        ([[0, np.nan, 0]], [[1, 0, 0]]),
        ([0, 1, 0], [1, 0, 0]),
        ([[0, 1, 0], [0, 1, 0]], [[1, 0, 0]]),
    ],
)
def test_invalid_vectors_rejected(a, n):
    with pytest.raises(ValueError):
        validate_vectors(a, n)


def test_pa_conventions_at_equator():
    a, n = sky_to_vectors(0, 0, [0, 90], convention="east_of_north")
    np.testing.assert_allclose(n, [[1, 0, 0], [1, 0, 0]], atol=1e-15)
    np.testing.assert_allclose(a, [[0, 0, 1], [0, 1, 0]], atol=1e-15)
    legacy, _ = sky_to_vectors(0, 0, [0, 90], convention="west_ccw")
    np.testing.assert_allclose(legacy, [[0, -1, 0], [0, 0, 1]], atol=1e-15)


def test_pa_convention_conversion_and_sign_equivalence():
    ra, dec, pa = [1, 100, 359], [-45, 90, 0], np.array([2, 120, 380])
    a, n = sky_to_vectors(ra, dec, pa)
    legacy, n_legacy = sky_to_vectors(ra, dec, pa + 90, convention="west_ccw")
    opposite, _ = sky_to_vectors(ra, dec, pa + 180)
    np.testing.assert_allclose(a, legacy, atol=2e-15)
    np.testing.assert_allclose(n, n_legacy)
    np.testing.assert_allclose(a, -opposite, atol=2e-15)


def test_radian_coordinates_and_scalar_shapes():
    a, n = sky_to_vectors(np.pi / 2, -np.pi / 4, np.pi / 3, degrees=False)
    degree_a, degree_n = sky_to_vectors(90, -45, 60)
    assert a.shape == n.shape == (1, 3)
    np.testing.assert_allclose(a, degree_a)
    np.testing.assert_allclose(n, degree_n)
    ra, dec = vector_to_radec(n[0])
    assert ra == pytest.approx(90)
    assert dec == pytest.approx(-45)


@pytest.mark.parametrize(
    "kwargs",
    [
        {"dec": 91},
        {"ra": np.inf},
        {"pa": np.nan},
        {"convention": "unknown"},
    ],
)
def test_invalid_sky_inputs(kwargs):
    values = {"ra": 0, "dec": 0, "pa": 0, **kwargs}
    with pytest.raises(ValueError):
        sky_to_vectors(**values)


def test_canonical_axis_all_tie_cases():
    axes = np.array([[0, 0, -2], [0, -3, 0], [-4, 0, 0], [1, -2, 3]])
    canonical = canonical_axis(axes)
    np.testing.assert_allclose(canonical_axis(-axes), canonical)
    np.testing.assert_allclose(canonical[:3], [[0, 0, 1], [0, 1, 0], [1, 0, 0]])
    np.testing.assert_allclose(np.linalg.norm(canonical, axis=1), 1)


@pytest.mark.parametrize("axis", [[0, 0, 0], [np.inf, 0, 1], [1, 2], []])
def test_invalid_axes_rejected(axis):
    with pytest.raises(ValueError):
        canonical_axis(axis)


def test_axial_separation_is_antipodal_and_broadcasts():
    first = [0, 0, 2]
    others = [[0, 0, 3], [0, 0, -1], [1, 0, 0], [1, 0, 1]]
    np.testing.assert_allclose(axial_separation(first, others), [0, 0, 90, 45])
    assert axial_separation([1, 0, 0], [0, 1, 0], degrees=False) == pytest.approx(np.pi / 2)
    assert axial_separation([1, 0, 0], [-1, 0, 0]) == 0


def test_vector_to_radec_preserves_directed_sign():
    ra, dec = vector_to_radec([[0, 2, 0], [0, 0, -3]])
    np.testing.assert_allclose(ra, [90, 0])
    np.testing.assert_allclose(dec, [0, -90])


def test_zero_axis_separation_is_invalid():
    with pytest.raises(ValueError):
        axial_separation([0, 0, 0], [1, 0, 0])


@pytest.mark.parametrize("which", ["a", "n"])
def test_masked_finite_vector_entries_are_rejected(which):
    a = np.ma.array([[0.0, 1, 0]], mask=False)
    n = np.ma.array([[1.0, 0, 0]], mask=False)
    (a if which == "a" else n).mask[0, 0] = True
    with pytest.raises(ValueError, match="masked"):
        validate_vectors(a, n)


def test_masked_target_and_sky_coordinates_are_rejected():
    axis = np.ma.array([0.0, 0, 1], mask=[True, False, False])
    for function in (canonical_axis, vector_to_radec):
        with pytest.raises(ValueError, match="masked"):
            function(axis)
    with pytest.raises(ValueError, match="masked"):
        axial_separation(axis, [1, 0, 0])
    with pytest.raises(ValueError, match="masked"):
        sky_to_vectors(np.ma.array([0.0], mask=True), [0], [0])
