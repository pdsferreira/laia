import healpy as hp
import numpy as np
import pytest

from laia.estimator import (
    compute_maps,
    evaluate_directions,
    measurement_from_map,
    prepare_weights,
    theta_ia_from_peak,
)
from laia.geometry import axial_separation, canonical_axis, sky_to_vectors


def sample(size=27, seed=7):
    rng = np.random.default_rng(seed)
    return sky_to_vectors(
        rng.uniform(0, 360, size),
        np.rad2deg(np.arcsin(rng.uniform(-1, 1, size))),
        rng.uniform(0, 180, size),
    )


def test_weights_are_explicit_when_no_errors_exist():
    with pytest.raises(ValueError, match="explicitly choose"):
        prepare_weights(3)
    p = prepare_weights(3, weights="uniform")
    np.testing.assert_allclose(p["weights"], 1 / 3)
    assert p["c_bar"] == 1
    assert p["attenuation_convention"] == "noiseless"


def test_sigma_floor_and_attenuation_conventions():
    sigma = np.deg2rad([0.5, 2, 4])
    original = sigma.copy()
    effective = np.deg2rad([1, 2, 4])
    p = prepare_weights(3, sigma_pa=sigma)
    w = effective**-2 / np.sum(effective**-2)
    np.testing.assert_allclose(p["weights"], w)
    assert p["c_bar"] == pytest.approx(np.sum(w * np.exp(-2 * effective**2)))
    physical = prepare_weights(3, sigma_pa=sigma, attenuation_uses_floor=False)
    assert physical["c_bar"] == pytest.approx(np.sum(w * np.exp(-2 * sigma**2)))
    np.testing.assert_allclose(physical["weights"], w)
    np.testing.assert_array_equal(sigma, original)


@pytest.mark.parametrize("sigma", [[np.nan, 0.1], [np.inf, 0.1], [-1, 0.1], [0, 0.1], [[0.1, 0.2]]])
def test_invalid_sigma_not_given_large_weight(sigma):
    with pytest.raises(ValueError):
        prepare_weights(2, sigma_pa=sigma)


@pytest.mark.parametrize("weights", [[0, 0], [-1, 1], [np.nan, 1], [np.inf, 1], [1], "bad"])
def test_invalid_weights_rejected(weights):
    with pytest.raises(ValueError):
        prepare_weights(2, weights=weights)


def test_large_weights_do_not_overflow_normalization():
    p = prepare_weights(2, weights=[1e308, 1e308])
    np.testing.assert_allclose(p["weights"], [0.5, 0.5])


def test_numeric_weights_and_scalar_sigma():
    p = prepare_weights(3, weights=[1, 2, 0], sigma_pa=0.1)
    np.testing.assert_allclose(p["weights"], [1 / 3, 2 / 3, 0])
    assert p["c_bar"] == pytest.approx(np.exp(-0.02))


def test_mixed_noiseless_objects_require_explicit_weights():
    sigma = [0, 0.1, 0.2]
    with pytest.raises(ValueError, match="strictly positive"):
        prepare_weights(3, sigma_pa=sigma)
    p = prepare_weights(3, sigma_pa=sigma, weights="uniform", attenuation_uses_floor=False)
    assert p["c_bar"] == pytest.approx(np.mean(np.exp(-2 * np.square(sigma))))
    np.testing.assert_allclose(p["weights"], 1 / 3)


def test_maps_match_direct_formula():
    a, n = sample()
    directions = np.array([[0, 0, 1], [1, 0, 0], [1, 2, 3]], dtype=float)
    directions /= np.linalg.norm(directions, axis=1)[:, None]
    weights = np.linspace(1, 2, len(a))
    result = evaluate_directions(a, n, directions, weights=weights)
    weights /= weights.sum()
    b = np.cross(n, a)
    den = 1 - (directions @ n.T) ** 2
    da, db = directions @ a.T, directions @ b.T
    np.testing.assert_allclose(result["Ea"], np.sum(weights * da**2 / den, axis=1), atol=2e-15)
    np.testing.assert_allclose(result["Eb"], np.sum(weights * db**2 / den, axis=1), atol=2e-15)
    np.testing.assert_allclose(
        result["Eab"], np.sum(weights * 2 * da * db / den, axis=1), atol=2e-15
    )
    np.testing.assert_allclose(result["Ea"] + result["Eb"], 1, atol=2e-14)
    np.testing.assert_allclose(result["Eam"], result["Ea"] - result["Eb"])


def test_antipodal_and_headless_invariance():
    a, n = sample()
    _, directions = sample(13, seed=12)
    grid = np.concatenate((directions, -directions))
    ordinary = evaluate_directions(a, n, grid, sigma_pa=0.1)
    a[::2] *= -1
    flipped = evaluate_directions(a, n, grid, sigma_pa=0.1)
    for name in ("Ea", "Eb", "Eab", "Eam"):
        np.testing.assert_allclose(ordinary[name][:13], ordinary[name][13:], atol=1e-15)
        np.testing.assert_allclose(ordinary[name], flipped[name], atol=1e-15)


def test_singular_directions_are_masked_not_false_zero_signal():
    a = [[1, 0, 0], [0, 1, 0]]
    n = [[0, 0, 1], [1, 0, 0]]
    directions = [[0, 0, 1], [2**-0.5, 2**-0.5, 0]]
    result = evaluate_directions(a, n, directions, weights="uniform")
    np.testing.assert_array_equal(result["valid_mask"], [False, True])
    for name in ("Ea", "Eb", "Eab", "Eam"):
        assert np.isnan(result[name][0])
    assert result["Ea"][1] + result["Eb"][1] == pytest.approx(1)
    zero_weight = evaluate_directions(a, n, directions, weights=[0, 1])
    assert zero_weight["valid_mask"][0]
    assert zero_weight["Ea"][0] + zero_weight["Eb"][0] == pytest.approx(1)


def test_changing_both_chunk_sizes_preserves_results():
    a, n = sample()
    one = compute_maps(a, n, weights="uniform", nside=2, gal_chunk=5, direction_chunk=3)
    two = compute_maps(a, n, weights="uniform", nside=2, gal_chunk=100, direction_chunk=100)
    for name in ("Ea", "Eb", "Eab", "Eam"):
        np.testing.assert_allclose(one[name], two[name], atol=2e-14, equal_nan=True)


def test_ring_nested_ordering_and_metadata():
    a, n = sample()
    nested = compute_maps(a, n, sigma_pa=0.1, nside=4, nest=True, half_sky=False)
    ring = compute_maps(a, n, sigma_pa=0.1, nside=4, nest=False, half_sky=False)
    assert nested["ordering"] == "NESTED"
    assert ring["ordering"] == "RING"
    for name in ("Ea", "Eb", "Eab", "Eam"):
        np.testing.assert_allclose(hp.reorder(nested[name], n2r=True), ring[name], atol=2e-14)
    nested_measurement = measurement_from_map(nested["Ea"], nested["c_bar"], nest=True)
    ring_measurement = measurement_from_map(ring["Ea"], ring["c_bar"], nest=False)
    assert axial_separation(nested_measurement["axis"], ring_measurement["axis"]) < 1e-10


def test_half_sky_has_explicit_validity_and_nan_padding():
    a, n = sample()
    result = compute_maps(a, n, weights="uniform", nside=2)
    z = hp.pix2vec(2, np.arange(48), nest=True)[2]
    np.testing.assert_array_equal(result["evaluated_mask"], z >= 0)
    assert not np.any(result["valid_mask"][z < 0])
    assert np.all(np.isnan(result["Ea"][z < 0]))
    assert np.all(np.isfinite(result["Ea"][z >= 0]))


@pytest.mark.parametrize(
    "kwargs",
    [
        {"nside": 0},
        {"nside": 3},
        {"nside": 2.0},
        {"gal_chunk": 0},
        {"direction_chunk": -1},
        {"eps": 0},
        {"half_sky": 1},
    ],
)
def test_invalid_grid_settings(kwargs):
    a, n = sample(2)
    with pytest.raises(ValueError):
        compute_maps(a, n, weights="uniform", **kwargs)


def test_analytic_amplitude_roundtrip_arrays_and_centered_maps():
    theta = np.array([0, 1e-3, 0.01, 0.2, 1.0, np.pi / 2])
    c = np.array([1, 0.8, 0.01, 1, 0.001, 0.6])
    excess = c / np.pi * (theta + 0.5 * np.sin(2 * theta))
    recovered = theta_ia_from_peak(0.5 + excess, c)
    recovered_centered = theta_ia_from_peak(excess, c, centered=True)
    np.testing.assert_allclose(recovered, theta, atol=2e-11)
    np.testing.assert_allclose(recovered_centered, theta, atol=2e-11)


@pytest.mark.parametrize("c", [0.1, 0.2, 0.5, 0.8, 1.0])
def test_exact_inversion_endpoints(c):
    assert theta_ia_from_peak(0.5, c) == 0
    assert theta_ia_from_peak(0.5 + 0.5 * c, c) == np.pi / 2
    assert theta_ia_from_peak(0, c, centered=True) == 0
    assert theta_ia_from_peak(0.5 * c, c, centered=True) == np.pi / 2


@pytest.mark.parametrize(
    "peak,c", [(0.49, 1), (0.9, 0.5), (0.6, 0), (0.6, -1), (0.6, 1.1), (np.nan, 1), (0.6, np.inf)]
)
def test_out_of_domain_inversion_is_never_silently_clipped(peak, c):
    with pytest.raises(ValueError, match="domain"):
        theta_ia_from_peak(peak, c)
    assert np.isnan(theta_ia_from_peak(peak, c, on_invalid="nan"))


def test_mixed_valid_invalid_amplitude_array():
    result = theta_ia_from_peak([0.5, 0.9, 0.6], 0.5, on_invalid="nan")
    assert result[0] == 0
    assert np.isnan(result[1])
    assert 0 < result[2] < np.pi / 2


def test_map_measurement_ignores_bad_pixels_and_canonicalizes_axis():
    field = np.full(48, 0.5)
    field[0], field[1], field[2] = np.nan, np.inf, hp.UNSEEN
    field[45] = 0.6
    result = measurement_from_map(field, 1, nside=2, nest=True)
    assert result["pixel"] == 45
    assert result["axis"][2] >= 0
    assert result["peak_excess"] == pytest.approx(0.1)
    assert result["amplitude_valid"]
    assert result["theta_ia_arcmin"] == pytest.approx(np.rad2deg(result["theta_ia_rad"]) * 60)
    assert result["n_valid_pixels"] == 45


def test_centered_zero_pixels_are_valid():
    field = np.zeros(12)
    mask = np.zeros(12, dtype=bool)
    mask[5] = True
    result = measurement_from_map(field, 1, centered=True, valid_mask=mask)
    assert result["pixel"] == 5
    assert result["theta_ia_rad"] == 0


def test_masked_array_support():
    field = np.ma.array(np.full(12, 0.6), mask=False)
    field[1] = 0.7
    field.mask[1] = True
    result = measurement_from_map(field, 1)
    assert result["pixel"] != 1
    assert result["peak"] == 0.6


def test_masked_integer_centered_map():
    field = np.ma.array(np.zeros(12, dtype=int), mask=False)
    field.mask[0] = True
    result = measurement_from_map(field, 1, centered=True)
    assert result["pixel"] == 1
    assert result["theta_ia_rad"] == 0


def test_invalid_amplitude_keeps_axis_but_flags_status_when_requested():
    field = np.full(12, 0.9)
    result = measurement_from_map(field, 0.5, on_invalid="nan")
    assert not result["amplitude_valid"]
    assert result["amplitude_status"] == "outside_model_domain"
    assert np.isnan(result["theta_ia_rad"])
    assert np.all(np.isfinite(result["axis"]))


@pytest.mark.parametrize(
    "field,kwargs",
    [
        (np.full(12, np.nan), {}),
        (np.zeros(11), {}),
        (np.zeros(12), {"nside": 2}),
        (np.zeros(12), {"valid_mask": [True]}),
        (np.zeros(12), {"valid_mask": np.full(12, np.nan)}),
        (np.zeros((3, 4)), {}),
    ],
)
def test_invalid_map_input(field, kwargs):
    with pytest.raises(ValueError):
        measurement_from_map(field, 1, **kwargs)


@pytest.mark.parametrize("separation", [1.1e-6, 1.5e-6, 3e-6, 1e-4])
def test_nearly_parallel_valid_trial_uses_stable_projection_norm(separation):
    direction = canonical_axis([0.3, 0.4, 0.5])
    tangent = np.cross(direction, [0, 0, 1])
    tangent /= np.linalg.norm(tangent)
    n = direction * np.cos(separation) + tangent * np.sin(separation)
    n /= np.linalg.norm(n)
    a = np.cross(n, direction)
    a /= np.linalg.norm(a)
    result = evaluate_directions(a[None, :], n[None, :], direction[None, :], weights="uniform")
    assert result["valid_mask"][0]
    assert result["Ea"][0] + result["Eb"][0] == pytest.approx(1, abs=5e-15)
    assert result["Ea"][0] < 1e-16
    assert result["Eb"][0] == pytest.approx(1, abs=5e-15)


def test_saturated_injection_kernel_inverse_roundtrip():
    from laia.mock import inject_alignment, uniform_catalog

    direction = canonical_axis([0.23, -0.57, 0.46])
    for seed in range(30):
        catalog = uniform_catalog(500, seed=seed)
        aligned = inject_alignment(catalog["a"], catalog["n"], direction, np.pi / 2)
        result = evaluate_directions(
            aligned, catalog["n"], direction[None, :], weights="uniform", gal_chunk=37
        )
        peak = result["Ea"][0]
        assert result["valid_mask"][0]
        assert abs(peak - 1) < 8e-15
        assert theta_ia_from_peak(peak, 1) == np.pi / 2


@pytest.mark.parametrize("separation", [1e-9, 1e-11])
def test_extremely_near_parallel_injection_remains_valid_estimator_input(separation):
    from laia.mock import inject_alignment

    direction = canonical_axis([0.23, -0.57, 0.46])
    tangent = np.cross(direction, [0, 0, 1])
    tangent /= np.linalg.norm(tangent)
    n = direction * np.cos(separation) + tangent * np.sin(separation)
    n /= np.linalg.norm(n)
    a = np.cross(n, [0, 0, 1])
    a /= np.linalg.norm(a)
    aligned = inject_alignment(a[None, :], n[None, :], direction, np.pi / 2)
    result = compute_maps(aligned, n[None, :], weights="uniform", nside=2)
    assert result["valid_mask"].any()
    np.testing.assert_allclose(
        (result["Ea"] + result["Eb"])[result["valid_mask"]], 1, rtol=0, atol=5e-15
    )


@pytest.mark.parametrize("centered", [True, False])
def test_only_machine_scale_endpoint_roundoff_is_adjusted(centered):
    baseline = 0.0 if centered else 0.5
    upper = baseline + 0.5
    assert theta_ia_from_peak(baseline - 1e-15, 1, centered=centered) == 0
    assert theta_ia_from_peak(baseline + 1e-15, 1, centered=centered) == 0
    assert theta_ia_from_peak(upper - 4e-15, 1, centered=centered) == np.pi / 2
    assert theta_ia_from_peak(upper + 4e-15, 1, centered=centered) == np.pi / 2
    for invalid in (baseline - 1e-12, upper + 1e-12):
        with pytest.raises(ValueError, match="domain"):
            theta_ia_from_peak(invalid, 1, centered=centered)


def test_map_measurement_reports_endpoint_roundoff_adjustment():
    result = measurement_from_map(np.full(12, 1 + 2e-15), 1)
    assert result["amplitude_valid"]
    assert result["amplitude_roundoff_adjusted"]
    assert result["theta_ia_rad"] == np.pi / 2


def test_masked_finite_uncertainty_cannot_receive_large_weight():
    sigma = np.ma.array([0.01, 0.1], mask=[True, False])
    with pytest.raises(ValueError, match="masked"):
        prepare_weights(2, sigma_pa=sigma)
    with pytest.raises(ValueError, match="masked"):
        prepare_weights(2, sigma_pa=sigma, weights="uniform")


def test_masked_finite_numeric_weights_are_rejected():
    weights = np.ma.array([10.0, 1], mask=[True, False])
    with pytest.raises(ValueError, match="masked"):
        prepare_weights(2, weights=weights)


def test_masked_finite_trial_direction_is_rejected():
    a, n = sample(2)
    direction = np.ma.array([[0.0, 0, 1]], mask=[[True, False, False]])
    with pytest.raises(ValueError, match="masked"):
        evaluate_directions(a, n, direction, weights="uniform")


def test_masked_peak_and_attenuation_follow_invalid_policy():
    peaks = np.ma.array([0.6, 0.6], mask=[True, False])
    with pytest.raises(ValueError, match="domain"):
        theta_ia_from_peak(peaks, 1)
    recovered = theta_ia_from_peak(peaks, 1, on_invalid="nan")
    assert np.isnan(recovered[0])
    assert np.isfinite(recovered[1])
    attenuation = np.ma.array([0.9, 0.9], mask=[True, False])
    recovered = theta_ia_from_peak([0.6, 0.6], attenuation, on_invalid="nan")
    assert np.isnan(recovered[0])
    assert np.isfinite(recovered[1])


def test_validity_mask_cannot_itself_have_masked_entries():
    mask = np.ma.array(np.ones(12, dtype=bool), mask=False)
    mask.mask[0] = True
    with pytest.raises(ValueError, match="masked"):
        measurement_from_map(np.full(12, 0.6), 1, valid_mask=mask)


@pytest.mark.parametrize("peak", [1e-15, -1e-25])
def test_small_cbar_does_not_turn_absolute_tolerance_into_physical_clipping(peak):
    with pytest.raises(ValueError, match="domain"):
        theta_ia_from_peak(peak, 1e-16, centered=True)
    assert np.isnan(theta_ia_from_peak(peak, 1e-16, centered=True, on_invalid="nan"))


def test_small_cbar_centered_signal_remains_resolvable():
    c_bar = 1e-16
    theta = 0.3
    contrast = c_bar / np.pi * (theta + 0.5 * np.sin(2 * theta))
    assert theta_ia_from_peak(contrast, c_bar, centered=True) == pytest.approx(theta, abs=2e-14)
    assert theta_ia_from_peak(c_bar / 2, c_bar, centered=True) == np.pi / 2
    assert theta_ia_from_peak(0, c_bar, centered=True) == 0
    tiny_theta = theta_ia_from_peak(1e-25, c_bar, centered=True)
    assert tiny_theta > 0
    assert tiny_theta == pytest.approx(np.pi * 1e-25 / (2 * c_bar), abs=2e-14)


def test_raw_domain_collapsed_by_roundoff_is_explicitly_invalid():
    c_bar = 1e-16
    assert 0.5 + c_bar / 2 == 0.5
    with pytest.raises(ValueError, match="unresolved"):
        theta_ia_from_peak(0.5, c_bar)
    assert np.isnan(theta_ia_from_peak(0.5, c_bar, on_invalid="nan"))


@pytest.mark.parametrize("c_bar", [1.0, 1e-4, 1e-16])
def test_endpoint_roundoff_allowance_scales_with_attenuation(c_bar):
    upper = c_bar / 2
    machine_offset = 4 * np.finfo(float).eps * c_bar
    assert theta_ia_from_peak(upper + machine_offset, c_bar, centered=True) == np.pi / 2
    with pytest.raises(ValueError, match="domain"):
        theta_ia_from_peak(upper + 1e-10 * c_bar, c_bar, centered=True)


def test_raw_roundoff_comparison_does_not_expand_tolerance_by_one_ulp():
    c_bar = 0.01
    upper = 0.5 + c_bar / 2
    just_above = np.nextafter(upper, np.inf)
    assert just_above - upper > 32 * np.finfo(float).eps * c_bar
    with pytest.raises(ValueError, match="domain"):
        theta_ia_from_peak(just_above, c_bar)
