"""Regression tests for explicit baselines and optional complex diagnostics."""

import healpy as hp
import numpy as np
import pytest

from laia.estimator import measurement_from_map
from laia.extras import (
    complex_diagnostic,
    complex_field,
    project_complex_psf,
    project_psf_map,
)


def test_complex_field_is_exact_and_zero_pixels_are_valid():
    a = np.array([0.5, 0.6, 0.0, np.nan])
    b = np.array([0.5, 0.4, 1.0, 0.2])
    cross = np.array([0.0, 0.03, 0.0, 0.0])
    result = complex_field(a, b, cross)
    np.testing.assert_allclose(result[:3], [0j, 0.2 + 0.03j, -1 + 0j])
    assert not np.isfinite(result[3])


def test_complex_field_respects_masked_and_unseen_pixels():
    a = np.ma.array([0.5, 0.6, hp.UNSEEN, 0.55], mask=[0, 1, 0, 0])
    result = complex_field(a, [0.5] * 4, [0.0] * 4)
    assert np.isfinite(result[0]) and np.isfinite(result[3])
    assert not np.isfinite(result[1]) and not np.isfinite(result[2])


def test_complex_diagnostic_reports_separate_dimensionless_amplitude():
    nside = 2
    count = hp.nside2npix(nside)
    a = np.full(count, 0.5)
    b = np.full(count, 0.5)
    cross = np.zeros(count)
    a[20], b[20], cross[20] = 0.65, 0.35, 0.4
    result = complex_diagnostic(dict(Ea=a, Eb=b, Eab=cross, c_bar=0.8, nside=nside, nest=False))
    assert result["pixel"] == 20
    assert result["complex_peak"] == pytest.approx(0.3 + 0.4j)
    assert result["modulus_peak"] == pytest.approx(0.5)
    assert result["A_complex"] == pytest.approx(0.625)
    assert "theta_ia_rad" not in result
    assert result["dec_deg"] >= 0


def test_complex_diagnostic_orderings_describe_same_axis():
    rng = np.random.default_rng(4)
    field = rng.normal(size=48) + 1j * rng.normal(size=48)
    ring = complex_diagnostic(dict(complex_map=field, c_bar=1, nside=2, nest=False))
    nested = complex_diagnostic(
        dict(
            complex_map=hp.reorder(field.real, r2n=True) + 1j * hp.reorder(field.imag, r2n=True),
            c_bar=1,
            nside=2,
            nest=True,
        )
    )
    np.testing.assert_allclose(ring["axis"], nested["axis"], atol=1e-14)
    assert ring["A_complex"] == pytest.approx(nested["A_complex"])


def test_real_projection_matches_known_null_and_psf_decomposition():
    x = np.linspace(-1, 1, 48)
    signal = x * x
    signal -= signal.mean()
    signal -= np.dot(signal, x) / np.dot(x, x) * x
    null = 0.5 + 0.02 * np.sin(np.arange(48))
    observed = 0.5 + 0.07 * signal + 2.0 * 0.03 * x + (null - 0.5)
    psf = 0.5 + 0.03 * x
    raw = project_psf_map(observed, psf, null_mean=null)
    centered = project_psf_map(observed - 0.5, psf - 0.5, null_mean=null - 0.5, centered=True)
    np.testing.assert_allclose(raw["corrected_map"], 0.07 * signal, atol=2e-16)
    np.testing.assert_allclose(raw["corrected_map"], centered["corrected_map"], atol=2e-16)
    assert raw["eta"] == pytest.approx(2)
    assert raw["centered"] is True and raw["null_subtracted"] is True
    assert raw["status"] == "ok"
    assert np.mean(raw["corrected_map"]) == pytest.approx(0, abs=1e-16)
    # Corrected contrast goes directly to the centered inversion.  Restoring
    # 1/2 and selecting raw mode is equivalent; subtracting it twice is not.
    a = measurement_from_map(raw["corrected_map"], 1.0, nest=True, centered=True)
    b = measurement_from_map(raw["corrected_map"] + 0.5, 1.0, nest=True)
    assert a["theta_ia_rad"] == pytest.approx(b["theta_ia_rad"], abs=1e-14)
    assert a["theta_ia_rad"] > 0


def test_constant_psf_template_is_reported_without_regularization():
    observed = np.linspace(0.48, 0.53, 12)
    result = project_psf_map(observed, np.full(12, 0.6))
    assert result["eta"] == 0
    assert not result["fit_applied"]
    assert result["status"] == "constant_template"
    assert result["template_variance"] == 0
    np.testing.assert_allclose(result["corrected_map"], observed - observed.mean())


def test_centered_zero_template_and_values_are_valid():
    result = project_psf_map([0, 0.1, -0.1], [0, 0, 0], centered=True)
    assert np.all(result["valid_mask"])
    np.testing.assert_allclose(result["corrected_map"], [0, 0.1, -0.1])


def test_projection_uses_common_finite_mask_and_does_not_mutate_inputs():
    observed = np.array([0.5, 0.6, np.nan, 0.4, hp.UNSEEN])
    psf = np.array([0.5, 0.55, 0.52, 0.45, 0.7])
    before = observed.copy()
    result = project_psf_map(observed, psf)
    np.testing.assert_array_equal(result["valid_mask"], [True, True, False, True, False])
    np.testing.assert_array_equal(observed, before)
    assert np.all(np.isnan(result["corrected_map"][[2, 4]]))


def test_complex_projection_uses_conjugate_ols():
    rng = np.random.default_rng(31)
    x = rng.normal(size=48) + 1j * rng.normal(size=48)
    x -= x.mean()
    signal = rng.normal(size=48) + 1j * rng.normal(size=48)
    signal -= signal.mean()
    signal -= np.vdot(x, signal) / np.vdot(x, x) * x
    eta = 0.12 - 0.35j
    null = rng.normal(size=48) * 0.01
    y = 3 + 2j + eta * x + signal + null
    result = project_complex_psf(y, x + 2 - 4j, null_mean=null)
    assert result["eta"] == pytest.approx(eta)
    np.testing.assert_allclose(result["corrected_map"], signal, atol=2e-15)
    assert abs(np.vdot(x, result["corrected_map"])) < 1e-13


@pytest.mark.parametrize("invalid", [0, -0.5, 1.01, np.nan])
def test_invalid_cbar_rejected_for_complex_diagnostic(invalid):
    with pytest.raises(ValueError, match="c_bar"):
        complex_diagnostic(dict(complex_map=np.ones(12, complex), c_bar=invalid))


def test_invalid_projection_inputs_raise():
    with pytest.raises(ValueError, match="same shape"):
        project_psf_map([0.5, 0.6], [0.4])
    with pytest.raises(ValueError, match="at least two"):
        project_psf_map([0.5], [0.6])
    with pytest.raises(ValueError, match="boolean"):
        project_psf_map([0.5, 0.6], [0.4, 0.5], valid_mask=[1, 1])
    with pytest.raises(ValueError, match="no common"):
        project_psf_map([np.nan, hp.UNSEEN], [0.4, 0.5])
    with pytest.raises(ValueError, match="real estimator"):
        project_psf_map([0.5 + 0.1j, 0.6], [0.5, 0.6])
