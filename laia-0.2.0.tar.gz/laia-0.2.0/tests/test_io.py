import json

import healpy as hp
import numpy as np
import pytest
from astropy import units as u
from astropy.io import fits
from astropy.table import Table

from laia import compute_maps, generate_mock
from laia.io import (
    json_safe,
    read_catalog,
    read_field,
    read_maps,
    write_bootstrap,
    write_catalog,
    write_field,
    write_maps,
)


def catalog():
    return generate_mock(64, direction=[0, 0, 1], theta_ia_rad=0.1, sigma_pa_rad=0.03, seed=17)


def test_catalog_roundtrip_and_overwrite(tmp_path):
    data = catalog()
    path = tmp_path / "mock.fits"
    write_catalog(path, data["a"], data["n"], sigma_pa=data["sigma_pa"])
    out = read_catalog(path)
    for key in ("a", "n", "sigma_pa"):
        np.testing.assert_allclose(out[key], data[key])
    with pytest.raises(FileExistsError):
        write_catalog(path, data["a"], data["n"])


def test_sigma_units(tmp_path):
    data = catalog()
    path = tmp_path / "degrees.fits"
    write_catalog(path, data["a"], data["n"], sigma_pa=data["sigma_pa"])
    table = Table.read(path)
    table["sigma"] = np.full(len(table), 2.0)
    table["sigma"].unit = u.deg
    table.write(path, overwrite=True)
    np.testing.assert_allclose(read_catalog(path)["sigma_pa"], np.deg2rad(2))


@pytest.mark.parametrize("nest", [True, False])
def test_maps_roundtrip(tmp_path, nest):
    data = catalog()
    maps = compute_maps(data["a"], data["n"], sigma_pa=data["sigma_pa"], nside=2, nest=nest)
    path = tmp_path / "maps.fits"
    write_maps(path, maps)
    out = read_maps(path)
    for key in ("Ea", "Eb", "Eab", "Eam"):
        np.testing.assert_allclose(out[key], maps[key], equal_nan=True)
    assert out["nest"] == nest
    assert out["ordering"] == ("NESTED" if nest else "RING")
    assert out["centered"] is False
    assert out["attenuation_uses_floor"] == maps["attenuation_uses_floor"]
    assert out["c_bar"] == pytest.approx(maps["c_bar"])
    np.testing.assert_array_equal(out["valid_mask"], maps["valid_mask"])
    from_healpy = hp.read_map(str(path), field=0, nest=nest)
    np.testing.assert_allclose(from_healpy[out["valid_mask"]], out["Ea"][out["valid_mask"]])


def test_field_zero_is_valid_and_centered_preserved(tmp_path):
    field = np.zeros(12)
    valid = np.ones(12, bool)
    valid[3] = False
    path = tmp_path / "field.fits"
    write_field(path, field, c_bar=1, centered=True, nest=False, valid_mask=valid)
    out = read_field(path)
    assert out["centered"]
    assert not out["nest"]
    assert np.count_nonzero(out["valid_mask"]) == 11
    assert np.isnan(out["field"][3])


def test_bootstrap_io_keeps_invalid_rows(tmp_path):
    result = {
        "samples": {
            "theta_ia_rad": np.array([0.1, np.nan]),
            "axis": np.array([[1.0, 0, 0], [0.0, 1, 0]]),
            "amplitude_valid": np.array([True, False]),
        },
        "summary": {"invalid_count": 1, "missing": np.nan},
        "metadata": {"seed": 12},
    }
    path = tmp_path / "bootstrap.fits"
    write_bootstrap(path, result)
    with fits.open(path) as hdul:
        assert len(hdul["SAMPLES"].data) == 2
        assert np.isnan(hdul["SAMPLES"].data["theta_ia_rad"][1])
        saved = json.loads(hdul["SUMMARY"].data["JSON"][0])
        assert saved["summary"]["missing"] is None


def test_masked_catalog_rejected(tmp_path):
    data = catalog()
    path = tmp_path / "bad.fits"
    write_catalog(path, data["a"], data["n"], sigma_pa=data["sigma_pa"])
    with fits.open(path, mode="update") as hdul:
        hdul[1].data["sigma"][0] = np.nan
    with pytest.raises(ValueError):
        read_catalog(path)


def test_masked_input_uncertainties_rejected_before_writing(tmp_path):
    data = catalog()
    sigma = np.ma.array(data["sigma_pa"], mask=False)
    sigma.mask[0] = True
    with pytest.raises(ValueError, match="Masked"):
        write_catalog(tmp_path / "bad.fits", data["a"], data["n"], sigma_pa=sigma)


def test_masked_uncertainty_map_rejected_at_catalog_positions(tmp_path):
    data = catalog()
    path = tmp_path / "no_sigma.fits"
    write_catalog(path, data["a"], data["n"])
    sigma_map = np.ma.array(np.full(12, 0.1), mask=False)
    pixel = hp.vec2pix(1, *data["n"][0], nest=True)
    sigma_map.mask[pixel] = True
    with pytest.raises(ValueError, match="uncertainties"):
        read_catalog(path, error_map=sigma_map, error_map_nest=True)


@pytest.mark.parametrize("nest", [True, False])
def test_uncertainty_map_ordering_is_explicit(tmp_path, nest):
    data = catalog()
    path = tmp_path / "no_sigma.fits"
    write_catalog(path, data["a"], data["n"])
    nested = np.linspace(0.01, 0.02, 48)
    supplied = nested if nest else hp.reorder(nested, n2r=True)
    result = read_catalog(path, error_map=supplied, error_map_nest=nest)
    pixels = hp.vec2pix(2, *data["n"].T, nest=True)
    np.testing.assert_allclose(result["sigma_pa"], nested[pixels])


def test_masked_fields_preserve_mask(tmp_path):
    field = np.ma.array(np.zeros(12, dtype=int), mask=False)
    field.mask[2] = True
    path = tmp_path / "masked.fits"
    write_field(path, field, c_bar=1, centered=True)
    result = read_field(path)
    assert not result["valid_mask"][2]
    assert np.isnan(result["field"][2])
    assert result["valid_mask"].sum() == 11


def test_masked_bundle_field_is_not_silently_unmasked(tmp_path):
    data = catalog()
    maps = compute_maps(data["a"], data["n"], sigma_pa=data["sigma_pa"], nside=1, half_sky=False)
    maps["Ea"] = np.ma.array(maps["Ea"], mask=False)
    maps["Ea"].mask[0] = True
    path = tmp_path / "masked_bundle.fits"
    write_maps(path, maps)
    result = read_maps(path)
    assert not result["valid_mask"][0]
    for key in ("Ea", "Eb", "Eab", "Eam"):
        assert np.isnan(result[key][0])


def test_centered_maps_cannot_be_mislabeled_as_raw_bundle(tmp_path):
    data = catalog()
    maps = compute_maps(data["a"], data["n"], sigma_pa=data["sigma_pa"], nside=1)
    maps["centered"] = True
    with pytest.raises(ValueError, match="raw Ea/Eb"):
        write_maps(tmp_path / "bad_bundle.fits", maps)


@pytest.mark.parametrize(
    "key,value,match",
    [
        ("COORDSYS", "G", "equatorial"),
        ("NSIDE", 2, "NSIDE"),
        ("INDXSCHM", "EXPLICIT", "IMPLICIT"),
        ("ORDERING", "UNKNOWN", "ORDERING"),
        ("C_BAR", -1, "C_BAR"),
    ],
)
def test_invalid_field_metadata_rejected(tmp_path, key, value, match):
    path = tmp_path / "bad.fits"
    write_field(path, np.full(12, 0.6), c_bar=1)
    with fits.open(path, mode="update") as hdul:
        hdul[1].header[key] = value
    with pytest.raises(ValueError, match=match):
        read_field(path)


def test_declared_non_equatorial_catalog_rejected(tmp_path):
    data = catalog()
    path = tmp_path / "galactic.fits"
    write_catalog(path, data["a"], data["n"])
    with fits.open(path, mode="update") as hdul:
        hdul[1].header["COORDSYS"] = "G"
    with pytest.raises(ValueError, match="equatorial"):
        read_catalog(path)


def test_legacy_primary_map_remains_readable_without_new_metadata(tmp_path):
    path = tmp_path / "legacy.fits"
    hdu = fits.PrimaryHDU(np.full(12, 0.6))
    hdu.header["ORDERING"] = "NESTED"
    hdu.writeto(path)
    out = read_field(path)
    assert out["nside"] == 1
    assert out["nest"]
    assert out["c_bar"] is None
    assert not out["centered"]
    assert out["valid_mask"].all()


def test_truthy_nan_mask_is_rejected(tmp_path):
    with pytest.raises(ValueError, match="0/1"):
        write_field(tmp_path / "bad.fits", np.ones(12), c_bar=1, valid_mask=np.full(12, np.nan))


def test_corrupted_bundle_mask_values_rejected(tmp_path):
    data = catalog()
    maps = compute_maps(data["a"], data["n"], sigma_pa=data["sigma_pa"], nside=1)
    path = tmp_path / "corrupted.fits"
    write_maps(path, maps)
    with fits.open(path, mode="update") as hdul:
        hdul[1].data["VALID"][0] = 2
    with pytest.raises(ValueError, match="0/1"):
        read_maps(path)


def test_json_safe_scalar_arrays():
    assert json_safe(np.array(3)) == 3
    assert json_safe(np.array(np.nan)) is None
    assert json_safe(np.array(1 + 2j)) == {"real": 1.0, "imag": 2.0}
