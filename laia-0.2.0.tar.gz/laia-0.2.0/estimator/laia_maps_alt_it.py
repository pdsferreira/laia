"""Optional HEALPix refinement using the same validated LAIA kernel.

The historical compute_chi2_for_pixels name denotes E, not chi-square or a
likelihood. This is a grid search, not the full direction-calibration pipeline.
"""

from pathlib import Path

import healpy as hp
import numpy as np
from astropy.table import Table

from laia import (
    compute_maps,
    evaluate_directions,
    theta_ia_from_peak,
    canonical_axis,
    vector_to_radec,
)
from laia.io import read_catalog, write_maps
from estimator.laia_maps import recover_alpha

__all__ = ["recover_alpha", "compute_chi2_for_pixels", "run_estimator_g_rot"]


def compute_chi2_for_pixels(
    nside, pixel_indices, g, n, error_map, chunk_size=4096, *, weights=None
):
    """Compatibility name: dimensionless E at NESTED pixels, not chi-square."""
    pixels = np.asarray(pixel_indices)
    if pixels.dtype.kind not in "iu" or pixels.ndim != 1:
        raise ValueError(
            "pixel_indices must be a one-dimensional integer array, not rounded values."
        )
    pixel_indices = pixels.astype(np.int64)
    if not hp.isnsideok(nside, nest=True) or np.any(
        (pixel_indices < 0) | (pixel_indices >= hp.nside2npix(nside))
    ):
        raise ValueError("Invalid NESTED nside or pixel index.")
    sigma = None
    if error_map is not None:
        error_map = np.asarray(np.ma.asarray(error_map, dtype=float).filled(np.nan))
        sigma = error_map[hp.vec2pix(hp.npix2nside(error_map.size), *np.asarray(n).T, nest=True)]
    directions = np.column_stack(hp.pix2vec(nside, pixel_indices, nest=True))
    return evaluate_directions(
        g, n, directions, sigma_pa=sigma, weights=weights, gal_chunk=chunk_size
    )["Ea"]


def run_estimator_g_rot(
    arquivo_fits,
    error_map=None,
    nside1=32,
    nside2=64,
    nside3=128,
    nside4=None,
    nside5=None,
    chunk_size=4096,
    show_plot=False,
    output_dir="./output_g_rot",
    *,
    weights=None,
    overwrite=False,
):
    """Refine the E maximum over selected NESTED child pixels.

    Each level shares weights, attenuation and estimator. Finer resolution
    improves discretization, not statistical precision. Defaults are modest.
    """
    levels = [v for v in (nside1, nside2, nside3, nside4, nside5) if v is not None]
    if any(not hp.isnsideok(v, nest=True) for v in levels):
        raise ValueError("All levels must be valid NESTED NSIDE values.")
    if any(new <= old or new % old for old, new in zip(levels, levels[1:])):
        raise ValueError("Refinement levels must be strictly increasing multiples.")
    data = read_catalog(arquivo_fits, error_map=error_map, error_map_nest=True)
    common = dict(sigma_pa=data["sigma_pa"], weights=weights, gal_chunk=chunk_size)
    maps = compute_maps(data["a"], data["n"], nside=nside1, **common)
    valid_pixels = np.flatnonzero(maps["valid_mask"])
    best = int(valid_pixels[np.argmax(maps["Ea"][valid_pixels])])
    peak, results, previous = float(maps["Ea"][best]), [], nside1
    for level in levels:
        if level != nside1:
            neighbors = hp.get_all_neighbours(previous, best, nest=True)
            parents = np.unique(np.r_[best, neighbors[neighbors >= 0]])
            factor = (level // previous) ** 2
            candidates = (parents[:, None] * factor + np.arange(factor)).ravel()
            directions = np.column_stack(hp.pix2vec(level, candidates, nest=True))
            values = evaluate_directions(data["a"], data["n"], directions, **common)
            valid = np.flatnonzero(values["valid_mask"])
            if valid.size == 0:
                raise ValueError("No valid projected directions in this level.")
            index = valid[np.argmax(values["Ea"][valid])]
            best, peak = int(candidates[index]), float(values["Ea"][index])
        ra, dec = vector_to_radec(canonical_axis(np.asarray(hp.pix2vec(level, best, nest=True))))
        results.append(
            {
                "nside": level,
                "max_pixel": best,
                "max_value": peak,
                "theta_ia": float(theta_ia_from_peak(peak, maps["c_bar"])),
                "ra_deg": float(ra),
                "dec_deg": float(dec),
            }
        )
        previous = level
    out = Path(output_dir)
    paths = [
        out / f"{Path(arquivo_fits).stem}_maps.fits",
        out / f"{Path(arquivo_fits).stem}_iterative_results.fits",
    ]
    if not overwrite and any(p.exists() for p in paths):
        raise FileExistsError("Refinement output exists; pass overwrite=True explicitly.")
    write_maps(paths[0], maps, overwrite=overwrite)
    Table(rows=results).write(paths[1], overwrite=overwrite)
    if show_plot:
        import matplotlib.pyplot as plt

        hp.mollview(np.where(maps["valid_mask"], maps["Ea"], hp.UNSEEN), nest=True, title="E^a")
        plt.show()
    return maps["Ea"], results


if __name__ == "__main__":
    raise SystemExit(
        "Import run_estimator_g_rot or use examples/quickstart.py; no batch starts automatically."
    )
