"""Import-safe compatibility namespace; use laia for new analyses."""
