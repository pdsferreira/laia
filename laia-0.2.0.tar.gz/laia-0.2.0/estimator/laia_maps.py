"""Import-safe beta compatibility entry points, delegating numerical work to laia.

See docs/migration.md for deliberate safety and convention changes. New analyses
should use the documented array API. No catalog is read or job started on import.
"""

from __future__ import annotations

import argparse
import warnings
from pathlib import Path

import healpy as hp
import numpy as np
from astropy import units as u
from astropy.coordinates import SkyCoord
from astropy.table import Table

from laia import (
    compute_maps,
    measurement_from_map,
    spatial_block_bootstrap,
    theta_ia_from_peak,
    complex_diagnostic,
    project_complex_psf,
    project_psf_map,
)
from laia.io import read_catalog, read_field, read_maps, write_bootstrap, write_field, write_maps
from laia.mock import inject_alignment


def recover_alpha(m, c_bar, *, tol=1e-12, maxiter=4096, eps=1e-9):
    """Legacy name for theta_ia_from_peak (radians), without silent clipping.

    Historical solver keywords remain accepted for call compatibility. The
    shared bracketed solver owns its tolerances. Alpha here is theta_IA, not RA.
    """
    return theta_ia_from_peak(m, c_bar)


def _coordinates(result):
    coord = SkyCoord(result["ra_deg"] * u.deg, result["dec_deg"] * u.deg, frame="icrs")
    return {
        "pix": int(result["pixel"]),
        "ra_deg": float(result["ra_deg"]),
        "dec_deg": float(result["dec_deg"]),
        "l_deg": float(coord.galactic.l.deg),
        "b_deg": float(coord.galactic.b.deg),
    }


def _bundle(Ea, Eb, Eab, Eam, *, nside, c_bar, nest, valid_mask=None):
    arrays = [
        np.asarray(np.ma.asarray(a, dtype=float).filled(np.nan))
        for a in (Ea, Eb, Eab, Eam)
    ]
    if any(a.shape != (hp.nside2npix(nside),) for a in arrays):
        raise ValueError("Every map must have the full HEALPix length for nside.")
    valid = np.logical_and.reduce([np.isfinite(a) & ~hp.mask_bad(a) for a in arrays])
    if valid_mask is None:
        # RAW a/b fields cannot both be zero at a defined projection. Only this
        # joint check supports beta zero-padded hemispheres; individual zeros
        # remain valid. New calls should pass their explicit valid_mask.
        valid &= ~((arrays[0] == 0) & (arrays[1] == 0))
    else:
        if np.shape(valid_mask) != valid.shape:
            raise ValueError("valid_mask must match the maps.")
        valid &= np.asarray(valid_mask, dtype=bool)
    return dict(
        zip(("Ea", "Eb", "Eab", "Eam"), arrays),
        nside=nside,
        nest=nest,
        c_bar=c_bar,
        valid_mask=valid,
    )


def run_estimator_new(
    arquivo_fits,
    error_map=None,
    *,
    nside=32,
    gal_chunk=4096,
    show_plot=False,
    output_dir="./results",
    eps=1e-12,
    sigma_col="sigma",
    half_sky=True,
    nest=True,
    direction_chunk=128,
    weights=None,
    error_map_nest=None,
    overwrite=False,
    sigma_floor_rad=np.deg2rad(1),
    attenuation_uses_floor=True,
):
    """Read a catalog, compute all fields and save standard HEALPix FITS files.

    The Portuguese argument is retained only for compatibility. Catalog sigma
    takes precedence; error-map ordering is explicit. Missing uncertainties
    require weights='uniform' or numerical weights. No overwriting by default.
    """
    if error_map_nest is None:
        error_map_nest = nest
    data = read_catalog(
        arquivo_fits, sigma_col=sigma_col, error_map=error_map, error_map_nest=error_map_nest
    )
    maps = compute_maps(
        data["a"],
        data["n"],
        sigma_pa=data["sigma_pa"],
        weights=weights,
        nside=nside,
        nest=nest,
        half_sky=half_sky,
        eps=eps,
        gal_chunk=gal_chunk,
        direction_chunk=direction_chunk,
        sigma_floor_rad=sigma_floor_rad,
        attenuation_uses_floor=attenuation_uses_floor,
    )
    out, base = Path(output_dir), Path(arquivo_fits).stem
    targets = [out / f"{base}_{name}.fits" for name in ("maps", "Ea", "Eb", "Eab", "Ea_minus_b")]
    stats_path = out / f"{base}_stats.txt"
    if not overwrite and any(p.exists() for p in targets + [stats_path]):
        raise FileExistsError("Output exists; choose another directory or overwrite=True.")
    write_maps(targets[0], maps, overwrite=overwrite)
    for path, key in zip(targets[1:], ("Ea", "Eb", "Eab", "Eam")):
        write_field(
            path,
            maps[key],
            c_bar=maps["c_bar"],
            nest=nest,
            valid_mask=maps["valid_mask"],
            centered=key in ("Eab", "Eam"),
            overwrite=overwrite,
        )
    stats_path.write_text(
        f"C_BAR {maps['c_bar']:.16e}\nN_GAL {len(data['a'])}\nHALFSKY {int(half_sky)}\n",
        encoding="utf-8",
    )
    if show_plot:
        import matplotlib.pyplot as plt

        for key in ("Ea", "Eb", "Eab", "Eam"):
            hp.mollview(np.where(maps["valid_mask"], maps[key], hp.UNSEEN), nest=nest, title=key)
            plt.show()
    return maps


def analyze_dual_and_DIA(Ea, Eb, Eab, Eam, *, nside, c_bar, nest=True, eps=1e-15, valid_mask=None):
    """Two ordinary measurements plus a separate complex diagnostic.

    Historical D_IA/A_IA denote the extra complex axis and modulus/C_bar, not
    the paper's d_IA/theta_IA. Invalid amplitudes return NaN with validity flags.
    """
    maps = _bundle(Ea, Eb, Eab, Eam, nside=nside, c_bar=c_bar, nest=nest, valid_mask=valid_mask)
    ma = measurement_from_map(
        maps["Ea"], c_bar, nside=nside, nest=nest, valid_mask=maps["valid_mask"], on_invalid="nan"
    )
    mb = measurement_from_map(
        maps["Eb"], c_bar, nside=nside, nest=nest, valid_mask=maps["valid_mask"], on_invalid="nan"
    )
    diagnostic = complex_diagnostic(maps)
    result = {
        "d_IA_a": _coordinates(ma),
        "d_IA_b": _coordinates(mb),
        "theta_IA_a_arcmin": ma["theta_ia_arcmin"],
        "theta_IA_b_arcmin": mb["theta_ia_arcmin"],
        "amplitude_valid_a": ma["amplitude_valid"],
        "amplitude_valid_b": mb["amplitude_valid"],
        "D_IA": _coordinates(diagnostic),
        "A_IA": diagnostic["A_complex"],
    }
    for suffix, measurement in (("D", diagnostic), ("da", ma), ("db", mb)):
        pix = measurement["pixel"]
        weight = maps["Ea"][pix] + maps["Eb"][pix]
        result[f"Eam_at_{suffix}"] = float(maps["Eam"][pix])
        result[f"Eam_over_W_at_{suffix}"] = float(maps["Eam"][pix] / weight) if weight else np.nan
    return result


def fit_eta_complex(Eam_obs, Eab_obs, Eam_psf, Eab_psf, *, mask=None, eps=1e-15):
    """Centered complex least-squares coefficient (additional diagnostic)."""
    return project_complex_psf(
        np.ma.asarray(Eam_obs) + 1j * np.ma.asarray(Eab_obs),
        np.ma.asarray(Eam_psf) + 1j * np.ma.asarray(Eab_psf),
        valid_mask=mask,
    )["eta"]


def fit_eta_real_axiswise(E_obs, E_psf, *, mask=None, eps=1e-15):
    """Centered real least-squares coefficient, shared with the public helper."""
    return project_psf_map(E_obs, E_psf, valid_mask=mask)["eta"]


def analyze_with_psf_corrections(
    Ea_obs,
    Eb_obs,
    Eab_obs,
    Ea_psf,
    Eb_psf,
    Eab_psf,
    *,
    nside,
    c_bar,
    nest=True,
    eps=1e-15,
    de_leak_mode="centered",
    baseline_real=0.5,
    baseline_complex=0.0,
    valid_mask=None,
    null_mean_a=None,
    null_mean_b=None,
):
    """Centered estimator-level PSF projection, not the full survey pipeline.

    a/b input maps and optional null means are RAW. Corrected real maps are
    centered contrasts; their inversion uses centered=True, never a second
    subtraction of 1/2. Catalog residualization and null generation are absent.
    """
    if de_leak_mode != "centered" or baseline_real != 0.5 or baseline_complex != 0:
        raise ValueError("Use the centered convention; beta arbitrary-baseline mode was removed.")
    obs = _bundle(
        Ea_obs,
        Eb_obs,
        Eab_obs,
        np.asarray(Ea_obs) - Eb_obs,
        nside=nside,
        c_bar=c_bar,
        nest=nest,
        valid_mask=valid_mask,
    )
    psf = _bundle(
        Ea_psf,
        Eb_psf,
        Eab_psf,
        np.asarray(Ea_psf) - Eb_psf,
        nside=nside,
        c_bar=c_bar,
        nest=nest,
        valid_mask=valid_mask,
    )
    mask = obs["valid_mask"] & psf["valid_mask"]
    ca = project_psf_map(Ea_obs, Ea_psf, null_mean=null_mean_a, valid_mask=mask)
    cb = project_psf_map(Eb_obs, Eb_psf, null_mean=null_mean_b, valid_mask=mask)
    cc = project_complex_psf(
        obs["Eam"] + 1j * obs["Eab"], psf["Eam"] + 1j * psf["Eab"], valid_mask=mask
    )
    ma = measurement_from_map(
        ca["corrected_map"],
        c_bar,
        nside=nside,
        nest=nest,
        valid_mask=ca["valid_mask"],
        centered=True,
        on_invalid="nan",
    )
    mb = measurement_from_map(
        cb["corrected_map"],
        c_bar,
        nside=nside,
        nest=nest,
        valid_mask=cb["valid_mask"],
        centered=True,
        on_invalid="nan",
    )
    # Real-tracer null templates do not define a complex null template.
    c_maps = dict(
        obs,
        Ea=0.5 + cc["corrected_map"].real / 2,
        Eb=0.5 - cc["corrected_map"].real / 2,
        Eam=cc["corrected_map"].real,
        Eab=cc["corrected_map"].imag,
        valid_mask=cc["valid_mask"],
    )
    diagnostic = complex_diagnostic(c_maps)
    return {
        "eta_complex": cc["eta"],
        "eta_a": ca["eta"],
        "eta_b": cb["eta"],
        "d_IA_a": _coordinates(ma),
        "d_IA_b": _coordinates(mb),
        "theta_IA_a_arcmin": ma["theta_ia_arcmin"],
        "theta_IA_b_arcmin": mb["theta_ia_arcmin"],
        "amplitude_valid_a": ma["amplitude_valid"],
        "amplitude_valid_b": mb["amplitude_valid"],
        "D_IA": _coordinates(diagnostic),
        "A_IA": diagnostic["A_complex"],
        "Ea_res_ax": ca["corrected_map"],
        "Eb_res_ax": cb["corrected_map"],
        "Eam_res_ax": ca["corrected_map"] - cb["corrected_map"],
        "Ea_res_c": c_maps["Ea"],
        "Eb_res_c": c_maps["Eb"],
        "Eam_res": c_maps["Eam"],
        "Eab_res": c_maps["Eab"],
        "real_residuals_centered": True,
        "valid_mask": ca["valid_mask"] & cb["valid_mask"],
        "valid_mask_a": ca["valid_mask"],
        "valid_mask_b": cb["valid_mask"],
        "valid_mask_complex": cc["valid_mask"],
        "psf_status_a": ca["status"],
        "psf_status_b": cb["status"],
    }


def _compute_maps_from_arrays(
    a,
    n,
    *,
    sigma_gal=None,
    error_map=None,
    nside=32,
    half_sky=True,
    nest=True,
    gal_chunk=4096,
    eps=1e-12,
    direction_chunk=128,
    weights=None,
):
    """Beta adapter to the shared kernel."""
    if sigma_gal is None and error_map is not None:
        error_map = np.asarray(np.ma.asarray(error_map, dtype=float).filled(np.nan))
        pixel = hp.vec2pix(hp.npix2nside(error_map.size), *np.asarray(n).T, nest=nest)
        sigma_gal = error_map[pixel]
    return compute_maps(
        a,
        n,
        sigma_pa=sigma_gal,
        weights=weights,
        nside=nside,
        half_sky=half_sky,
        nest=nest,
        gal_chunk=gal_chunk,
        direction_chunk=direction_chunk,
        eps=eps,
    )


def _rotate_tangent_toward_dir(a, n, d_hat, theta_rad, eps=1e-12):
    """Compatibility alias for the shared saturated injection."""
    return inject_alignment(a, n, d_hat, theta_rad, eps=eps)


def bootstrap_errors_from_catalog(
    arquivo_fits,
    error_map=None,
    *,
    arquivo_fits_psf=None,
    with_psf=False,
    lensing=False,
    lensing_theta_arcmin=1.0,
    lensing_nside_dir=4096,
    B=1000,
    nside_blocks=8,
    nside_eval=32,
    nest=True,
    half_sky=True,
    outdir="results/boot",
    seed=2025,
    sigma_col="sigma",
    save_residual_maps=False,
    residual_dir=None,
    tracer="a",
    weights=None,
    overwrite=False,
    include_complex=True,
    gal_chunk=4096,
    direction_chunk=128,
    error_map_nest=None,
):
    """Save spatial bootstrap samples for one explicitly chosen tracer.

    The beta lensing flag means a stochastic axial perturbation, not physical
    shear; its amplitude is supplied by the caller, not calibrated here. Every
    draw and validity flag is saved. The optional complex diagnostic is separate.
    """
    if save_residual_maps or residual_dir is not None:
        raise ValueError(
            "Per-draw map dumps are not retained; this bootstrap saves samples and flags."
        )
    if error_map_nest is None:
        error_map_nest = nest
    data = read_catalog(
        arquivo_fits, sigma_col=sigma_col, error_map=error_map, error_map_nest=error_map_nest
    )
    psf_a = None
    if with_psf:
        if arquivo_fits_psf is None:
            raise ValueError("A matched PSF catalog is required with_psf=True.")
        psf = read_catalog(arquivo_fits_psf)
        if psf["n"].shape != data["n"].shape or not np.allclose(
            psf["n"], data["n"], atol=1e-10, rtol=0
        ):
            raise ValueError("PSF and observed catalogs must match row by row in sky position.")
        psf_a = psf["a"]
    if lensing:
        warnings.warn(
            "Legacy lensing adds a stochastic axial rotation, not physical shear.",
            UserWarning,
            stacklevel=2,
        )
    path = Path(outdir) / f"{Path(arquivo_fits).stem}_bootstrap_{tracer}_B{B}.fits"
    if path.exists() and not overwrite:
        raise FileExistsError(f"{path} exists; pass overwrite=True explicitly.")
    result = spatial_block_bootstrap(
        data["a"],
        data["n"],
        sigma_pa=data["sigma_pa"],
        weights=weights,
        tracer=tracer,
        n_resamples=B,
        nside_blocks=nside_blocks,
        nside=nside_eval,
        nest=nest,
        half_sky=half_sky,
        seed=seed,
        psf_a=psf_a,
        include_complex=include_complex,
        gal_chunk=gal_chunk,
        direction_chunk=direction_chunk,
        extra_rotation_rad=np.deg2rad(lensing_theta_arcmin / 60) if lensing else 0,
    )
    return str(write_bootstrap(path, result, overwrite=overwrite))


def _read_saved_bundle(base):
    path = Path(str(base) + "_maps.fits")
    if path.exists():
        return read_maps(path)
    fields = [read_field(str(base) + suffix) for suffix in ("_Ea.fits", "_Eb.fits", "_Eab.fits")]
    if any(f["nest"] != fields[0]["nest"] for f in fields):
        raise ValueError("Stored field ordering differs; reorder explicitly.")
    c_bar = fields[0]["c_bar"]
    if c_bar is None:
        stats = dict(
            line.split()
            for line in Path(str(base) + "_stats.txt").read_text().splitlines()
            if line.strip()
        )
        c_bar = float(stats["C_BAR"])
    Ea, Eb, Eab = [f["field"] for f in fields]
    return _bundle(
        Ea, Eb, Eab, Ea - Eb, nside=fields[0]["nside"], c_bar=c_bar, nest=fields[0]["nest"]
    )


def batch_analyze(
    output_dir,
    *,
    prefix="simulation_d_xyz_t_0_sim_",
    sims=range(10),
    nside_default=32,
    nest=True,
    save_per_sim_fits=True,
    save_summary_fits=True,
    overwrite=False,
):
    """Analyze raw bundles; actual stored metadata overrides historical hints."""
    rows = []
    for j in sims:
        base = Path(output_dir) / f"{prefix}{j}"
        maps = _read_saved_bundle(base)
        result = analyze_dual_and_DIA(
            *(maps[key] for key in ("Ea", "Eb", "Eab", "Eam")),
            nside=maps["nside"],
            c_bar=maps["c_bar"],
            nest=maps["nest"],
            valid_mask=maps["valid_mask"],
        )
        row = {
            "sim": j,
            "C_bar": maps["c_bar"],
            "theta_a_arcmin": result["theta_IA_a_arcmin"],
            "theta_b_arcmin": result["theta_IA_b_arcmin"],
            "A_complex": result["A_IA"],
        }
        for label in ("a", "b"):
            row[f"d{label}_ra_deg"] = result[f"d_IA_{label}"]["ra_deg"]
            row[f"d{label}_dec_deg"] = result[f"d_IA_{label}"]["dec_deg"]
        rows.append(row)
        if save_per_sim_fits:
            Table(rows=[row]).write(str(base) + "_analysis_nopsf.fits", overwrite=overwrite)
    table = Table(rows=rows)
    if save_summary_fits:
        table.write(Path(output_dir) / "summary_IA_nopsf.fits", overwrite=overwrite)
    return table


def main():
    parser = argparse.ArgumentParser(description="Compute LAIA fields from a FITS catalog.")
    parser.add_argument("catalog")
    parser.add_argument("--output", default="results")
    parser.add_argument("--nside", type=int, default=32)
    parser.add_argument("--ring", action="store_true")
    parser.add_argument("--full-sky", action="store_true")
    parser.add_argument("--uniform-weights", action="store_true")
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args()
    run_estimator_new(
        args.catalog,
        nside=args.nside,
        output_dir=args.output,
        nest=not args.ring,
        half_sky=not args.full_sky,
        weights="uniform" if args.uniform_weights else None,
        overwrite=args.overwrite,
    )


if __name__ == "__main__":
    main()
