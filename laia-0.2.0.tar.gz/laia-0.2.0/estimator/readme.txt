Compatibility entry points for the original public beta.

Install from the repository root: python -m pip install -e .
New code should import reusable functions from laia.
See ../README.md and ../docs/migration.md for conventions and migration notes.

Catalog entry point:
  python -m estimator.laia_maps path/to/catalog.fits --output results

The optional iterative module uses the same kernel at every resolution.
Its historical chi2 function name denotes E, not a chi-square statistic.
