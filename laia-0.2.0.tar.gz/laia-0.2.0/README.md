# LAIA — Large-Scale Axial Intrinsic Alignment

Public reference implementation of the **core LAIA estimator**, a **minimal
phenomenological signal injection**, and small reproducible examples. The package
also provides a spatial block bootstrap, estimator-level PSF-template projection,
and optional complex-field diagnostics.

Paper: Pedro da Silveira Ferreira et al.,
[Where Galaxies Point: First Measurement of the Large-Scale Axial Intrinsic Alignment](https://arxiv.org/abs/2511.10005).

![A new cosmic compass](figures_readme/galaxies_compass_v2.jpg)

## Scope: what this release does and does not provide

This is a reusable implementation of the estimator and controlled demonstrations,
**not the complete analysis pipeline used to obtain the paper's measurements**.
It does not include the full catalog preparation and selection, survey-condition
residualization, empirical/cosmological null construction, injection-based
survey calibrations, or significance analysis. Running the quickstart does not
reproduce the DES/SDSS results or their complete error budget.

| Component | Public functionality | Interpretation |
| --- | --- | --- |
| Core estimator | Real fields `Ea`, `Eb`; preferred axial direction; `theta_IA` | The paper's basic orientation statistic and amplitude relation |
| Minimal mocks | Random sky positions/PAs; saturated axial injection; optional PA noise | Controlled toy catalogs, not cosmological or survey-realistic mocks |
| Block bootstrap | Resampling of occupied HEALPix sky blocks, with matched errors/PSF entries | Sampling variability conditional on the supplied catalog and corrections |
| Real PSF projection | Centered, estimator-map template projection; optional supplied mean-null map | One map-level step, not the full catalog/systematics pipeline |
| Complex fields | `(Ea-Eb) + i Eab`, modulus maximum, optional complex projection | Additional diagnostics; their amplitude is **not** `theta_IA` |

Software version: **0.2.0**. Source code:
[github.com/pdsferreira/laia](https://github.com/pdsferreira/laia).
Version DOI: [10.5281/zenodo.24500241](https://doi.org/10.5281/zenodo.24500241).
See [CHANGELOG.md](CHANGELOG.md) for the changes included in this version.

## Installation

From an extracted source archive or a local checkout containing this version,
run the following commands in the directory containing `pyproject.toml`:

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -e ".[plot,dev]"
```

The core dependencies are NumPy, SciPy, Healpy and Astropy. Plotting uses the
optional Matplotlib extra; tests use Pytest. `numexpr` and `tqdm` are no longer
required. Python 3.10 or newer is declared; validation was performed with
Python 3.12. The tested dependency versions and validation results are recorded
in [validation.md](docs/validation.md).

No module reads catalogs, starts simulations or creates files when imported.
The examples below require no private files, DES data or external survey maps.

## Quickstart: generate → inject → estimate → recover

```bash
python examples/quickstart.py --output example_output --plot
python examples/maps_to_measurement.py example_output/maps.fits --field a
```

The quickstart uses 10,000 uniformly distributed objects, a fixed random seed,
an illustrative 10-degree axial injection toward `(RA, Dec) = (60, 30)` degrees,
and 2-degree Gaussian PA noise. **These are pedagogical parameters, not the
paper's measured amplitudes.** It prints the injected/recovered values and the
sign-invariant axis separation. Sampling fluctuations and a finite direction
grid prevent exact recovery.

Outputs are `mock.fits`, `maps.fits`, `recovery.json`, and optionally `Ea.png`.
An existing output is protected; choose another directory or pass `--overwrite`
explicitly. `--noise-deg 0` selects the genuinely noiseless demonstration;
`--ring` exercises RING ordering.

The same calculation in Python is:

```python
import healpy as hp
import numpy as np
from laia import generate_mock, compute_maps, measurement_from_map

mock = generate_mock(
    10_000,
    direction=hp.ang2vec(60.0, 30.0, lonlat=True),
    theta_ia_rad=np.deg2rad(10.0),
    sigma_pa_rad=np.deg2rad(2.0),
    seed=20261123,
)
maps = compute_maps(mock["a"], mock["n"], sigma_pa=mock["sigma_pa"], nside=8)
result = measurement_from_map(
    maps["Ea"], maps["c_bar"],
    nside=maps["nside"], nest=maps["nest"], valid_mask=maps["valid_mask"],
)
print(result["ra_deg"], result["dec_deg"], result["theta_ia_arcmin"])
```

For a noiseless catalog, omit `sigma_pa` and explicitly request
`weights="uniform"`. Omitting both uncertainties and a weighting choice is an
error, not an implicit change to uniform weights in a galaxy analysis.

## Quickstart ensemble: 64 north--south-axis recoveries

```bash
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python examples/quickstart.py --ensemble --output north_pole_output
```

This second quickstart runs **64 independent simulations of 100,000 objects
each**, with a **60-arcmin** saturated axial injection toward the celestial
north--south axis, `d = (0, 0, 1)`. Positions and initial PAs are uniform, with
**no added PA noise**, explicit equal weights and `C_bar=1`. Equal weights are
appropriate for this controlled noiseless example; they do not replace
uncertainty-based weights in a galaxy analysis. The recovery scans the northern
HEALPix direction grid at **NSIDE=32**, without using the known axis to select
or restrict the maximum. The root seed is 20261123; independent child random
streams are recorded for reproducibility.

The command prints progress and saves:

- `realizations.csv`: recovered amplitudes, axes, RA/Dec and seed information;
- `summary.json`: the sample mean and **sample standard deviation (`ddof=1`)**
  of recovered `theta_IA`, with the standard error of the mean reported separately;
- `recovered_axis_counts.fits`: the HEALPix count map of recovered axes;
- `recovered_axes_mollweide.png`: a Mollweide map and markers for those axes;
- `theta_ia_distribution.png`: the recovered-amplitude distribution.

Every axis is mapped to its **northern antipode** by reversing the entire vector
when needed, not by replacing Dec with its absolute value. Thus RA changes by
180 degrees when the antipode is selected. The injected pole has no defined RA;
an arithmetic mean of recovered RAs is not reported. The sky plot is a
distribution of 64 recovery estimates, not a posterior or significance map.

The same example is available as `examples/north_pole_ensemble.py`. To check
the command quickly before the full run:

```bash
python examples/quickstart.py --ensemble --n-simulations 4 --n-objects 1000 --nside 4 --output north_pole_smoke
```

The reduced run checks execution only; it cannot constrain a 60-arcmin signal
with the precision of the full ensemble. Runtime depends on the machine; the
full run evaluates 6.4 million objects over 64 maps. Catalogs are handled one at
a time and are not all retained in memory or written to disk.

A **separate known-axis diagnostic** evaluates the statistic at the injected
north pole. Its columns and summary are explicitly distinguished from the
blind map-maximum recovery. Maximization, finite samples and grid resolution
can shift the mean recovered peak amplitude away from 60 arcmin, so agreement
with the injection is not enforced by clipping or a post-hoc recentering. Neither
distribution is converted into a detection significance.

The full default run is included in
[`examples/reference_north_pole`](examples/reference_north_pole): it recovered
**60.1433 arcmin** on average, with **5.4839 arcmin sample standard deviation**
and **0.6855 arcmin standard error of the mean**. All 64 amplitudes were valid.
These values describe this seeded toy ensemble, not a result from survey data.

## Scientific conventions

### Estimator and amplitude

For tangent unit orientations `u`, unit sightlines `n`, normalized weights,
and a trial unit axis `d`, the real estimator is

$$
\widehat E(\hat d)=\sum_i w_i
\frac{(\hat d\cdot\hat u_i)^2}{1-(\hat d\cdot\hat n_i)^2},
\qquad \sum_i w_i=1.
$$

`compute_maps(a, n, ...)` uses the supplied orientation as `a` and constructs
`b = n × a`. For the **same catalog and weights**, `Ea + Eb = 1` wherever the
projection is defined. These complementary fields are not independent
measurements to combine. This identity does not relate distinct BD/DD catalogs.
In the paper, the BD measurement uses major axes (`Ea`); the DD measurement uses
minor axes (`Eb`). A filament orientation supplied as `a` is analyzed with `Ea`.

Maximize the selected real field and recover the amplitude through

$$
2\theta_{\rm IA}+\sin(2\theta_{\rm IA})
=\frac{2\pi}{\bar C}\left(\widehat E_{\max}-\frac12\right),
\qquad
\bar C=\sum_iw_i e^{-2\sigma_{{\rm PA},i}^2}.
$$

The exponential, trigonometric functions and inversion use **radians**.
`theta_ia_from_peak` returns radians. `measurement_from_map` also reports
`theta_ia_arcmin`. `c_bar` is a PA-error attenuation factor, not a concentration
parameter. For the explicit no-PA-noise/equal-weight case with `sigma_pa=None`,
`c_bar=1`. If zero-valued uncertainties are instead supplied, the preserved
effective-sigma convention still applies its floor unless
`attenuation_uses_floor=False` is selected.

This relation is the saturated-rotation model discussed in the paper's amplitude
appendix. Its positive-amplitude branch is `0 <= theta_IA <= pi/2`. The expected
raw peak must lie between `1/2` and `(1+c_bar)/2`. A finite-sample or corrected
peak can fall outside this model domain: the default raises an informative error;
`on_invalid="nan"` returns a flagged invalid amplitude. No value is silently
clipped into a plausible-looking angle. A narrowly defined endpoint allowance,
`32 * float64_epsilon * c_bar`, handles numerical roundoff only; the measurement
reports `amplitude_roundoff_adjusted` when an endpoint is adjusted. A raw-map
domain that collapses at floating-point precision is rejected. An inferred amplitude is not a detection
significance, and the maximum of a noisy null map is not expected to equal 1/2.

### PA errors and weighting

With `sigma_pa` and no explicit weights, the package uses normalized inverse
variance weights with a default 1-degree floor. Invalid/missing/negative errors
are not turned into high-precision measurements. Zero errors are rejected in
automatic inverse-variance mode; explicit uniform/numerical weights may accompany
nonnegative noise errors.

For compatibility with the beta, `attenuation_uses_floor=True` computes both the
weights and attenuation using the effective floored uncertainties. This is
explicit in the metadata. To apply the floor only to the weights and use the
input physical noise in attenuation, select `attenuation_uses_floor=False`.
The choice is not made silently; it should match the intended error convention.
The defaults do not impose uniform weights on galaxy science measurements.

### Axes, coordinates, map validity and resolution

- Orientations and recovered directions are headless axes: `d` and `-d` are
  equivalent. Compare them with `axial_separation`, not an ordinary vector angle.
- Sky vectors are interpreted in equatorial coordinates. Returned RA/Dec use a
  canonical northern-hemisphere representative. `grid_axis` and `pixel` identify
  the actual selected grid point, which can be its antipode for full-sky maps.
- `sky_to_vectors` defaults to PA measured east of north. The original notebook
  convention is available explicitly as `convention="west_ccw"`; do not mix them.
- `nest=True` means NESTED and `nest=False` means RING throughout computation and
  I/O. Saved ordering is read, never guessed.
- Default half-sky evaluation exploits axial symmetry. Unevaluated or singular
  directions are NaN in memory, not artificial zero signals. FITS files store
  `UNSEEN` plus explicit `VALID` and `EVALUATED` masks.
- A trial direction parallel to a positive-weight object's sightline has an
  undefined tangent projection. The kernel marks that trial invalid. It does not
  assign an artificial zero contribution. See module docstrings for `eps`.
- The recovered maximum is grid-quantized. Increase `nside` and check convergence;
  the optional iterative adapter shares the same kernel. A finer grid does not
  itself increase the statistical precision of the catalog.

## Maps already computed: recover the measurement

```python
from laia.io import read_maps
from laia import measurement_from_map

maps = read_maps("example_output/maps.fits")
measurement = measurement_from_map(
    maps["Eb"], maps["c_bar"],
    nside=maps["nside"], nest=maps["nest"], valid_mask=maps["valid_mask"],
)
```

Choose `Ea` or `Eb` for the tracer being analyzed; no `Eab` is needed for the
ordinary real-map measurement. The example above illustrates reading `Eb`, not
the recovery of the `a`-axis injection used in the quickstart.

The map identifies a grid-maximum axis, but amplitude recovery additionally
requires its relevant `c_bar`. Bundles save it in the FITS header. For a single
legacy map without this metadata, supply it explicitly:

```bash
python examples/maps_to_measurement.py Ea.fits --single --c-bar 0.99 --northern-only
```

`--northern-only` explicitly describes the support of old northern-only,
zero-padded files; do not use it for a different evaluation footprint. A valid
zero is not treated as a missing pixel.

For an already-centered contrast `E_centered = E_raw - 1/2`, call
`measurement_from_map(..., centered=True)`. The API then does **not** subtract
1/2 again. Real PSF-corrected outputs are also centered contrasts.

## Spatial block-bootstrap errors

```bash
python examples/bootstrap_example.py --n-resamples 32
```

This demonstration retains all samples in `example_output/bootstrap.fits`.
The reusable `spatial_block_bootstrap` defaults to 1,000 realizations and
`nside_blocks=8`; the example deliberately uses fewer realizations for speed.

Each draw samples the occupied sky pixels with replacement and includes every
object in each selected block, retaining matched uncertainties, explicit weights
and optional PSF rows. Maps and the selected real-map measurement are recomputed
per draw. Outputs include empirical 15.865/50/84.135 percentiles of `theta_IA`,
Cartesian axis samples, sign-invariant axial spread and validity counts.

These are useful sampling-error estimates, not automatically the paper's full
calibrated uncertainties. Check block-size and direction-grid convergence. Do
not infer zero directional error from repeated maxima on a coarse grid. Inspect
the full axis distribution if it is broad or multimodal. The summary uses
empirical percentiles, not a KDE-derived central value or a null significance.

## Optional PSF projection and complex fields

```bash
python examples/psf_map_example.py
```

`project_psf_map` can subtract a supplied mean-null map and project out a centered
PSF estimator template using covariance/variance regression. It returns a
centered contrast and explicit fit status. It does **not** prepare residualized
galaxy catalogs, generate empirical nulls or perform all survey calibrations.
The inputs must share their ordering, validity region and appropriate sample.

`complex_field` and `complex_diagnostic` retain the extra field
`(Ea-Eb) + 1j*Eab`. The returned `A_complex` is a dimensionless modulus divided
by `c_bar`; it is **not** the paper's angular amplitude. It is kept in an
additional-analysis section, not labeled as an unvalidated replacement for the
real estimator.

The optional bootstrap `extra_rotation_rad` parameter retains a stochastic
axial perturbation of user-supplied amplitude, with zero as its default. This
can represent a separately calibrated orientation-error contribution; it is not
a physical weak-lensing simulator and assumes no survey calibration automatically.

See [extras_and_bootstrap.md](docs/extras_and_bootstrap.md) for complete examples,
definitions and the distinction between map-level projection and the full paper
pipeline.

## Minimal mocks: limitations

The generator draws independent positions/PAs, rotates toward a projected global
axis by `min(original_separation, theta_IA)`, and optionally adds Gaussian PA
noise. All stochastic stages use one controllable NumPy generator.

Full-sky positions are continuously uniform. Optional masks select allowed pixels;
finite positive mask values mean included, not a probability weight. Within that
support, parent-pixel sampling probabilities are proportional to `1+delta`.
Masked positions use equal-area nested subpixel centers
at a documented finite resolution. This does not create realistic spatial or
orientation correlations. Zero overdensity is valid and means uniform density
within the selected mask.

These mocks omit cosmological structure formation, astrophysical evolution,
correlated intrinsic alignments, physical gravitational shear, realistic shape
measurement/PSF systematics and the paper's survey-calibrated selection and null
ensembles. They are suitable for controlled demonstrations and numerical tests,
not a substitute for the paper's validation suite. See
[mock_generation/readme.md](mock_generation/readme.md).

## Catalogs, tests and migration

`laia.io.write_catalog` writes `g_rot_x/y/z`, `n_x/y/z` and optional `sigma` in
radians. `read_catalog` also supports an explicitly ordered uncertainty map.
Use [sample_organizer.ipynb](estimator/sample_organizer.ipynb) for a short,
data-independent RA/Dec/PA-to-vector example.

```bash
python -m pytest -q tests
python -m ruff check laia estimator mock_generation examples tests
python -m build
```

The tests cover geometry, axial symmetries, injection/recovery, uncertainty
validation, amplitude inversion, masks, ordering, FITS roundtrips, random seeds,
block resampling, template projection and import safety. Examples and plotting
are also exercised separately; see [validation record](docs/validation.md).

Useful original entry points remain under `estimator` and `mock_generation`.
They delegate to the shared kernels. Some beta behaviors deliberately changed;
read [migration.md](docs/migration.md) before reusing older scripts or products.

## Citation

If you use LAIA in your research, please cite both the associated scientific
paper and the version of the software used in your analysis:

- Pedro da Silveira Ferreira et al.,
  [Where Galaxies Point: First Measurement of the Large-Scale Axial Intrinsic Alignment](https://arxiv.org/abs/2511.10005).
- LAIA software, version **0.2.0**:
  [doi:10.5281/zenodo.24500241](https://doi.org/10.5281/zenodo.24500241).

Software authorship and citation metadata are provided in
[`CITATION.cff`](CITATION.cff). The paper and software are separate research
outputs; the DOI above identifies the software, not the article.

## License

LAIA is released under the [MIT License](LICENSE).
