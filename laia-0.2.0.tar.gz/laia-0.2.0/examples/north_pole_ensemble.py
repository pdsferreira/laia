"""Recover 64 north-pole injections of 60 arcmin in 100,000-object toy catalogs.

Install the plotting extra and run from the source archive:
    python -m pip install -e '.[plot]'
    python examples/north_pole_ensemble.py --output north_pole_output

Noiseless, uniform full-sky catalogs are the controlled default. This example
does not use private survey data or calculate a detection significance.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from laia.ensemble import run_north_pole_ensemble, validate_ensemble_output, write_ensemble
from laia.io import json_safe


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--n-simulations", "--n-sims", type=int, default=64)
    parser.add_argument("--n-objects", type=int, default=100_000)
    parser.add_argument("--theta-arcmin", type=float, default=60.0)
    parser.add_argument("--noise-deg", type=float, default=0.0)
    parser.add_argument("--nside", type=int, default=32)
    parser.add_argument("--seed", type=int, default=20261123)
    parser.add_argument("--gal-chunk", type=int, default=1000)
    parser.add_argument("--direction-chunk", type=int, default=64)
    parser.add_argument("--output", type=Path, default=Path("north_pole_output"))
    parser.add_argument("--no-plot", "--no-plots", action="store_true")
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args()
    try:
        validate_ensemble_output(args.output, plots=not args.no_plot, overwrite=args.overwrite)
    except (FileExistsError, NotADirectoryError, ImportError) as exc:
        parser.error(str(exc))

    def progress(completed, total, row):
        print(
            f"[{completed:02d}/{total:02d}] theta_IA={row['theta_ia_arcmin']:.3f} arcmin; "
            f"RA={row['ra_deg']:.3f} deg; Dec={row['dec_deg']:.3f} deg",
            flush=True,
        )

    result = run_north_pole_ensemble(
        n_simulations=args.n_simulations,
        n_objects=args.n_objects,
        theta_ia_arcmin=args.theta_arcmin,
        sigma_pa_deg=args.noise_deg,
        nside=args.nside,
        seed=args.seed,
        gal_chunk=args.gal_chunk,
        direction_chunk=args.direction_chunk,
        progress=progress,
    )
    write_ensemble(args.output, result, plots=not args.no_plot, overwrite=args.overwrite)
    print(json.dumps(json_safe(result["summary"]), indent=2, allow_nan=False))
    print(f"Saved ensemble outputs to {args.output}")


if __name__ == "__main__":
    main()
