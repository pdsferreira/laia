"""Generate controlled LAIA signals and recover their directions and amplitudes.

Run from the repository after ``python -m pip install -e '.[plot]'``:
    python examples/quickstart.py --output example_output --plot
    python examples/quickstart.py --ensemble --output north_pole_output
The ensemble defaults to 64 noiseless, full-sky catalogs of 100,000 objects,
with theta_IA=60 arcmin toward the celestial north--south axis.
The illustrative 10-degree injection is not a measurement from the paper.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import healpy as hp
import numpy as np

from laia import compute_maps, generate_mock, measurement_from_map
from laia.io import json_safe, write_catalog, write_maps


def run(
    *,
    n_objects=10000,
    nside=8,
    seed=20261123,
    noise_deg=2.0,
    theta_deg=10.0,
    ra_deg=60.0,
    dec_deg=30.0,
    ring=False,
):
    direction = hp.ang2vec(ra_deg, dec_deg, lonlat=True)
    catalog = generate_mock(
        n_objects,
        direction=direction,
        theta_ia_rad=np.deg2rad(theta_deg),
        sigma_pa_rad=np.deg2rad(noise_deg),
        seed=seed,
    )
    weights = "uniform" if catalog["sigma_pa"] is None else None
    maps = compute_maps(
        catalog["a"],
        catalog["n"],
        sigma_pa=catalog["sigma_pa"],
        weights=weights,
        nside=nside,
        nest=not ring,
        gal_chunk=1000,
        direction_chunk=64,
    )
    measured = measurement_from_map(
        maps["Ea"], maps["c_bar"], nside=nside, nest=maps["nest"], valid_mask=maps["valid_mask"]
    )
    angle = np.rad2deg(np.arccos(np.clip(abs(np.dot(direction, measured["axis"])), 0, 1)))
    report = {
        "purpose": "Illustrative toy recovery; not a paper measurement or detection significance",
        "n_objects": n_objects,
        "nside": nside,
        "nest": not ring,
        "seed": seed,
        "injected": {
            "ra_deg": ra_deg,
            "dec_deg": dec_deg,
            "theta_ia_deg": theta_deg,
            "sigma_pa_deg": noise_deg,
        },
        "recovered": measured,
        "theta_ia_recovered_deg": float(np.rad2deg(measured["theta_ia_rad"])),
        "axis_separation_deg": float(angle),
        "c_bar": maps["c_bar"],
        "max_complement_error": float(np.nanmax(abs(maps["Ea"] + maps["Eb"] - 1))),
    }
    return catalog, maps, report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--ensemble", action="store_true", help="Run the 64-catalog north-pole example.")
    parser.add_argument("--n-simulations", type=int, default=None, help="Ensemble only; default 64.")
    parser.add_argument("--n-objects", type=int, default=None, help="Default 10000, or 100000 in ensemble mode.")
    parser.add_argument("--nside", type=int, default=None, help="Default 8, or 32 in ensemble mode.")
    parser.add_argument("--seed", type=int, default=20261123)
    amplitude = parser.add_mutually_exclusive_group()
    amplitude.add_argument("--theta-deg", type=float, default=None)
    amplitude.add_argument("--theta-arcmin", type=float, default=None)
    parser.add_argument("--noise-deg", type=float, default=None, help="Default 2, or 0 in ensemble mode.")
    parser.add_argument("--ra-deg", type=float, default=None, help="Single-catalog mode only; default 60.")
    parser.add_argument("--dec-deg", type=float, default=None, help="Single-catalog mode only; default 30.")
    parser.add_argument("--ring", action="store_true")
    parser.add_argument("--output", type=Path, default=None)
    plot = parser.add_mutually_exclusive_group()
    plot.add_argument("--plot", dest="plot", action="store_true", default=None)
    plot.add_argument("--no-plots", dest="plot", action="store_false")
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args()

    if args.ensemble:
        if args.ra_deg is not None or args.dec_deg is not None or args.ring:
            parser.error("--ensemble uses the celestial north--south axis and NESTED maps; omit --ra-deg, --dec-deg and --ring.")
        from laia.ensemble import run_north_pole_ensemble, validate_ensemble_output, write_ensemble

        output = args.output or Path("north_pole_output")
        try:
            validate_ensemble_output(
                output, plots=True if args.plot is None else args.plot, overwrite=args.overwrite
            )
        except (FileExistsError, NotADirectoryError, ImportError) as exc:
            parser.error(str(exc))
        theta_arcmin = args.theta_arcmin
        if theta_arcmin is None:
            theta_arcmin = 60.0 if args.theta_deg is None else 60.0 * args.theta_deg

        def progress(completed, total, row):
            print(
                f"[{completed:02d}/{total:02d}] theta_IA={row['theta_ia_arcmin']:.4f} arcmin; "
                f"RA={row['ra_deg']:.3f} deg; Dec={row['dec_deg']:.3f} deg",
                flush=True,
            )

        result = run_north_pole_ensemble(
            n_simulations=64 if args.n_simulations is None else args.n_simulations,
            n_objects=100_000 if args.n_objects is None else args.n_objects,
            nside=32 if args.nside is None else args.nside,
            theta_ia_arcmin=theta_arcmin,
            sigma_pa_deg=0.0 if args.noise_deg is None else args.noise_deg,
            seed=args.seed,
            progress=progress,
        )
        write_ensemble(output, result, plots=True if args.plot is None else args.plot, overwrite=args.overwrite)
        print(json.dumps(json_safe(result["summary"]), indent=2, allow_nan=False))
        return

    if args.n_simulations is not None:
        parser.error("--n-simulations requires --ensemble.")
    args.n_objects = 10000 if args.n_objects is None else args.n_objects
    args.nside = 8 if args.nside is None else args.nside
    args.noise_deg = 2.0 if args.noise_deg is None else args.noise_deg
    args.ra_deg = 60.0 if args.ra_deg is None else args.ra_deg
    args.dec_deg = 30.0 if args.dec_deg is None else args.dec_deg
    if args.theta_deg is None:
        args.theta_deg = 10.0 if args.theta_arcmin is None else args.theta_arcmin / 60.0
    args.output = args.output or Path("example_output")
    args.plot = False if args.plot is None else args.plot
    targets = [args.output / name for name in ("mock.fits", "maps.fits", "recovery.json")]
    if args.plot:
        targets.append(args.output / "Ea.png")
    for path in targets:
        if path.exists() and not args.overwrite:
            parser.error(f"{path} exists. Choose another output or pass --overwrite.")
    catalog, maps, report = run(
        n_objects=args.n_objects,
        nside=args.nside,
        seed=args.seed,
        noise_deg=args.noise_deg,
        theta_deg=args.theta_deg,
        ra_deg=args.ra_deg,
        dec_deg=args.dec_deg,
        ring=args.ring,
    )
    args.output.mkdir(parents=True, exist_ok=True)
    write_catalog(
        targets[0],
        catalog["a"],
        catalog["n"],
        sigma_pa=catalog["sigma_pa"],
        overwrite=args.overwrite,
    )
    write_maps(targets[1], maps, overwrite=args.overwrite)
    encoded = json.dumps(json_safe(report), indent=2, allow_nan=False) + "\n"
    targets[2].write_text(encoded, encoding="utf-8")
    print(encoded)
    if args.plot:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt

        hp.mollview(
            np.where(maps["valid_mask"], maps["Ea"], hp.UNSEEN),
            nest=maps["nest"],
            title=r"Toy LAIA recovery: raw $E^a$ (gray = unevaluated)",
            unit="dimensionless",
        )
        hp.graticule(dpar=30, dmer=60, alpha=0.3)
        hp.projscatter(
            args.ra_deg,
            args.dec_deg,
            lonlat=True,
            marker="o",
            s=90,
            facecolors="none",
            edgecolors="black",
            linewidths=1.6,
            label="Injected axis",
        )
        hp.projscatter(
            report["recovered"]["ra_deg"],
            report["recovered"]["dec_deg"],
            lonlat=True,
            marker="x",
            color="red",
            label="Recovered axis",
        )
        plt.legend(loc="lower left", frameon=True)
        plt.savefig(args.output / "Ea.png", dpi=160, bbox_inches="tight")
        plt.close()


if __name__ == "__main__":
    main()
