"""Recover an axis and theta_IA from an existing map bundle or one FITS field.

Examples:
    python examples/maps_to_measurement.py example_output/maps.fits --field a
    python examples/maps_to_measurement.py Ea.fits --single --c-bar 0.99
For an old zero-padded map, --northern-only declares its actual evaluated support.
"""

import argparse
import json

import healpy as hp
import numpy as np

from laia import measurement_from_map
from laia.io import json_safe, read_field, read_maps


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("path")
    parser.add_argument("--field", choices=("a", "b"), default="a")
    parser.add_argument("--single", action="store_true", help="Read a single field, not a bundle")
    parser.add_argument("--c-bar", type=float, help="Override attenuation metadata explicitly")
    parser.add_argument("--centered", action="store_true", help="Single field contains E-1/2")
    parser.add_argument("--northern-only", action="store_true", help="Explicit legacy support mask")
    args = parser.parse_args()
    if args.single:
        data = read_field(args.path)
        field, c_bar = data["field"], data["c_bar"]
        centered = args.centered or data["centered"]
    else:
        if args.centered:
            parser.error("Bundles contain raw Ea/Eb; --centered applies only to --single.")
        data = read_maps(args.path)
        field, c_bar = data["E" + args.field], data["c_bar"]
        centered = False
    if args.c_bar is not None:
        c_bar = args.c_bar
    if c_bar is None:
        parser.error("C_BAR is absent. Supply the relevant --c-bar; do not assume 1 silently.")
    mask = data["valid_mask"].copy()
    if args.northern_only:
        z = hp.pix2vec(data["nside"], np.arange(len(field)), nest=data["nest"])[2]
        mask &= z >= 0
    result = measurement_from_map(
        field, c_bar, nside=data["nside"], nest=data["nest"], valid_mask=mask, centered=centered
    )
    print(json.dumps(json_safe(result), indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
