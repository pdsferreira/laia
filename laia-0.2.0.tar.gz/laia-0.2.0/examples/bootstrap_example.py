"""Demonstrate occupied-pixel block bootstrap, with optional complex diagnostics.

The small default is a runnable demonstration, not convergence validation.
Increase --n-resamples and check block and direction-grid resolution for science.
"""

import argparse
import json
from pathlib import Path

import healpy as hp
import numpy as np

from laia import generate_mock, spatial_block_bootstrap
from laia.io import json_safe, write_bootstrap


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--n-objects", type=int, default=10000)
    parser.add_argument("--n-resamples", type=int, default=32)
    parser.add_argument("--nside", type=int, default=8)
    parser.add_argument("--nside-blocks", type=int, default=8)
    parser.add_argument("--seed", type=int, default=20261123)
    parser.add_argument("--output", type=Path, default=Path("example_output/bootstrap.fits"))
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args()
    if args.output.exists() and not args.overwrite:
        parser.error("Output exists; select another path or pass --overwrite.")
    catalog = generate_mock(
        args.n_objects,
        direction=hp.ang2vec(60, 30, lonlat=True),
        theta_ia_rad=np.deg2rad(10),
        sigma_pa_rad=np.deg2rad(2),
        seed=args.seed,
    )
    result = spatial_block_bootstrap(
        catalog["a"],
        catalog["n"],
        sigma_pa=catalog["sigma_pa"],
        tracer="a",
        n_resamples=args.n_resamples,
        nside_blocks=args.nside_blocks,
        nside=args.nside,
        seed=args.seed + 1,
        include_complex=True,
        gal_chunk=1000,
        direction_chunk=64,
    )
    write_bootstrap(args.output, result, overwrite=args.overwrite)
    print(json.dumps(json_safe(result["summary"]), indent=2, allow_nan=False))
    print(f"All draws, validity flags and settings saved to {args.output}")
    print("These are empirical bootstrap intervals, not a detection significance.")


if __name__ == "__main__":
    main()
