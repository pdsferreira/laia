"""Demonstrate estimator-level template projection, not a survey PSF pipeline.

A synthetic map-level contaminant is added along a centered PSF template.
Neither this construction nor its fitted coefficient is a physical PSF model.
"""

import json

import healpy as hp
import numpy as np

from laia import compute_maps, generate_mock, measurement_from_map, project_psf_map
from laia.io import json_safe


def main():
    catalog = generate_mock(
        3000,
        direction=hp.ang2vec(60, 30, lonlat=True),
        theta_ia_rad=np.deg2rad(10),
        sigma_pa_rad=np.deg2rad(2),
        seed=42,
    )
    maps = compute_maps(catalog["a"], catalog["n"], sigma_pa=catalog["sigma_pa"], nside=8)
    rng = np.random.default_rng(31415)
    template = 0.5 + rng.normal(0, 0.02, size=len(maps["Ea"]))
    valid = maps["valid_mask"]
    observed = maps["Ea"] + 0.2 * (template - np.mean(template[valid]))
    correction = project_psf_map(observed, template, valid_mask=valid)
    measurement = measurement_from_map(
        correction["corrected_map"],
        maps["c_bar"],
        nside=maps["nside"],
        nest=maps["nest"],
        valid_mask=correction["valid_mask"],
        centered=True,
    )
    print(
        json.dumps(
            json_safe({"fitted_eta": correction["eta"], "measurement": measurement}),
            indent=2,
            allow_nan=False,
        )
    )
    print(
        "The projection removes any component along the template, including chance signal overlap."
    )
    print("It is not a replacement for catalog residualization or empirical-null calibration.")


if __name__ == "__main__":
    main()
