# Minimal LAIA mock generator

The implementation is now in `laia.mock`; `mock_generator.py` preserves the
useful historical entry points as wrappers. Importing either module performs
no catalog I/O, creates no directories and starts no simulations.

From an installed checkout:

```bash
python -m mock_generation.mock_generator --n-objects 10000 --seed 20261123
python -m mock_generation.mock_generator --output toy_catalog.fits
```

The second command writes a catalog with position/orientation vectors and the
`sigma` PA-uncertainty column in **radians**. Existing files are protected unless
`--overwrite` is requested. The default 10-degree signal is deliberately strong
for a compact demonstration; it is not the amplitude measured in the paper.

## Scientific scope

This generator draws independent axial position angles and injects a saturated
rotation toward a fixed sky axis, optionally followed by independent Gaussian
PA noise. It is a minimal phenomenological test of estimator geometry and
signal recovery, not a cosmological simulation or a DES/SDSS emulator. It does
not implement correlated IA, physical weak lensing, realistic observational
selection, survey-calibrated systematics or the paper's full null/inference
pipeline. The historical extra random-axis rotation is not part of this default
example and must not be interpreted as a physical shear simulator.

## Position sampling and reproducibility

- Without maps, sightlines are continuously uniform in solid angle.
- Masks select finite positive pixels; mask magnitudes do not weight counts.
- Masked-array entries in either the mask or overdensity map are excluded;
  masked PA uncertainties at sampled objects are rejected, not imputed.
- `overdensity` (historically `anisotropy_map`) means **delta**. Parent-pixel
  probability is proportional to `1 + delta`; a zero map is valid and uniform.
- Masked positions are equal-area child-pixel centers, at a child NSIDE 256 times
  the parent by default. This explicitly finite-resolution approximation never
  leaves the selected parent. Maps may use RING or NESTED in the modern API;
  historical position-generation wrappers assume NESTED.
- A single `numpy.random.Generator`, or one seed, controls positions, initial
  PAs and PA noise. NumPy's global random state is not used.

## Minimal Python API

```python
import numpy as np
from laia.mock import generate_mock
from laia.estimator import compute_maps

mock = generate_mock(
    10000,
    direction=[0.75, np.sqrt(3) / 4, 0.5],
    theta_ia_rad=np.deg2rad(10),
    sigma_pa_rad=np.deg2rad(2),
    seed=20261123,
)
maps = compute_maps(mock["a"], mock["n"], sigma_pa=mock["sigma_pa"], nside=8)
```

For a truly noiseless mock, `sigma_pa` is `None`; pass `weights="uniform"`
explicitly to the estimator. Do not substitute a fictitious PA uncertainty.
Noiseless uniform weights are a controlled demonstration, not a recommendation
to discard PA weighting in a galaxy analysis.

For a complete simulation-to-measurement example, see
[`examples/quickstart.py`](../examples/quickstart.py).
