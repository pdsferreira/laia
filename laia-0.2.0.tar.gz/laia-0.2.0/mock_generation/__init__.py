"""Legacy mock entry points; new code should import from :mod:`laia.mock`."""
