"""Compatibility entry points for the public minimal LAIA mock generator.

The implementation lives in :mod:`laia.mock`. Importing this module neither
reads files nor starts a simulation. Use the package API for new code, or run
``python -m mock_generation.mock_generator --help`` for a standalone toy.
"""

from __future__ import annotations

import argparse
import operator

import healpy as hp
import numpy as np

from laia.mock import add_pa_noise, generate_mock, inject_alignment, sample_positions


def astrometry_sim(
    n_objects,
    mask=None,
    anisotropy_map=None,
    threads_var=1,
    nside_new_var=None,
    nside_regions2sim=64,
    *,
    rng=None,
    seed=None,
):
    """Legacy NESTED-map wrapper for :func:`laia.mock.sample_positions`.

    ``anisotropy_map`` is **overdensity delta**, with probabilities proportional
    to ``1 + delta``, not a direct density map. Omitted maps now correctly give
    continuous full-sky positions. With maps, the default samples equal-area
    child centers at 256 times the map NSIDE. An explicitly supplied
    ``nside_new_var`` instead specifies the child NSIDE and must be a compatible
    power-of-two refinement. ``threads_var`` and ``nside_regions2sim`` remain
    accepted for source compatibility but do not control this implementation.
    """
    factor = 256
    if nside_new_var is not None and (mask is not None or anisotropy_map is not None):
        source = np.asarray(mask if mask is not None else anisotropy_map)
        parent_nside = hp.npix2nside(source.size)
        try:
            child_nside = operator.index(nside_new_var)
        except TypeError as exc:
            raise ValueError("nside_new_var must be an integer HEALPix NSIDE.") from exc
        if (
            isinstance(nside_new_var, (bool, np.bool_))
            or child_nside < parent_nside
            or child_nside % parent_nside
        ):
            raise ValueError("nside_new_var must be an integer refinement of the map NSIDE.")
        factor = int(child_nside // parent_nside)
    return sample_positions(
        n_objects,
        mask=mask,
        overdensity=anisotropy_map,
        nest=True,
        subpixel_factor=factor,
        rng=rng,
        seed=seed,
    )


def direcoes_g(
    n_gal,
    mask_var=None,
    anisotropy_map_var=None,
    n_threads=16,
    *,
    rng=None,
    seed=None,
):
    """Legacy name: return ``(n, a)`` with independent uniform axial PAs.

    Maps use NESTED ordering, and ``anisotropy_map_var`` is overdensity.
    ``n_threads`` is retained but unused. The supplied random stream controls
    both sightlines and initial PAs, unlike the historical beta driver.
    """
    catalog = generate_mock(
        n_gal,
        direction=[0.0, 0.0, 1.0],
        theta_ia_rad=0.0,
        mask=mask_var,
        overdensity=anisotropy_map_var,
        rng=rng,
        seed=seed,
    )
    return catalog["n"], catalog["a"]


def rotate_tangent_vectors(g, n, d, theta, theta_error_map, nest=True, rng=None):
    """Inject saturated alignment, then independent Gaussian PA errors.

    ``theta`` and the HEALPix error-map values are in radians. Keep the sampled
    error values when passing the mock to a weighted estimator; adding noise
    geometrically does not replace its uncertainty metadata.
    """
    aligned = inject_alignment(g, n, d, theta)
    error_map = np.ma.asarray(theta_error_map, dtype=float)
    if error_map.ndim != 1:
        raise ValueError("theta_error_map must be a one-dimensional HEALPix map.")
    map_nside = hp.npix2nside(error_map.size)
    sightlines = np.asarray(n, dtype=float)
    pixels = hp.vec2pix(map_nside, *sightlines.T, nest=nest)
    return add_pa_noise(aligned, sightlines, error_map[pixels], rng=rng)


def rotate_tangent_vectors_no_error(g, n, d, theta, nest=True, rng=None):
    """Legacy pure-injection wrapper; ``nest`` and ``rng`` are unused.

    No map or randomness enters this operation. This wrapper and the noisy
    version share the same validated injection kernel.
    """
    return inject_alignment(g, n, d, theta)


def _random_unit_vector(rng):
    """Draw one isotropic direction using the caller's generator."""
    return sample_positions(1, rng=rng)[0]


def main(argv=None):
    """Generate one small synthetic catalog, optionally saving it to FITS."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--n-objects", type=int, default=10000)
    parser.add_argument("--ra-deg", type=float, default=60.0)
    parser.add_argument("--dec-deg", type=float, default=30.0)
    parser.add_argument(
        "--theta-deg",
        type=float,
        default=10.0,
        help="Illustrative injected amplitude, not a paper measurement.",
    )
    parser.add_argument("--sigma-deg", type=float, default=2.0)
    parser.add_argument("--seed", type=int, default=20261123)
    parser.add_argument("--output", help="Optional FITS output. No files are written when omitted.")
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args(argv)
    if not np.isfinite(args.dec_deg) or not -90 <= args.dec_deg <= 90:
        parser.error("--dec-deg must lie in [-90, 90].")
    longitude, latitude = np.deg2rad([args.ra_deg, args.dec_deg])
    direction = [
        np.cos(latitude) * np.cos(longitude),
        np.cos(latitude) * np.sin(longitude),
        np.sin(latitude),
    ]
    catalog = generate_mock(
        args.n_objects,
        direction=direction,
        theta_ia_rad=np.deg2rad(args.theta_deg),
        sigma_pa_rad=np.deg2rad(args.sigma_deg),
        seed=args.seed,
    )
    print(f"Generated {args.n_objects} minimal synthetic objects (seed={args.seed}).")
    print(f"Injected theta_IA={args.theta_deg:g} deg; PA noise sigma={args.sigma_deg:g} deg.")
    if args.output:
        from laia.io import write_catalog

        write_catalog(
            args.output,
            catalog["a"],
            catalog["n"],
            sigma_pa=catalog["sigma_pa"],
            overwrite=args.overwrite,
        )
        print(f"Saved catalog: {args.output}")
    else:
        print("No output requested; no files written.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
