# Changelog

## 0.2.0 — prepared release

- Applied the reviewed masked-array corrections in the compatibility adapters
  and direct spatial-block helper; missing data are no longer silently unmasked.
- Added a reproducible 64-by-100000 north--south-axis recovery ensemble with
  60-arcmin injection, sample mean/standard deviation, northern axial folding,
  a HEALPix count map, and Mollweide/amplitude-distribution figures.
- Exposed the same implementation through the quickstart and a standalone
  example; retained the original single-catalog quickstart defaults.
- Kept the optional private verification scripts separate from the public package.
- Updated the README, citation metadata and package URLs with the author-supplied
  software DOI `10.5281/zenodo.24500241`.
- Included an optional short `README_GITHUB.md` for archive-only GitHub hosting;
  the full `README.md` remains the documentation inside the source distribution.
- Rebuilt the source distribution without changes to the numerical implementation.
  No remote publication is performed by this packaging step.
- Applied the author-confirmed MIT license consistently to the source archive,
  citation metadata, package metadata and README files; replaced the earlier
  license-decision placeholder with `LICENSE`.
- Removed the embedded ensemble Mollweide figure from the full README, while
  retaining its generation and bundled reference output. The GitHub landing
  README uses only the introductory cosmic-compass illustration.

## 0.2.0rc1 — review candidate

- Refactored the public beta into a reusable, import-safe `laia` package.
- Kept the real LAIA estimator and saturated axial injection, using shared kernels.
- Added explicit map-to-direction/amplitude recovery and self-contained examples.
- Retained a useful occupied-pixel spatial bootstrap, map-level PSF projection,
  and clearly distinguished complex-field diagnostics.
- Corrected raw/centered inversion, invalid uncertainty handling, physical-domain
  checks, HEALPix ordering/masks and sampler boundary/probability errors.
- Made all stochastic mock stages reproducible from one random generator.
- Added metadata-bearing FITS I/O, two-dimensional chunking and overwrite protection.
- Replaced duplicated notebook workflows with a data-independent geometry example.
- Added numerical, integration and compatibility tests and installation metadata.
- Rewrote the documentation in English with the public scope and mock limitations.
- Retained an optional, explicitly calibrated-by-caller stochastic orientation
  perturbation; did not add a physical lensing simulator or private survey pipeline.
- Prepared citation metadata; license choice, software author list, final version
  tag and Zenodo DOI remain author/release decisions. Nothing has been published.

See `docs/migration.md` for behavior changes and `docs/validation.md` for checks.
