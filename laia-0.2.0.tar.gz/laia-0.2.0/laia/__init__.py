"""Public LAIA estimator and controlled examples, not the full survey pipeline."""

from .estimator import (
    compute_maps,
    evaluate_directions,
    measurement_from_map,
    prepare_weights,
    theta_ia_from_peak,
)
from .geometry import axial_separation, canonical_axis, sky_to_vectors, vector_to_radec
from .mock import add_pa_noise, generate_mock, inject_alignment, sample_positions, uniform_catalog
from .bootstrap import spatial_block_bootstrap
from .extras import complex_diagnostic, complex_field, project_complex_psf, project_psf_map

__version__ = "0.2.0"

__all__ = [
    "compute_maps",
    "evaluate_directions",
    "measurement_from_map",
    "prepare_weights",
    "theta_ia_from_peak",
    "sky_to_vectors",
    "vector_to_radec",
    "canonical_axis",
    "axial_separation",
    "add_pa_noise",
    "generate_mock",
    "inject_alignment",
    "sample_positions",
    "uniform_catalog",
    "spatial_block_bootstrap",
    "complex_diagnostic",
    "complex_field",
    "project_complex_psf",
    "project_psf_map",
]
