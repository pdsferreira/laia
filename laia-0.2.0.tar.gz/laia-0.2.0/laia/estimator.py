"""Core LAIA maps and axial direction/amplitude recovery.

The raw estimator is E(d)=sum_i w_i (d.a_i)^2/[1-(d.n_i)^2], with normalized
weights.  Its isotropic expectation at a predefined direction is one half.
The peak of a finite noisy map is not itself a detection significance.
"""

from __future__ import annotations

import numbers

import healpy as hp
import numpy as np
from scipy.optimize import brentq

from .geometry import canonical_axis, validate_vectors, vector_to_radec

DEFAULT_SIGMA_FLOOR_RAD = np.deg2rad(1.0)
# Scale the endpoint tolerance by C_bar, not by a fixed O(1) raw baseline:
# otherwise an almost completely attenuated signal could be broadly clipped.
# Saturation is ill-conditioned in theta because its first derivative vanishes.
_AMPLITUDE_ENDPOINT_RTOL = 32 * np.finfo(np.float64).eps


def _positive_integer(value, name):
    if isinstance(value, (bool, np.bool_)) or not isinstance(value, numbers.Integral) or value < 1:
        raise ValueError(f"{name} must be a positive integer.")
    return int(value)


def prepare_weights(
    n_objects,
    *,
    sigma_pa=None,
    weights=None,
    sigma_floor_rad=DEFAULT_SIGMA_FLOOR_RAD,
    attenuation_uses_floor=True,
):
    """Build normalized weights and the PA-error attenuation factor C_bar.

    Parameters
    ----------
    n_objects : int
        Number of objects.
    sigma_pa : float or array-like, optional
        Finite nonnegative PA uncertainties in radians.  Inverse-variance mode
        requires strictly positive values; zero is allowed only with explicit
        numeric/uniform weights for known noiseless objects.  A scalar is
        broadcast to all objects.  Missing or invalid errors are never replaced
        by the smallest allowed uncertainty.  For a fully noiseless catalogue,
        omit sigma and explicitly supply ``weights='uniform'`` or numeric weights.
    weights : {'uniform'}, array-like, or None
        None uses inverse-variance weights and requires sigma_pa.  Numeric
        weights must be finite, nonnegative and have a positive total; their
        normalization is handled here.  Explicit weights override inverse
        variance weighting, but sigma_pa still determines the attenuation.
    sigma_floor_rad : float
        Nonnegative floor used in inverse-variance weighting (default 1 degree).
    attenuation_uses_floor : bool
        True preserves the public beta convention: C_bar uses the same floored
        sigma as the weights.  False uses the input physical sigma in
        exp(-2*sigma**2), while retaining the floor for inverse-variance weights.
        This choice is returned as metadata rather than silently changed.

    Returns
    -------
    dict
        ``weights``, ``c_bar``, ``sigma_input``, ``sigma_effective``, ``weighting``,
        ``sigma_floor_rad``, ``attenuation_uses_floor`` and
        ``attenuation_convention``.  If no sigma is supplied, C_bar is exactly 1.
    """
    n_objects = _positive_integer(n_objects, "n_objects")
    if not np.isscalar(sigma_floor_rad) or not np.isfinite(sigma_floor_rad) or sigma_floor_rad < 0:
        raise ValueError("sigma_floor_rad must be a finite nonnegative scalar.")
    if not isinstance(attenuation_uses_floor, (bool, np.bool_)):
        raise ValueError("attenuation_uses_floor must be Boolean.")
    sigma_input = None
    sigma_effective = None
    if sigma_pa is not None:
        if np.any(np.ma.getmaskarray(sigma_pa)):
            raise ValueError("sigma_pa must not contain masked uncertainties.")
        sigma_input = np.asarray(sigma_pa, dtype=float)
        if sigma_input.ndim == 0:
            sigma_input = np.full(n_objects, float(sigma_input))
        elif sigma_input.shape == (n_objects,):
            sigma_input = sigma_input.copy()
        else:
            raise ValueError("sigma_pa must be a scalar or have shape (N,).")
        if not np.all(np.isfinite(sigma_input)) or np.any(sigma_input < 0):
            raise ValueError("sigma_pa must be finite and nonnegative.")
        sigma_effective = np.maximum(sigma_input, sigma_floor_rad)

    if weights is None:
        if sigma_input is None:
            raise ValueError(
                "Provide sigma_pa for inverse-variance weights, or explicitly choose weights='uniform' or numeric weights."
            )
        if np.any(sigma_input == 0):
            raise ValueError(
                "Inverse-variance weighting requires strictly positive sigma_pa; known zero-noise objects require explicit weights."
            )
        # Relative inverse variances avoid overflow for extremely small errors.
        w = (np.min(sigma_effective) / sigma_effective) ** 2
        weighting = "inverse_variance"
    elif isinstance(weights, str):
        if weights != "uniform":
            raise ValueError("The only supported named weighting is 'uniform'.")
        w = np.ones(n_objects, dtype=float)
        weighting = "uniform"
    else:
        if np.any(np.ma.getmaskarray(weights)):
            raise ValueError("Numeric weights must not contain masked values.")
        w = np.asarray(weights, dtype=float)
        if w.shape != (n_objects,):
            raise ValueError("Numeric weights must have shape (N,).")
        if not np.all(np.isfinite(w)) or np.any(w < 0):
            raise ValueError("Numeric weights must be finite and nonnegative.")
        if np.max(w) <= 0:
            raise ValueError("Numeric weights must have a positive total.")
        w = w / np.max(w)
        weighting = "explicit"
    w = w / np.sum(w)
    if sigma_input is None:
        c_bar = 1.0
        attenuation_convention = "noiseless"
    else:
        sigma_attenuation = sigma_effective if attenuation_uses_floor else sigma_input
        # Very large errors may legitimately underflow the attenuation to zero;
        # the maps remain defined, but amplitude inversion will reject C_bar=0.
        with np.errstate(over="ignore", under="ignore"):
            c_bar = float(np.sum(w * np.exp(-2 * sigma_attenuation**2)))
        c_bar = min(1.0, c_bar)
        attenuation_convention = "effective_sigma" if attenuation_uses_floor else "input_sigma"
    return {
        "weights": w,
        "c_bar": c_bar,
        "sigma_input": sigma_input,
        "sigma_effective": sigma_effective,
        "weighting": weighting,
        "sigma_floor_rad": float(sigma_floor_rad),
        "attenuation_uses_floor": bool(attenuation_uses_floor),
        "attenuation_convention": attenuation_convention,
    }


def _weight_metadata(prepared, n_objects):
    sigma = prepared["sigma_effective"]
    sigma_input = prepared["sigma_input"]
    return {
        "c_bar": prepared["c_bar"],
        "n_objects": n_objects,
        "weighting": prepared["weighting"],
        "sigma_floor_rad": prepared["sigma_floor_rad"],
        "attenuation_uses_floor": prepared["attenuation_uses_floor"],
        "attenuation_convention": prepared["attenuation_convention"],
        "sigma_mean_rad": 0.0 if sigma is None else float(np.mean(sigma)),
        "sigma_input_mean_rad": 0.0 if sigma_input is None else float(np.mean(sigma_input)),
    }


def evaluate_directions(
    a,
    n,
    directions,
    *,
    sigma_pa=None,
    weights=None,
    gal_chunk=4096,
    direction_chunk=128,
    sigma_floor_rad=DEFAULT_SIGMA_FLOOR_RAD,
    attenuation_uses_floor=True,
    eps=1e-12,
):
    """Evaluate the single LAIA kernel on arbitrary unit trial directions.

    ``a`` and ``n`` have shape (N, 3); ``directions`` has shape (M, 3).  See
    :func:`prepare_weights` for weights, uncertainty units and attenuation.
    Working matrices are bounded by ``direction_chunk * gal_chunk`` elements.

    The b axis is n cross a.  Eab is twice the weighted product of the two
    normalized projections, and Eam=Ea-Eb.  The latter fields are useful
    additional diagnostics, not alternative definitions of theta_IA.

    A projected trial axis is undefined when 1-(d.n_i)^2 <= eps.  If this occurs
    for any positive-weight object, the whole trial is marked invalid and its
    four outputs are NaN.  No artificial zero contribution or direction-specific
    reweighting is introduced.  Zero-weight objects do not invalidate a trial.
    """
    a, n = validate_vectors(a, n)
    if np.any(np.ma.getmaskarray(directions)):
        raise ValueError("directions must not contain masked values.")
    directions = np.array(directions, dtype=float, copy=True)
    if directions.ndim != 2 or directions.shape[1] != 3 or directions.shape[0] == 0:
        raise ValueError("directions must have nonempty shape (M, 3).")
    if not np.all(np.isfinite(directions)):
        raise ValueError("directions must be finite.")
    norm = np.linalg.norm(directions, axis=1)
    if np.any(np.abs(norm - 1) > 1e-7):
        raise ValueError("directions must be unit vectors.")
    directions /= norm[:, None]
    gal_chunk = _positive_integer(gal_chunk, "gal_chunk")
    direction_chunk = _positive_integer(direction_chunk, "direction_chunk")
    if not np.isscalar(eps) or not np.isfinite(eps) or not 0 < eps < 1:
        raise ValueError("eps must be a finite scalar between 0 and 1.")
    prepared = prepare_weights(
        len(a),
        sigma_pa=sigma_pa,
        weights=weights,
        sigma_floor_rad=sigma_floor_rad,
        attenuation_uses_floor=attenuation_uses_floor,
    )
    positive = prepared["weights"] > 0
    a_active, n_active = a[positive], n[positive]
    b_active = np.cross(n_active, a_active)
    b_active /= np.linalg.norm(b_active, axis=1)[:, None]
    w = prepared["weights"][positive]
    size = len(directions)
    ea, eb, eab = (np.zeros(size, dtype=float) for _ in range(3))
    valid = np.ones(size, dtype=bool)
    for d0 in range(0, size, direction_chunk):
        d1 = min(size, d0 + direction_chunk)
        d = directions[d0:d1]
        for g0 in range(0, len(a_active), gal_chunk):
            g1 = min(len(a_active), g0 + gal_chunk)
            da = d @ a_active[g0:g1].T
            db = d @ b_active[g0:g1].T
            # In an orthonormal tangent basis, these squares sum to
            # 1-(d.n)^2.  This algebraically identical form avoids catastrophic
            # cancellation when the trial axis nearly follows a sightline.
            denominator = da * da + db * db
            singular = denominator <= eps
            valid[d0:d1] &= ~np.any(singular, axis=1)
            denominator[singular] = 1.0  # The complete trial is masked below.
            weighted_inverse = w[g0:g1][None, :] / denominator
            ea[d0:d1] += np.sum(da * da * weighted_inverse, axis=1)
            eb[d0:d1] += np.sum(db * db * weighted_inverse, axis=1)
            eab[d0:d1] += np.sum(2.0 * da * db * weighted_inverse, axis=1)
    for field in (ea, eb, eab):
        field[~valid] = np.nan
    return {
        "Ea": ea,
        "Eb": eb,
        "Eab": eab,
        "Eam": ea - eb,
        "valid_mask": valid,
        "evaluated_mask": np.ones(size, dtype=bool),
        "directions": directions,
        "eps": float(eps),
        **_weight_metadata(prepared, len(a)),
    }


def compute_maps(
    a,
    n,
    *,
    sigma_pa=None,
    weights=None,
    nside=32,
    nest=True,
    half_sky=True,
    gal_chunk=4096,
    direction_chunk=128,
    sigma_floor_rad=DEFAULT_SIGMA_FLOOR_RAD,
    attenuation_uses_floor=True,
    eps=1e-12,
):
    """Build HEALPix Ea, Eb and additional Eab/Eam maps from a catalogue.

    All output maps have length ``12*nside**2``.  By default only northern trial
    directions (including the equator) are evaluated, because LAIA is axial.
    This restricts trial directions, not the catalogue footprint.  Unevaluated
    pixels and singular trials are NaN, not zero; ``evaluated_mask`` and
    ``valid_mask`` distinguish these cases.  ``nest`` consistently controls the
    grid and returned ordering metadata.  Weights/noise follow
    :func:`prepare_weights`, and the kernel is :func:`evaluate_directions`.
    """
    nside = _positive_integer(nside, "nside")
    if not isinstance(nest, (bool, np.bool_)) or not isinstance(half_sky, (bool, np.bool_)):
        raise ValueError("nest and half_sky must be Boolean.")
    if not hp.isnsideok(nside, nest=bool(nest)):
        raise ValueError("Invalid HEALPix nside for the requested ordering.")
    size = hp.nside2npix(nside)
    grid = np.column_stack(hp.pix2vec(nside, np.arange(size), nest=bool(nest)))
    evaluated = grid[:, 2] >= 0 if half_sky else np.ones(size, dtype=bool)
    partial = evaluate_directions(
        a,
        n,
        grid[evaluated],
        sigma_pa=sigma_pa,
        weights=weights,
        gal_chunk=gal_chunk,
        direction_chunk=direction_chunk,
        sigma_floor_rad=sigma_floor_rad,
        attenuation_uses_floor=attenuation_uses_floor,
        eps=eps,
    )
    result = {
        key: value
        for key, value in partial.items()
        if key not in {"Ea", "Eb", "Eab", "Eam", "directions", "valid_mask", "evaluated_mask"}
    }
    for name in ("Ea", "Eb", "Eab", "Eam"):
        result[name] = np.full(size, np.nan)
        result[name][evaluated] = partial[name]
    valid = np.zeros(size, dtype=bool)
    valid[evaluated] = partial["valid_mask"]
    result.update(
        nside=nside,
        nest=bool(nest),
        ordering="NESTED" if nest else "RING",
        half_sky=bool(half_sky),
        valid_mask=valid,
        evaluated_mask=evaluated,
        centered=False,
    )
    return result


def theta_ia_from_peak(peak, c_bar, *, centered=False, on_invalid="raise"):
    """Invert the saturated-injection mean relation to theta_IA in radians.

    For a raw peak m, solve
    ``m = 0.5 + C_bar/pi * (theta + 0.5*sin(2*theta))`` on [0, pi/2].
    Set ``centered=True`` only when ``peak`` is already the contrast above 0.5
    (including an explicitly calibrated centered residual map).  The baseline
    is then zero and is not subtracted again.

    ``peak`` and ``c_bar`` may be broadcast-compatible scalars/arrays.  The raw
    domain is [0.5, 0.5+C_bar/2], with finite 0<C_bar<=1.  An empirical peak can
    fall outside this model domain; it must not silently become a boundary
    estimate.  ``on_invalid='raise'`` raises ValueError; ``'nan'`` returns NaN for
    invalid entries.  Exact endpoints are preserved.  Values within
    ``32*np.finfo(float64).eps*C_bar`` (about 7.1e-15*C_bar in this dimensionless
    statistic) of a model endpoint are rounded to that endpoint, including
    values just outside from summation roundoff.  Thus the allowance is always
    only 64 machine epsilons of the model's C_bar/2 contrast range; it cannot
    swallow a substantial fraction of a strongly attenuated signal's domain.
    Larger domain violations are never clipped.  If the two model endpoints
    round to the same float, inversion is numerically unresolved and follows
    ``on_invalid``; this matters for raw maps with extremely small C_bar, while
    centered contrasts can retain much smaller signals.  The endpoint tolerance
    avoids spurious angular offsets at saturation, where the forward relation
    has zero derivative.  No p-value or significance is computed here.
    """
    if on_invalid not in {"raise", "nan"}:
        raise ValueError("on_invalid must be 'raise' or 'nan'.")
    if not isinstance(centered, (bool, np.bool_)):
        raise ValueError("centered must be Boolean.")
    peak, c_bar = np.broadcast_arrays(
        np.ma.asarray(peak, dtype=float).filled(np.nan),
        np.ma.asarray(c_bar, dtype=float).filled(np.nan),
    )
    baseline = 0.0 if centered else 0.5
    upper = baseline + 0.5 * c_bar
    endpoint_atol = _AMPLITUDE_ENDPOINT_RTOL * c_bar
    # Compare differences directly: forming upper+tol can itself round outward
    # by an entire ULP when tol is smaller than that spacing.
    with np.errstate(invalid="ignore"):
        above_lower = peak - baseline >= -endpoint_atol
        below_upper = peak - upper <= endpoint_atol
    valid = (
        np.isfinite(peak)
        & np.isfinite(c_bar)
        & (c_bar > 0)
        & (c_bar <= 1)
        & (upper > baseline)
        & above_lower
        & below_upper
    )
    if on_invalid == "raise" and not np.all(valid):
        raise ValueError(
            "Peak is outside the amplitude-model domain, its endpoints are numerically unresolved, or C_bar is not finite in (0, 1]."
        )
    result = np.full(peak.shape, np.nan)
    for index in np.ndindex(peak.shape):
        if not valid[index]:
            continue
        value, c = float(peak[index]), float(c_bar[index])
        tolerance = float(endpoint_atol[index])
        lower_distance = abs(value - baseline)
        upper_distance = abs(value - float(upper[index]))
        if value == baseline or (lower_distance <= tolerance and lower_distance < upper_distance):
            result[index] = 0.0
        elif upper_distance <= tolerance:
            result[index] = np.pi / 2
        else:
            target = min(np.pi / 2, np.pi * ((value - baseline) / c))
            result[index] = brentq(
                lambda t: t + 0.5 * np.sin(2 * t) - target,
                0.0,
                np.pi / 2,
                xtol=2e-14,
                rtol=8 * np.finfo(float).eps,
            )
    return float(result) if result.ndim == 0 else result


def measurement_from_map(
    field, c_bar, *, nside=None, nest=True, valid_mask=None, centered=False, on_invalid="raise"
):
    """Recover the axial grid-maximum direction and effective theta_IA.

    Supply one field: Ea for an a-axis analysis, or Eb for a b-axis analysis.
    This function does not average these complementary fields or use the
    complex-field diagnostic.  It ignores NaN/Inf, HEALPix UNSEEN and masked
    entries, while retaining legitimate zero-valued pixels.  An explicit
    ``valid_mask`` is recommended when reading maps from other software.

    ``pixel`` is the selected pixel in the supplied ordering.  ``axis`` and its
    RA/Dec use the canonical northern antipode; ``grid_axis`` preserves the
    pixel's original sign.  The angular result is grid-quantized.  The amplitude
    requires C_bar and obeys :func:`theta_ia_from_peak`; invalid amplitudes are
    explicitly flagged when ``on_invalid='nan'`` is requested.
    """
    values = np.asarray(np.ma.asarray(field, dtype=float).filled(np.nan))
    if values.ndim != 1 or values.size == 0:
        raise ValueError("field must be a nonempty one-dimensional HEALPix map.")
    inferred_nside = hp.npix2nside(values.size)
    if nside is None:
        nside = inferred_nside
    nside = _positive_integer(nside, "nside")
    if nside != inferred_nside or not hp.isnsideok(nside, nest=bool(nest)):
        raise ValueError("nside/order is incompatible with the map length.")
    if not isinstance(nest, (bool, np.bool_)):
        raise ValueError("nest must be Boolean.")
    if np.ndim(c_bar) != 0:
        raise ValueError("measurement_from_map requires a scalar c_bar.")
    c_bar = float(np.ma.asarray(c_bar, dtype=float).filled(np.nan))
    valid = np.isfinite(values) & hp.mask_good(values)
    if valid_mask is not None:
        if np.any(np.ma.getmaskarray(valid_mask)):
            raise ValueError("valid_mask must not itself contain masked entries.")
        mask = np.asarray(valid_mask)
        if mask.shape != values.shape:
            raise ValueError("valid_mask must have the same shape as field.")
        if mask.dtype.kind != "b":
            if not np.all(np.isfinite(mask)) or not np.all((mask == 0) | (mask == 1)):
                raise ValueError("valid_mask must be Boolean or contain only 0/1.")
        valid &= mask.astype(bool)
    if not np.any(valid):
        raise ValueError("The map has no valid trial directions.")
    pixel = int(np.argmax(np.where(valid, values, -np.inf)))
    peak = float(values[pixel])
    theta = theta_ia_from_peak(peak, c_bar, centered=centered, on_invalid=on_invalid)
    grid_axis = np.asarray(hp.pix2vec(nside, pixel, nest=bool(nest)))
    axis = canonical_axis(grid_axis)
    ra, dec = vector_to_radec(axis)
    baseline = 0.0 if centered else 0.5
    endpoint_adjusted = np.isfinite(theta) and (
        (theta == 0.0 and peak != baseline) or (theta == np.pi / 2 and peak != baseline + c_bar / 2)
    )
    return {
        "axis": axis,
        "grid_axis": grid_axis,
        "ra_deg": ra,
        "dec_deg": dec,
        "pixel": pixel,
        "peak": peak,
        "peak_excess": peak if centered else peak - 0.5,
        "theta_ia_rad": float(theta),
        "theta_ia_arcmin": float(np.rad2deg(theta) * 60),
        "amplitude_valid": bool(np.isfinite(theta)),
        "amplitude_status": "ok" if np.isfinite(theta) else "outside_model_domain",
        "amplitude_roundoff_adjusted": bool(endpoint_adjusted),
        "c_bar": float(c_bar),
        "nside": nside,
        "nest": bool(nest),
        "centered": bool(centered),
        "n_valid_pixels": int(np.sum(valid)),
    }
