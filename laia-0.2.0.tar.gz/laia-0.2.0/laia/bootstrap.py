"""Spatial block-bootstrap uncertainty estimates for the public LAIA estimator.

This resamples occupied sky pixels, not independent objects, and keeps every
object's orientation, uncertainty, optional weight and matched PSF entry
together.  It estimates sampling variability conditional on the supplied
catalogue and any fixed correction maps.  It is not a null-hypothesis test or
the full survey-specific uncertainty and calibration pipeline of the paper.
"""

from __future__ import annotations

import warnings

import healpy as hp
import numpy as np

from .estimator import compute_maps, measurement_from_map, prepare_weights
from .extras import (
    _common_maps,
    complex_diagnostic,
    complex_field,
    project_complex_psf,
    project_psf_map,
)
from .geometry import axial_separation, canonical_axis, validate_vectors


_THETA_PERCENTILES = np.array([15.865, 50.0, 84.135])


def _positive_integer(value, name, *, minimum=1):
    if isinstance(value, (bool, np.bool_)) or not np.isscalar(value):
        raise ValueError(f"{name} must be an integer >= {minimum}.")
    if not np.isfinite(value) or int(value) != value or value < minimum:
        raise ValueError(f"{name} must be an integer >= {minimum}.")
    return int(value)


def build_spatial_blocks(n, *, nside_blocks=8, nest=True):
    """Return occupied HEALPix block IDs and the object indices in each block.

    The blocks have equal area, but can have different object counts.  Each
    occupied block, not each object, has equal probability in the bootstrap.
    The catalogue must contain at least two occupied blocks for resampling to
    provide a nontrivial uncertainty estimate.
    """
    if np.any(np.ma.getmaskarray(n)):
        raise ValueError("n must not contain masked sightline values.")
    n = np.asarray(n, dtype=float)
    if n.ndim != 2 or n.shape[1] != 3 or n.shape[0] == 0:
        raise ValueError("n must be a nonempty (N, 3) array.")
    if not np.all(np.isfinite(n)) or not np.allclose(
        np.linalg.norm(n, axis=1), 1.0, rtol=0.0, atol=1e-7
    ):
        raise ValueError("n must contain finite unit vectors.")
    nside_blocks = _positive_integer(nside_blocks, "nside_blocks")
    if not isinstance(nest, (bool, np.bool_)):
        raise ValueError("nest must explicitly be True or False.")
    if not hp.isnsideok(nside_blocks, nest=bool(nest)):
        raise ValueError("Invalid nside_blocks for the HEALPix ordering.")
    pixels = hp.vec2pix(nside_blocks, n[:, 0], n[:, 1], n[:, 2], nest=bool(nest))
    order = np.argsort(pixels, kind="stable")
    block_ids, first = np.unique(pixels[order], return_index=True)
    blocks = list(np.split(order, first[1:]))
    if len(blocks) < 2:
        raise ValueError("Spatial bootstrap requires at least two occupied blocks.")
    return block_ids, blocks


def _estimate(maps, tracer, psf_maps, null_mean):
    field = maps[f"E{tracer}"]
    valid_mask = maps["valid_mask"]
    centered = False
    psf_result = None
    if psf_maps is not None:
        psf_result = project_psf_map(
            field,
            psf_maps[f"E{tracer}"],
            null_mean=null_mean,
            centered=False,
            valid_mask=valid_mask & psf_maps["valid_mask"],
        )
        field = psf_result["corrected_map"]
        valid_mask = psf_result["valid_mask"]
        centered = True
    elif null_mean is not None:
        # Both fields are RAW maps: subtracting their identical isotropic
        # baselines cancels them.  The difference is already a contrast.
        (observed, null), valid_mask = _common_maps(field, null_mean, valid_mask=valid_mask)
        field = np.full(observed.shape, np.nan)
        field[valid_mask] = observed[valid_mask] - null[valid_mask]
        centered = True
    result = measurement_from_map(
        field,
        maps["c_bar"],
        nside=maps["nside"],
        nest=maps["nest"],
        valid_mask=valid_mask,
        centered=centered,
        on_invalid="nan",
    )
    return result, psf_result


def _extra_diagnostic(maps, psf_maps):
    if psf_maps is None:
        return complex_diagnostic(maps), None
    mask = maps["valid_mask"] & psf_maps["valid_mask"]
    observed = complex_field(maps["Ea"], maps["Eb"], maps["Eab"], valid_mask=mask)
    template = complex_field(psf_maps["Ea"], psf_maps["Eb"], psf_maps["Eab"], valid_mask=mask)
    projection = project_complex_psf(observed, template, valid_mask=mask)
    diagnostic = complex_diagnostic(
        {
            "complex_map": projection["corrected_map"],
            "valid_mask": projection["valid_mask"],
            "c_bar": maps["c_bar"],
            "nside": maps["nside"],
            "nest": maps["nest"],
        }
    )
    return diagnostic, projection


def summarize_bootstrap(samples, reference_axis):
    """Summarize empirical amplitudes and axial spread without RA wrap errors.

    The amplitude summary uses empirical 15.865th, 50th and 84.135th
    percentiles, not a KDE median.  Invalid amplitudes remain in ``samples``;
    their number is reported explicitly and only finite valid amplitudes
    enter the percentiles.  Axes are compared with ``acos(abs(dot))`` to the
    full-sample reference axis.  Separation quantiles describe bootstrap
    spread, not a guaranteed frequentist confidence cone.  Repeated maxima
    on a finite grid can produce a zero separation quantile without implying
    zero angular uncertainty; such cases are flagged.  Full axis samples
    should be inspected when the distribution is broad or multimodal.
    """
    theta = np.asarray(samples["theta_ia_rad"], dtype=float)
    axes = np.asarray(samples["axis"], dtype=float)
    if theta.ndim != 1 or axes.shape != (theta.size, 3) or theta.size == 0:
        raise ValueError("Bootstrap samples require theta(B) and axis(B, 3).")
    amplitude_valid = np.asarray(
        samples.get("amplitude_valid", np.isfinite(theta)), dtype=bool
    ).copy()
    if amplitude_valid.shape != theta.shape:
        raise ValueError("amplitude_valid must match the amplitude samples.")
    amplitude_valid &= np.isfinite(theta)
    axis_valid = np.asarray(
        samples.get("axis_valid", np.all(np.isfinite(axes), axis=1)), dtype=bool
    ).copy()
    if axis_valid.shape != theta.shape:
        raise ValueError("axis_valid must match the axis samples.")
    norms = np.linalg.norm(axes, axis=1)
    axis_valid &= np.all(np.isfinite(axes), axis=1) & (norms > 0)
    reference = np.asarray(reference_axis, dtype=float)
    if reference.shape != (3,) or not np.all(np.isfinite(reference)):
        raise ValueError("reference_axis must be a finite nonzero vector.")
    reference_norm = np.linalg.norm(reference)
    if reference_norm == 0:
        raise ValueError("reference_axis must be a finite nonzero vector.")
    reference = canonical_axis(reference / reference_norm)

    quantiles = np.full(3, np.nan)
    if np.any(amplitude_valid):
        quantiles = np.percentile(theta[amplitude_valid], _THETA_PERCENTILES)
    angular_percentiles = np.array([15.865, 50.0, 68.27, 84.135, 95.0])
    angular_quantiles = np.full(angular_percentiles.size, np.nan)
    axial_eigenvalues = np.full(3, np.nan)
    n_unique_axes = 0
    if np.any(axis_valid):
        unit_axes = axes[axis_valid] / norms[axis_valid, None]
        # atan2-based axial_separation is stable even for identical grid axes;
        # acos(dot) can manufacture a ~1e-6 degree spread through roundoff.
        separations = np.asarray(axial_separation(unit_axes, reference))
        angular_quantiles = np.percentile(separations, angular_percentiles)
        dyad = unit_axes.T @ unit_axes / unit_axes.shape[0]
        axial_eigenvalues = np.linalg.eigvalsh(dyad)[::-1]
        n_unique_axes = np.unique(np.round(canonical_axis(unit_axes), decimals=12), axis=0).shape[0]
    n_unique_grid_pixels = None
    most_common_grid_pixel_fraction = None
    if "pixel" in samples:
        pixels = np.asarray(samples["pixel"])
        if pixels.shape != theta.shape:
            raise ValueError("pixel must match the bootstrap sample count.")
        valid_pixels = axis_valid & np.isfinite(pixels) & (pixels >= 0)
        _, pixel_counts = np.unique(pixels[valid_pixels], return_counts=True)
        n_unique_grid_pixels = int(pixel_counts.size)
        if pixel_counts.size:
            most_common_grid_pixel_fraction = float(pixel_counts.max() / pixel_counts.sum())
    grid_limited_spread = bool(np.isfinite(angular_quantiles[2]) and angular_quantiles[2] < 1e-7)

    notes = []
    n_amplitude_valid = int(np.count_nonzero(amplitude_valid))
    n_axis_valid = int(np.count_nonzero(axis_valid))
    if n_amplitude_valid != theta.size:
        notes.append(
            f"{theta.size - n_amplitude_valid} of {theta.size} amplitudes are invalid; "
            "inspect their flags and input/model compatibility before quoting intervals."
        )
    if n_axis_valid != theta.size:
        notes.append(f"{theta.size - n_axis_valid} of {theta.size} axes are invalid.")
    if theta.size < 100:
        notes.append(
            "Fewer than 100 resamples: useful for a smoke test, not stable tail quantiles."
        )
    if np.isfinite(angular_quantiles[3]) and angular_quantiles[3] > 45:
        notes.append(
            "The bootstrap axes are broadly dispersed; inspect the full axial distribution."
        )
    if grid_limited_spread:
        notes.append(
            "The 68.27th-percentile axial spread is unresolved on the finite direction grid. "
            "Repeated grid maxima do not imply zero angular uncertainty; increase the grid "
            "resolution or refine each realization before quoting directional errors."
        )
    return {
        "n_resamples": int(theta.size),
        "n_amplitude_valid": n_amplitude_valid,
        "n_amplitude_invalid": int(theta.size - n_amplitude_valid),
        "n_axis_valid": n_axis_valid,
        "n_unique_axes": int(n_unique_axes),
        "unique_axis_rounding_decimals": 12,
        "n_unique_grid_pixels": n_unique_grid_pixels,
        "most_common_grid_pixel_fraction": most_common_grid_pixel_fraction,
        "direction_spread_grid_limited": grid_limited_spread,
        "theta_percentiles": _THETA_PERCENTILES.tolist(),
        "theta_ia_rad": quantiles.tolist(),
        "theta_ia_arcmin": (np.degrees(quantiles) * 60.0).tolist(),
        "theta_minus_arcmin": float(np.degrees(quantiles[1] - quantiles[0]) * 60),
        "theta_plus_arcmin": float(np.degrees(quantiles[2] - quantiles[1]) * 60),
        "reference_axis": reference.tolist(),
        "axial_separation_percentiles": angular_percentiles.tolist(),
        "axial_separation_deg": angular_quantiles.tolist(),
        "axial_dyad_eigenvalues": axial_eigenvalues.tolist(),
        "warnings": notes,
        "method": "empirical_percentiles; axial spread about the full-sample axis",
    }


def spatial_block_bootstrap(
    a,
    n,
    *,
    sigma_pa=None,
    weights=None,
    tracer="a",
    n_resamples=1000,
    nside_blocks=8,
    nside=32,
    nest=True,
    half_sky=True,
    seed=None,
    psf_a=None,
    null_mean=None,
    include_complex=False,
    extra_rotation_rad=0.0,
    gal_chunk=4096,
    direction_chunk=128,
    sigma_floor_rad=np.deg2rad(1.0),
    attenuation_uses_floor=True,
):
    """Resample occupied sky blocks and remeasure the selected LAIA tracer.

    Each draw selects as many occupied HEALPix blocks as there were originally,
    uniformly with replacement.  All objects in every selected block are
    included; the object count can therefore vary between draws.  ``sigma_pa``,
    explicit weights and matched ``psf_a`` rows follow the same object indices.
    Zero-weight objects are excluded before defining occupied blocks and their
    count is recorded.  Weights are normalized again in every realization.

    ``tracer='a'`` uses the supplied orientation; ``tracer='b'`` uses its
    perpendicular tangent axis.  The two are complementary fields of the
    same catalogue, not independent observations.  Galaxy PA weights follow
    the core estimator's explicit uncertainty/floor convention.

    ``psf_a`` optionally supplies matched PSF orientations, enabling the real
    map-level PSF projection inside every realization.  ``null_mean`` is an
    optional RAW mean-null map of the selected tracer, held fixed across the
    bootstrap.  This conditions the error estimate on that correction; it
    does not propagate the finite null-ensemble uncertainty or refit any
    catalogue-level residualisation.

    ``include_complex=True`` also returns the separate complex-field
    diagnostic, optionally complex-PSF-projected when ``psf_a`` is present.
    A selected real-tracer ``null_mean`` cannot specify a complex null field
    and is NOT applied to that extra diagnostic.

    ``extra_rotation_rad`` optionally adds a saturated axial rotation towards
    an independent isotropic axis in each realization, using the same random
    generator.  It affects observed orientations, not PSF orientations.  The
    paper used this kind of stochastic perturbation to propagate a separately
    calibrated lensing--footprint contribution.  Here its amplitude is supplied
    by the caller, defaults to zero and carries NO automatic survey calibration.
    It is not a physical shear simulation.  The full-sample reference is not
    perturbed; every sampled perturbation axis is returned for inspection.

    Returns a dict with ``reference`` (full-sample measurement), ``samples``
    (arrays retaining every draw and validity flag), ``summary`` (empirical
    percentiles and axial spread), and ``metadata``.  Out-of-domain amplitude
    inversions are flagged NaNs, never clipped or silently discarded.  No
    significance, KDE or survey-specific calibration is inferred by this
    routine.  Increase ``n_resamples``
    and check block-size/resolution stability for a scientific application.
    """
    a, n = validate_vectors(a, n)
    n_resamples = _positive_integer(n_resamples, "n_resamples", minimum=2)
    if tracer not in ("a", "b"):
        raise ValueError("tracer must be 'a' or 'b'.")
    if not isinstance(include_complex, (bool, np.bool_)):
        raise ValueError("include_complex must explicitly be True or False.")
    if (
        not np.isscalar(extra_rotation_rad)
        or not np.isfinite(extra_rotation_rad)
        or not 0 <= extra_rotation_rad <= np.pi / 2
    ):
        raise ValueError("extra_rotation_rad must be finite and lie in [0, pi/2].")
    if extra_rotation_rad > 0:
        from .mock import inject_alignment
    n_input = a.shape[0]
    prepared = prepare_weights(
        n_input,
        sigma_pa=sigma_pa,
        weights=weights,
        sigma_floor_rad=sigma_floor_rad,
        attenuation_uses_floor=attenuation_uses_floor,
    )
    sigma_full = prepared["sigma_input"]
    if psf_a is not None:
        psf_a, _ = validate_vectors(psf_a, n)
    positive = prepared["weights"] > 0
    n_zero_weight = int(np.count_nonzero(~positive))
    a, n = a[positive], n[positive]
    if sigma_full is not None:
        sigma_full = sigma_full[positive]
    if psf_a is not None:
        psf_a = psf_a[positive]
    if weights is not None and not isinstance(weights, str):
        weights = prepared["weights"][positive]

    block_ids, blocks = build_spatial_blocks(n, nside_blocks=nside_blocks, nest=nest)
    n_blocks = len(blocks)
    rng = np.random.default_rng(seed)
    common = {
        "nside": nside,
        "nest": nest,
        "half_sky": half_sky,
        "gal_chunk": gal_chunk,
        "direction_chunk": direction_chunk,
        "sigma_floor_rad": sigma_floor_rad,
        "attenuation_uses_floor": attenuation_uses_floor,
    }

    def evaluate(indices=None, extra_axis=None):
        aa = a if indices is None else a[indices]
        nn = n if indices is None else n[indices]
        if extra_axis is not None:
            aa = inject_alignment(aa, nn, extra_axis, extra_rotation_rad)
        ss = sigma_full if indices is None or sigma_full is None else sigma_full[indices]
        ww = weights
        if indices is not None and ww is not None and not isinstance(ww, str):
            ww = ww[indices]
        maps = compute_maps(aa, nn, sigma_pa=ss, weights=ww, **common)
        psf_maps = None
        if psf_a is not None:
            pp = psf_a if indices is None else psf_a[indices]
            psf_maps = compute_maps(pp, nn, sigma_pa=ss, weights=ww, **common)
        estimate, projection = _estimate(maps, tracer, psf_maps, null_mean)
        diagnostic, complex_projection = (None, None)
        if include_complex:
            diagnostic, complex_projection = _extra_diagnostic(maps, psf_maps)
        return maps["c_bar"], estimate, projection, diagnostic, complex_projection

    reference_cbar, reference, reference_psf, reference_complex, _ = evaluate()
    reference = dict(reference)
    reference["c_bar"] = reference_cbar
    if reference_psf is not None:
        reference["eta_psf"] = float(reference_psf["eta"])
        reference["psf_fit_applied"] = reference_psf["fit_applied"]
    if reference_complex is not None:
        reference["complex_axis"] = reference_complex["axis"].copy()
        reference["A_complex"] = reference_complex["A_complex"]

    real_fields = (
        "ra_deg",
        "dec_deg",
        "peak",
        "peak_excess",
        "theta_ia_rad",
        "theta_ia_arcmin",
        "c_bar",
        "eta_psf",
    )
    samples = {key: np.full(n_resamples, np.nan) for key in real_fields}
    samples["axis"] = np.full((n_resamples, 3), np.nan)
    samples["extra_rotation_axis"] = np.full((n_resamples, 3), np.nan)
    for key in ("pixel", "n_objects", "n_unique_blocks"):
        samples[key] = np.full(n_resamples, -1, dtype=np.int64)
    for key in ("amplitude_valid", "axis_valid", "psf_fit_applied"):
        samples[key] = np.zeros(n_resamples, dtype=bool)
    if include_complex:
        samples["complex_axis"] = np.full((n_resamples, 3), np.nan)
        for key in (
            "complex_ra_deg",
            "complex_dec_deg",
            "complex_peak_real",
            "complex_peak_imag",
            "A_complex",
            "eta_complex_real",
            "eta_complex_imag",
        ):
            samples[key] = np.full(n_resamples, np.nan)
        samples["complex_fit_applied"] = np.zeros(n_resamples, dtype=bool)

    for draw in range(n_resamples):
        choice = rng.integers(0, n_blocks, size=n_blocks)
        indices = np.concatenate([blocks[index] for index in choice])
        extra_axis = None
        if extra_rotation_rad > 0:
            extra_axis = rng.normal(size=3)
            while np.linalg.norm(extra_axis) == 0:
                extra_axis = rng.normal(size=3)
            extra_axis = canonical_axis(extra_axis)
            samples["extra_rotation_axis"][draw] = extra_axis
        c_bar, estimate, projection, diagnostic, complex_projection = evaluate(indices, extra_axis)
        for key in (
            "axis",
            "ra_deg",
            "dec_deg",
            "pixel",
            "peak",
            "peak_excess",
            "theta_ia_rad",
            "theta_ia_arcmin",
            "amplitude_valid",
        ):
            samples[key][draw] = estimate[key]
        samples["axis_valid"][draw] = bool(np.all(np.isfinite(estimate["axis"])))
        samples["c_bar"][draw] = c_bar
        samples["n_objects"][draw] = indices.size
        samples["n_unique_blocks"][draw] = np.unique(choice).size
        if projection is not None:
            samples["eta_psf"][draw] = projection["eta"]
            samples["psf_fit_applied"][draw] = projection["fit_applied"]
        if diagnostic is not None:
            samples["complex_axis"][draw] = diagnostic["axis"]
            samples["complex_ra_deg"][draw] = diagnostic["ra_deg"]
            samples["complex_dec_deg"][draw] = diagnostic["dec_deg"]
            samples["complex_peak_real"][draw] = diagnostic["complex_peak"].real
            samples["complex_peak_imag"][draw] = diagnostic["complex_peak"].imag
            samples["A_complex"][draw] = diagnostic["A_complex"]
        if complex_projection is not None:
            samples["eta_complex_real"][draw] = complex_projection["eta"].real
            samples["eta_complex_imag"][draw] = complex_projection["eta"].imag
            samples["complex_fit_applied"][draw] = complex_projection["fit_applied"]

    summary = summarize_bootstrap(samples, reference["axis"])
    if n_zero_weight:
        summary["warnings"].append(
            f"{n_zero_weight} zero-weight objects were excluded before defining blocks."
        )
    if summary["n_amplitude_invalid"]:
        warnings.warn(summary["warnings"][0], RuntimeWarning, stacklevel=2)
    metadata = {
        "n_input_objects": int(n_input),
        "n_used_objects": int(a.shape[0]),
        "n_zero_weight_excluded": n_zero_weight,
        "n_resamples": n_resamples,
        "nside_blocks": int(nside_blocks),
        "n_occupied_blocks": n_blocks,
        "block_ids": block_ids.tolist(),
        "nside": int(nside),
        "nest": bool(nest),
        "half_sky": bool(half_sky),
        "tracer": tracer,
        "seed": int(seed) if isinstance(seed, (int, np.integer)) else None,
        "rng": "numpy.random.default_rng",
        "psf_projection": psf_a is not None,
        "fixed_null_mean_subtracted": null_mean is not None,
        "include_complex": bool(include_complex),
        "extra_rotation_rad": float(extra_rotation_rad),
        "complex_null_subtracted": False,
        "sigma_floor_rad": float(sigma_floor_rad),
        "attenuation_uses_floor": bool(attenuation_uses_floor),
        "weighting": prepared["weighting"],
        "uncertainty_scope": "sampling variability conditional on supplied catalogue and fixed maps",
    }
    return {"reference": reference, "samples": samples, "summary": summary, "metadata": metadata}
