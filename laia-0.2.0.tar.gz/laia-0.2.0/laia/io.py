"""Explicit FITS I/O for catalogs, HEALPix fields and bootstrap samples.

No file is read or written at import time. Writing requires a destination and
never overwrites an existing file unless ``overwrite=True`` is explicit.
Cartesian vectors and map directions are interpreted in equatorial coordinates.
"""

from __future__ import annotations

import json
import numbers
from pathlib import Path

import healpy as hp
import numpy as np
from astropy import units as u
from astropy.io import fits
from astropy.table import Table

from .geometry import validate_vectors


def _destination(path, overwrite):
    path = Path(path)
    if path.exists() and not overwrite:
        raise FileExistsError(f"{path} exists; pass overwrite=True to replace it.")
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def _sigma_array(sigma, size):
    if np.any(np.ma.getmaskarray(sigma)):
        raise ValueError("Masked PA uncertainties must be removed explicitly.")
    sigma = np.broadcast_to(np.asarray(sigma, dtype=float), (size,)).copy()
    if np.any(~np.isfinite(sigma)) or np.any(sigma < 0):
        raise ValueError("PA uncertainties must be finite, non-negative radians.")
    return sigma


def _binary_mask(mask, shape, name="valid_mask"):
    """Accept Boolean or explicit 0/1 masks, never truthy missing values."""
    if np.any(np.ma.getmaskarray(mask)):
        raise ValueError(f"{name} must not contain masked values.")
    mask = np.asarray(mask)
    if mask.shape != shape:
        raise ValueError(f"{name} must match the field shape.")
    if mask.dtype.kind != "b":
        if not np.all(np.isfinite(mask)) or not np.all((mask == 0) | (mask == 1)):
            raise ValueError(f"{name} must be Boolean or contain only finite 0/1 values.")
    return mask.astype(bool)


def _boolean(value, name):
    if not isinstance(value, (bool, np.bool_)):
        raise ValueError(f"{name} must be Boolean.")
    return bool(value)


def _equatorial_header(header):
    """Unlabelled beta files are equatorial; declared other frames are not."""
    if str(header.get("COORDSYS", "C")).strip().upper() != "C":
        raise ValueError(
            "This API reports equatorial coordinates; transform non-equatorial data first."
        )


def _full_map_header(header, size):
    """Validate frame, full-sky indexing, ordering and optional NSIDE metadata."""
    _equatorial_header(header)
    if str(header.get("INDXSCHM", "IMPLICIT")).strip().upper() != "IMPLICIT":
        raise ValueError(
            "Only full-length IMPLICIT HEALPix maps are supported, not explicit-index partial maps."
        )
    order = str(header.get("ORDERING", "")).strip().upper()
    if order not in ("NESTED", "RING"):
        raise ValueError("The map must declare its ORDERING; do not guess it.")
    nside = hp.npix2nside(size)
    recorded = header.get("NSIDE", nside)
    if (
        isinstance(recorded, (bool, np.bool_))
        or not isinstance(recorded, numbers.Integral)
        or recorded != nside
    ):
        raise ValueError("NSIDE header does not match map length.")
    if not hp.isnsideok(nside, nest=order == "NESTED"):
        raise ValueError("NSIDE is invalid for the declared HEALPix ordering.")
    return nside, order


def write_catalog(path, a, n, *, sigma_pa=None, overwrite=False):
    """Write tangent vectors and sightlines; optional ``sigma`` has unit radian."""
    a, n = validate_vectors(a, n)
    table = Table()
    for j, suffix in enumerate("xyz"):
        table[f"g_rot_{suffix}"] = a[:, j]
        table[f"n_{suffix}"] = n[:, j]
    if sigma_pa is not None:
        table["sigma"] = _sigma_array(sigma_pa, len(a))
        table["sigma"].unit = u.rad
    table.meta["COORDSYS"] = "C"
    table.meta["ORIENT"] = "AXIAL"
    path = _destination(path, overwrite)
    table.write(path, format="fits", overwrite=overwrite)
    return path


def read_catalog(path, *, sigma_col="sigma", error_map=None, error_map_nest=True):
    """Read the public vector schema, with explicit uncertainty-map ordering.

    A catalog uncertainty column takes precedence over ``error_map``. Columns
    with an angular unit are converted to radians; an unlabelled legacy column
    is assumed to contain radians. Missing uncertainty metadata is returned as
    ``None``; the estimator then requires an explicit weighting choice.
    """
    error_map_nest = _boolean(error_map_nest, "error_map_nest")
    table = Table.read(path, format="fits")
    _equatorial_header(table.meta)
    required = [f"{prefix}_{s}" for prefix in ("g_rot", "n") for s in "xyz"]
    missing = set(required).difference(table.colnames)
    if missing:
        raise ValueError(f"Missing catalog columns: {sorted(missing)}")
    if any(np.any(np.ma.getmaskarray(table[name])) for name in required):
        raise ValueError("Masked orientation or sightline values must be removed explicitly.")
    a = np.column_stack([table[f"g_rot_{s}"] for s in "xyz"])
    n = np.column_stack([table[f"n_{s}"] for s in "xyz"])
    a, n = validate_vectors(a, n)
    sigma = None
    if sigma_col in table.colnames:
        column = table[sigma_col]
        if np.any(np.ma.getmaskarray(column)):
            raise ValueError("Masked PA uncertainties must be removed explicitly.")
        sigma = column.quantity.to_value(u.rad) if column.unit is not None else column
        sigma = _sigma_array(sigma, len(a))
    elif error_map is not None:
        error_map = np.asarray(np.ma.asarray(error_map, dtype=float).filled(np.nan))
        if error_map.ndim != 1 or not hp.isnpixok(error_map.size):
            raise ValueError("error_map must be a one-dimensional full HEALPix map.")
        pixels = hp.vec2pix(hp.npix2nside(error_map.size), *n.T, nest=error_map_nest)
        sigma = _sigma_array(error_map[pixels], len(a))
        if np.any(hp.mask_bad(sigma)):
            raise ValueError("The uncertainty map has UNSEEN values at catalog positions.")
    return {"a": a, "n": n, "sigma_pa": sigma}


def _field_valid(field, valid_mask=None):
    field = np.asarray(np.ma.asarray(field, dtype=float).filled(np.nan)).copy()
    if field.ndim != 1 or not hp.isnpixok(field.size):
        raise ValueError("A field must be a one-dimensional full-length HEALPix array.")
    valid = np.isfinite(field) & ~hp.mask_bad(field)
    if valid_mask is not None:
        valid &= _binary_mask(valid_mask, field.shape)
    return field, valid


def write_maps(path, maps, *, overwrite=False):
    """Write E_a, E_b, E_ab, E_a-minus-b plus explicit validity/evaluation masks.

    The first four columns are estimator fields, not CMB Stokes components.
    ``C_BAR``, ordering, raw-map convention and weight/attenuation settings are
    stored in the header. ``healpy.read_map(path, field=0, nest=...)`` can read E_a.
    """
    if _boolean(maps.get("centered", False), "centered"):
        raise ValueError(
            "write_maps expects raw Ea/Eb; use write_field(centered=True) for centered contrasts."
        )
    nest = _boolean(maps["nest"], "nest")
    fields = [
        np.asarray(np.ma.asarray(maps[key], dtype=float).filled(np.nan))
        for key in ("Ea", "Eb", "Eab", "Eam")
    ]
    _, valid = _field_valid(fields[0], maps.get("valid_mask"))
    for field in fields[1:]:
        if field.shape != fields[0].shape:
            raise ValueError("All estimator maps must have the same shape.")
        _, ok = _field_valid(field)
        valid &= ok
    nside = hp.npix2nside(fields[0].size)
    recorded = maps.get("nside", nside)
    if (
        isinstance(recorded, (bool, np.bool_))
        or not isinstance(recorded, numbers.Integral)
        or recorded != nside
    ):
        raise ValueError("NSIDE metadata does not match map length.")
    if not hp.isnsideok(nside, nest=nest):
        raise ValueError("NSIDE is invalid for the requested HEALPix ordering.")
    evaluated = _binary_mask(maps.get("evaluated_mask", valid), valid.shape, "evaluated_mask")
    if np.any(valid & ~evaluated):
        raise ValueError("evaluated_mask must contain every valid pixel.")
    c_bar = float(maps["c_bar"])
    if not np.isfinite(c_bar) or not 0 < c_bar <= 1:
        raise ValueError("c_bar must be finite and in (0, 1].")
    header = [("C_BAR", c_bar), ("RAWAB", True), ("LAIAVER", "0.2.0")]
    for key, card in (("weighting", "WEIGHT"), ("attenuation_convention", "ATTEN")):
        if key in maps:
            header.append((card, str(maps[key])))
    if "sigma_floor_rad" in maps:
        header.append(("SIGFLOOR", float(maps["sigma_floor_rad"])))
    if "attenuation_uses_floor" in maps:
        header.append(
            ("ATTFLOR", _boolean(maps["attenuation_uses_floor"], "attenuation_uses_floor"))
        )
    if "half_sky" in maps:
        header.append(("HALFSKY", _boolean(maps["half_sky"], "half_sky")))
    data = [np.where(valid, f, hp.UNSEEN) for f in fields]
    data += [valid.astype(np.uint8), evaluated.astype(np.uint8)]
    path = _destination(path, overwrite)
    hp.write_map(
        str(path),
        data,
        nest=nest,
        coord="C",
        fits_IDL=False,
        column_names=["E_A", "E_B", "E_AB", "E_A_MINUS_B", "VALID", "EVALUATED"],
        dtype=[np.float64] * 4 + [np.uint8] * 2,
        extra_header=header,
        overwrite=overwrite,
    )
    return path


def read_maps(path):
    """Read a public map bundle without silently changing RING/NESTED ordering."""
    with fits.open(path, memmap=False) as hdul:
        hdu = hdul[1]
        header = hdu.header.copy()
        names = hdu.columns.names
        required = ["E_A", "E_B", "E_AB", "E_A_MINUS_B", "VALID", "EVALUATED"]
        if not set(required).issubset(names):
            raise ValueError("Not a LAIA map bundle; use read_field for a single legacy map.")
        arrays = [np.array(hdu.data[name]).ravel() for name in required]
    nside, order = _full_map_header(header, arrays[0].size)
    if not _boolean(header.get("RAWAB", False), "RAWAB"):
        raise ValueError("Expected raw Ea/Eb maps with baseline 1/2.")
    maps = dict(zip(("Ea", "Eb", "Eab", "Eam"), arrays[:4]))
    valid = _binary_mask(arrays[4], arrays[0].shape, "VALID")
    for key in ("Ea", "Eb", "Eab", "Eam"):
        maps[key], finite = _field_valid(maps[key])
        valid &= finite
    for key in ("Ea", "Eb", "Eab", "Eam"):
        maps[key][~valid] = np.nan
    c_bar = float(header["C_BAR"])
    if not np.isfinite(c_bar) or not 0 < c_bar <= 1:
        raise ValueError("Invalid C_BAR metadata.")
    evaluated = _binary_mask(arrays[5], arrays[0].shape, "EVALUATED")
    if np.any(valid & ~evaluated):
        raise ValueError("Valid pixels cannot be marked unevaluated.")
    maps.update(
        nside=nside,
        nest=order == "NESTED",
        ordering=order,
        centered=False,
        c_bar=c_bar,
        valid_mask=valid,
        evaluated_mask=evaluated,
        weighting=header.get("WEIGHT", "unknown"),
        attenuation_convention=header.get("ATTEN", "unknown"),
    )
    if "SIGFLOOR" in header:
        maps["sigma_floor_rad"] = header["SIGFLOOR"]
    if "ATTFLOR" in header:
        maps["attenuation_uses_floor"] = _boolean(header["ATTFLOR"], "ATTFLOR")
    if "HALFSKY" in header:
        maps["half_sky"] = _boolean(header["HALFSKY"], "HALFSKY")
    return maps


def write_field(path, field, *, c_bar, nest=True, valid_mask=None, centered=False, overwrite=False):
    """Write one field plus a validity mask, retaining its baseline convention."""
    field, valid = _field_valid(field, valid_mask)
    nest = _boolean(nest, "nest")
    centered = _boolean(centered, "centered")
    if not hp.isnsideok(hp.npix2nside(field.size), nest=nest):
        raise ValueError("NSIDE is invalid for the requested HEALPix ordering.")
    if not np.isfinite(c_bar) or not 0 < c_bar <= 1:
        raise ValueError("c_bar must be in (0, 1].")
    path = _destination(path, overwrite)
    hp.write_map(
        str(path),
        [np.where(valid, field, hp.UNSEEN), valid.astype(np.uint8)],
        nest=nest,
        coord="C",
        dtype=[np.float64, np.uint8],
        fits_IDL=False,
        column_names=["E_FIELD", "VALID"],
        extra_header=[("C_BAR", float(c_bar)), ("CENTERED", bool(centered))],
        overwrite=overwrite,
    )
    return path


def read_field(path, *, valid_mask=None):
    """Read one standard HEALPix field or a beta primary-image FITS field.

    Zero is a legitimate value, never an implicit mask. For old zero-padded
    files, supply ``valid_mask`` explicitly before centered/template analysis.
    A missing C_BAR is returned as None and must be supplied by the caller.
    """
    internal = None
    with fits.open(path, memmap=False) as hdul:
        if hdul[0].data is not None:
            field = np.asarray(hdul[0].data, dtype=float).copy()
            if field.ndim != 1:
                raise ValueError("A legacy primary-image map must be one-dimensional.")
            header = hdul[0].header.copy()
        else:
            hdu = hdul[1]
            field = np.asarray(hdu.data.field(0), dtype=float).ravel().copy()
            header = hdu.header.copy()
            if "VALID" in hdu.columns.names:
                internal = np.asarray(hdu.data["VALID"]).ravel()
    field, valid = _field_valid(field, valid_mask)
    if internal is not None:
        valid &= _binary_mask(internal, field.shape, "VALID")
    field[~valid] = np.nan
    nside, order = _full_map_header(header, field.size)
    c_bar = header.get("C_BAR")
    if c_bar is not None:
        c_bar = float(c_bar)
        if not np.isfinite(c_bar) or not 0 < c_bar <= 1:
            raise ValueError("Invalid C_BAR metadata.")
    return {
        "field": field,
        "valid_mask": valid,
        "nside": nside,
        "nest": order == "NESTED",
        "ordering": order,
        "c_bar": c_bar,
        "centered": _boolean(header.get("CENTERED", False), "CENTERED"),
    }


def json_safe(value):
    """Convert numerical results to strict JSON types (nonfinite values -> null)."""
    if isinstance(value, dict):
        return {str(k): json_safe(v) for k, v in value.items()}
    if isinstance(value, np.ndarray) and value.ndim == 0:
        return json_safe(value.item())
    if isinstance(value, (list, tuple, np.ndarray)):
        return [json_safe(v) for v in value]
    if isinstance(value, np.generic):
        return json_safe(value.item())
    if isinstance(value, complex):
        return {"real": json_safe(value.real), "imag": json_safe(value.imag)}
    if isinstance(value, float) and not np.isfinite(value):
        return None
    return value


def write_bootstrap(path, result, *, overwrite=False):
    """Save every bootstrap draw, validity flags, summary and settings to FITS."""
    table = Table(result["samples"])
    details = {k: v for k, v in result.items() if k != "samples"}
    encoded = json.dumps(json_safe(details), ensure_ascii=True, allow_nan=False)
    summary = fits.BinTableHDU.from_columns(
        [fits.Column(name="JSON", format=f"{len(encoded)}A", array=[encoded])], name="SUMMARY"
    )
    hdul = fits.HDUList([fits.PrimaryHDU(), fits.BinTableHDU(table, name="SAMPLES"), summary])
    path = _destination(path, overwrite)
    hdul.writeto(path, overwrite=overwrite)
    return path
