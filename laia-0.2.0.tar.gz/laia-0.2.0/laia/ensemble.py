"""Reproducible north-pole toy ensembles for validating the public estimator.

The default experiment is 64 independent, noiseless, full-sky catalogs of
100,000 objects with a 60-arcmin saturated axial injection. It is not a survey
simulation, an empirical null ensemble or a calculation of detection significance.
"""

from __future__ import annotations

import csv
import json
import numbers
from pathlib import Path

import healpy as hp
import numpy as np

from .estimator import compute_maps, evaluate_directions, measurement_from_map, theta_ia_from_peak
from .geometry import axial_separation, canonical_axis, vector_to_radec
from .io import json_safe
from .mock import generate_mock


_NORTH_AXIS = np.array([0.0, 0.0, 1.0])
_DATA_FILES = ("realizations.csv", "summary.json", "recovered_axis_counts.fits")
_PLOT_FILES = ("recovered_axes_mollweide.png", "theta_ia_distribution.png")


def _positive_integer(value, name, minimum=1):
    if (
        isinstance(value, (bool, np.bool_))
        or not isinstance(value, numbers.Integral)
        or value < minimum
    ):
        raise ValueError(f"{name} must be an integer >= {minimum}.")
    return int(value)


def _finite_scalar(value, name, *, lower=0.0, upper=np.inf):
    if np.any(np.ma.getmaskarray(value)) or isinstance(value, (bool, np.bool_)):
        raise ValueError(f"{name} must be a finite scalar in [{lower}, {upper}].")
    array = np.asarray(value, dtype=float)
    if array.ndim != 0 or not np.isfinite(array) or not lower <= array <= upper:
        raise ValueError(f"{name} must be a finite scalar in [{lower}, {upper}].")
    return float(array)


def _sample_statistics(values):
    """Retain invalid counts; std is between-realization scatter with ddof=1."""
    values = np.asarray(values, dtype=float)
    valid = np.isfinite(values)
    selected = values[valid]
    count = selected.size
    mean = float(selected.mean()) if count else np.nan
    std = float(selected.std(ddof=1)) if count > 1 else np.nan
    return {
        "n_valid": int(count),
        "n_invalid": int(values.size - count),
        "mean": mean,
        "std": std,
        "std_ddof": 1,
        "sem": std / np.sqrt(count) if count > 1 else np.nan,
        "median": float(np.median(selected)) if count else np.nan,
    }


def run_north_pole_ensemble(
    *,
    n_simulations=64,
    n_objects=100_000,
    theta_ia_arcmin=60.0,
    nside=32,
    seed=20261123,
    sigma_pa_deg=0.0,
    gal_chunk=1000,
    direction_chunk=64,
    progress=None,
):
    """Simulate and independently recover an ensemble of north-south axes.

    The default has no PA measurement noise and explicitly uses equal weights
    with C_bar=1. This is a controlled mock choice, not a recommendation to use
    equal weights for galaxy measurements. Optional Gaussian ``sigma_pa_deg``
    uses the actual input noise for attenuation (the 1-degree floor then affects
    automatic weights only). No systematic survey effects are added.

    Each catalog uses a separate child of ``SeedSequence(seed)``. Its spawn
    index is returned, making individual streams reconstructible without
    sharing NumPy's global RNG. Catalogs/maps are processed one at a time and
    discarded; the returned object retains only per-realization measurements.

    The main measurement maximizes Ea over the ordinary northern HEALPix grid.
    The known injected axis is NOT used to restrict the search or select the
    answer. A separate pre-specified-direction evaluation at (0,0,1) is saved
    as a diagnostic of peak-selection effects. The exact pole is not a pixel
    center, so a grid peak is not guaranteed to exceed this fixed-direction
    value. Out-of-model inversions are flagged NaN, never clipped.

    All reported directions use the canonical northern antipode: the entire
    vector is flipped, changing RA by 180 degrees when required, not just the
    sign of Dec. At the true pole RA is undefined; no arithmetic RA mean or
    RA standard deviation is reported. Angular separations are axial.

    The sample standard deviation uses ddof=1 and describes scatter among
    independent catalogs. The standard error of their mean is separately
    labeled; neither is a detection significance or the full survey error.
    A maximized noisy map may have a positive amplitude bias, so the mean is
    not forced to equal the injection. Grid-resolution convergence is a
    separate check; ``nside`` is explicit and configurable.

    ``progress``, if provided, is called as
    ``progress(completed_count, total_count, row_dict)`` after each catalog.
    """
    n_simulations = _positive_integer(n_simulations, "n_simulations", minimum=2)
    n_objects = _positive_integer(n_objects, "n_objects")
    nside = _positive_integer(nside, "nside")
    gal_chunk = _positive_integer(gal_chunk, "gal_chunk")
    direction_chunk = _positive_integer(direction_chunk, "direction_chunk")
    if not hp.isnsideok(nside, nest=True):
        raise ValueError("nside must be a valid NESTED HEALPix resolution.")
    theta_ia_arcmin = _finite_scalar(theta_ia_arcmin, "theta_ia_arcmin", upper=5400.0)
    sigma_pa_deg = _finite_scalar(sigma_pa_deg, "sigma_pa_deg")
    if isinstance(seed, (bool, np.bool_)) or not isinstance(seed, numbers.Integral) or seed < 0:
        raise ValueError("seed must be a nonnegative integer.")
    seed = int(seed)
    if progress is not None and not callable(progress):
        raise TypeError("progress must be callable or None.")

    children = np.random.SeedSequence(seed).spawn(n_simulations)
    rows = []
    common = {
        "gal_chunk": gal_chunk,
        "direction_chunk": direction_chunk,
        "attenuation_uses_floor": False,
    }
    for index, child in enumerate(children):
        mock = generate_mock(
            n_objects,
            direction=_NORTH_AXIS,
            theta_ia_rad=np.deg2rad(theta_ia_arcmin / 60.0),
            sigma_pa_rad=np.deg2rad(sigma_pa_deg),
            rng=np.random.default_rng(child),
        )
        weights = "uniform" if mock["sigma_pa"] is None else None
        maps = compute_maps(
            mock["a"],
            mock["n"],
            sigma_pa=mock["sigma_pa"],
            weights=weights,
            nside=nside,
            nest=True,
            half_sky=True,
            **common,
        )
        measured = measurement_from_map(
            maps["Ea"],
            maps["c_bar"],
            nside=nside,
            nest=True,
            valid_mask=maps["valid_mask"],
            on_invalid="nan",
        )
        fixed = evaluate_directions(
            mock["a"],
            mock["n"],
            [_NORTH_AXIS],
            sigma_pa=mock["sigma_pa"],
            weights=weights,
            **common,
        )
        fixed_peak = float(fixed["Ea"][0])
        fixed_theta = theta_ia_from_peak(fixed_peak, fixed["c_bar"], on_invalid="nan")
        axis = canonical_axis(measured["axis"])
        ra, dec = vector_to_radec(axis)
        row = {
            "simulation": index + 1,
            "seed_spawn_index": int(child.spawn_key[0]),
            "theta_ia_arcmin": float(measured["theta_ia_arcmin"]),
            "amplitude_valid": bool(measured["amplitude_valid"]),
            "ra_deg": float(ra),
            "dec_deg": float(dec),
            "axis_x": float(axis[0]),
            "axis_y": float(axis[1]),
            "axis_z": float(axis[2]),
            "grid_pixel": int(measured["pixel"]),
            "axial_separation_deg": float(axial_separation(axis, _NORTH_AXIS)),
            "E_peak": float(measured["peak"]),
            "c_bar": float(maps["c_bar"]),
            "E_at_injected_axis": fixed_peak,
            "theta_ia_at_injected_axis_arcmin": float(np.rad2deg(fixed_theta) * 60.0),
            "amplitude_at_injected_axis_valid": bool(np.isfinite(fixed_theta)),
        }
        rows.append(row)
        if progress is not None:
            progress(index + 1, n_simulations, dict(row))

    samples = {key: np.asarray([row[key] for row in rows]) for key in rows[0]}
    axes = np.column_stack([samples[key] for key in ("axis_x", "axis_y", "axis_z")])
    count_pixels = hp.vec2pix(nside, *axes.T, nest=True)
    counts = np.bincount(count_pixels, minlength=hp.nside2npix(nside)).astype(np.int64)
    north_support = np.asarray(hp.pix2vec(nside, np.arange(counts.size), nest=True)[2]) >= 0
    if np.any(samples["dec_deg"] < 0) or np.any(counts[~north_support] != 0):
        raise RuntimeError("An ensemble direction was not folded to the northern hemisphere.")

    peak_stats = _sample_statistics(samples["theta_ia_arcmin"])
    fixed_stats = _sample_statistics(samples["theta_ia_at_injected_axis_arcmin"])
    fixed_e_stats = _sample_statistics(samples["E_at_injected_axis"])
    separation_stats = _sample_statistics(samples["axial_separation_deg"])
    notes = [
        "Independent toy-catalog scatter, not a survey posterior or detection significance.",
        "The main theta statistic is the searched grid maximum; its mean can be biased.",
        "The fixed injected-axis diagnostic is separate and does not select the recovered axis.",
        "RA is undefined at the injected pole; northern folding flips the entire axial vector.",
        "Check nside convergence before interpreting directional precision.",
    ]
    if peak_stats["n_invalid"] or fixed_stats["n_invalid"]:
        notes.append(
            "Invalid amplitudes are retained in the samples and counted; statistics use only finite values."
        )
    summary = {
        "n_simulations": n_simulations,
        "n_amplitude_valid": peak_stats["n_valid"],
        "n_amplitude_invalid": peak_stats["n_invalid"],
        "theta_ia_mean_arcmin": peak_stats["mean"],
        "theta_ia_std_arcmin": peak_stats["std"],
        "theta_ia_sem_arcmin": peak_stats["sem"],
        "theta_ia_median_arcmin": peak_stats["median"],
        "theta_ia_mean_minus_injected_arcmin": peak_stats["mean"] - theta_ia_arcmin,
        "std_ddof": 1,
        "fixed_axis_control": {
            "theta_ia_arcmin": fixed_stats,
            "E": fixed_e_stats,
            "note": "Pre-specified exact injected pole; not the blindly recovered measurement.",
        },
        "axial_separation_deg": separation_stats,
        "n_northern_axes": int(counts.sum()),
        "notes": notes,
    }
    metadata = {
        "experiment": "independent_full_sky_north_pole_toy_catalogs",
        "n_simulations": n_simulations,
        "n_objects_per_simulation": n_objects,
        "injected_theta_ia_arcmin": theta_ia_arcmin,
        "injected_axis": _NORTH_AXIS.tolist(),
        "injected_ra_deg": None,
        "injected_dec_deg": 90.0,
        "sigma_pa_deg": sigma_pa_deg,
        "weighting": "uniform" if sigma_pa_deg == 0 else "inverse_variance",
        "attenuation_convention": "noiseless" if sigma_pa_deg == 0 else "input_sigma",
        "nside": nside,
        "nest": True,
        "search": "Ea maximum over northern HEALPix pixel centers",
        "coordinate_frame": "equatorial",
        "axis_representation": "canonical northern antipode, Dec >= 0",
        "seed_sequence_entropy": seed,
        "seed_spawn_key": "Each realization uses (seed_spawn_index,) with the root entropy.",
        "rng": "numpy.random.default_rng(SeedSequence child)",
        "bit_generator": "PCG64",
        "numpy_version": np.__version__,
        "gal_chunk": gal_chunk,
        "direction_chunk": direction_chunk,
        "keeps_catalogs_or_estimator_maps": False,
    }
    return {
        "samples": samples,
        "summary": summary,
        "metadata": metadata,
        "direction_counts": counts,
        "north_support": north_support,
    }


def validate_ensemble_output(output_dir, *, plots=True, overwrite=False):
    """Preflight the destination before starting an expensive ensemble.

    Existing directories require explicit overwrite, even if empty. Overwrite
    affects only this example's named files, never unrelated files. If plots
    from an older run exist, a no-plot overwrite is rejected to avoid stale
    images being confused with the new measurements.
    """
    if not isinstance(plots, (bool, np.bool_)) or not isinstance(overwrite, (bool, np.bool_)):
        raise ValueError("plots and overwrite must be Boolean.")
    output_dir = Path(output_dir)
    if output_dir.exists() and not output_dir.is_dir():
        raise NotADirectoryError(f"Not a directory: {output_dir}")
    if output_dir.exists() and not overwrite:
        raise FileExistsError(f"{output_dir} exists; choose a new output or pass --overwrite.")
    if not plots and any((output_dir / name).exists() for name in _PLOT_FILES):
        raise FileExistsError(
            "Old plots exist; choose a new output or regenerate plots explicitly."
        )
    if plots:
        try:
            import matplotlib  # noqa: F401
        except ImportError as exc:
            raise ImportError(
                "Ensemble plots require Matplotlib; install the 'plot' extra or disable plots."
            ) from exc
    return output_dir


def _plot_ensemble(output_dir, result):
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    samples, metadata = result["samples"], result["metadata"]
    display = np.where(result["north_support"], result["direction_counts"], hp.UNSEEN)
    hp.mollview(
        display,
        nest=True,
        coord="C",
        title=f"Recovered axes: {metadata['n_simulations']} independent toy catalogs",
        unit="Recovered axes per pixel",
        min=0,
        max=max(1, int(np.max(result["direction_counts"]))),
        cmap="viridis",
        notext=False,
    )
    hp.graticule(dpar=30, dmer=60, alpha=0.35)
    hp.projscatter(
        samples["ra_deg"],
        samples["dec_deg"],
        lonlat=True,
        marker="o",
        s=16,
        facecolors="none",
        edgecolors="#fdae61",
        linewidths=0.7,
        label="Recovered northern representatives",
    )
    hp.projscatter(
        0,
        90,
        lonlat=True,
        marker="*",
        s=110,
        color="#e34a33",
        clip_on=False,
        label="Injected north-south axis",
    )
    plt.legend(loc="lower left", fontsize=7, framealpha=0.95)
    plt.figtext(
        0.5,
        0.02,
        "Equatorial RA/Dec; full-vector antipodal fold to Dec >= 0. Not a posterior.",
        ha="center",
        fontsize=8,
    )
    plt.savefig(output_dir / _PLOT_FILES[0], dpi=170, bbox_inches="tight")
    plt.close()

    peak = np.asarray(samples["theta_ia_arcmin"], dtype=float)
    fixed = np.asarray(samples["theta_ia_at_injected_axis_arcmin"], dtype=float)
    peak, fixed = peak[np.isfinite(peak)], fixed[np.isfinite(fixed)]
    fig, ax = plt.subplots(figsize=(7.5, 4.8))
    combined = np.concatenate([peak, fixed])
    if combined.size:
        bins = np.histogram_bin_edges(
            combined, bins=max(6, min(20, int(np.sqrt(metadata["n_simulations"]) * 1.5)))
        )
        if peak.size:
            ax.hist(
                peak,
                bins=bins,
                alpha=0.72,
                color="#087e8b",
                label=f"Recovered grid maximum (n={peak.size})",
            )
        if fixed.size:
            ax.hist(
                fixed,
                bins=bins,
                histtype="step",
                linewidth=1.8,
                color="#d98432",
                label=f"Fixed injected-axis control (n={fixed.size})",
            )
    ax.axvline(
        metadata["injected_theta_ia_arcmin"],
        color="black",
        linestyle="--",
        label="Injected amplitude",
    )
    summary = result["summary"]
    ax.set(
        xlabel=r"$\theta_{\rm IA}$ [arcmin]",
        ylabel="Number of independent catalogs",
        title="North-pole toy ensemble: recovered amplitude",
    )
    ax.text(
        0.98,
        0.96,
        f"Grid-peak mean = {summary['theta_ia_mean_arcmin']:.2f} arcmin\n"
        f"Sample std = {summary['theta_ia_std_arcmin']:.2f} arcmin (ddof=1)",
        transform=ax.transAxes,
        ha="right",
        va="top",
        fontsize=9,
        bbox={"facecolor": "white", "alpha": 0.85, "edgecolor": "none"},
    )
    ax.legend(loc="upper left", fontsize=8)
    fig.tight_layout()
    fig.savefig(output_dir / _PLOT_FILES[1], dpi=170)
    plt.close(fig)


def write_ensemble(output_dir, result, *, plots=True, overwrite=False):
    """Save measured rows, statistics and a northern-axis count map.

    The FITS count map has an explicit NORTH_SUPPORT mask; its unobserved
    southern half is UNSEEN, not a second independent set of directions.
    The map bins independent recovered axes, not galaxies or posterior samples.
    ``summary.json`` is written last, after the other requested outputs.
    """
    output_dir = validate_ensemble_output(output_dir, plots=plots, overwrite=overwrite)
    samples = result["samples"]
    metadata = result["metadata"]
    counts = np.asarray(result["direction_counts"])
    north = np.asarray(result["north_support"], dtype=bool)
    count = metadata["n_simulations"]
    if counts.shape != (hp.nside2npix(metadata["nside"]),) or north.shape != counts.shape:
        raise ValueError("Direction count map/mask does not match metadata nside.")
    if counts.sum() != count or np.any(counts < 0) or np.any(counts[~north] != 0):
        raise ValueError("Direction counts must contain exactly one northern axis per simulation.")
    if any(np.asarray(value).shape != (count,) for value in samples.values()):
        raise ValueError("Each sample column must have one value per simulation.")
    output_dir.mkdir(parents=True, exist_ok=True)
    with (output_dir / _DATA_FILES[0]).open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(samples))
        writer.writeheader()
        for index in range(count):
            writer.writerow({key: value[index] for key, value in samples.items()})
    hp.write_map(
        str(output_dir / _DATA_FILES[2]),
        [np.where(north, counts, hp.UNSEEN), north.astype(np.uint8)],
        nest=True,
        coord="C",
        fits_IDL=False,
        column_names=["AXIS_COUNT", "NORTH_SUPPORT"],
        dtype=[np.float64, np.uint8],
        extra_header=[
            ("AXIAL", True),
            ("FOLDN", True),
            ("N_SIM", int(count)),
            ("INJAMIN", float(metadata["injected_theta_ia_arcmin"])),
        ],
        overwrite=overwrite,
    )
    if plots:
        _plot_ensemble(output_dir, result)
    payload = {
        "summary": result["summary"],
        "metadata": metadata,
        "files": list(_DATA_FILES) + (list(_PLOT_FILES) if plots else []),
    }
    (output_dir / _DATA_FILES[1]).write_text(
        json.dumps(json_safe(payload), indent=2, allow_nan=False) + "\n", encoding="utf-8"
    )
    return {name: output_dir / name for name in payload["files"]}
