"""Geometry for headless orientations on the celestial sphere.

An orientation is an axis: ``a`` and ``-a`` carry the same information.  Sky
coordinates are equatorial Cartesian vectors, with x toward (RA, Dec)=(0, 0),
y toward (90, 0), and z toward the north celestial pole.
"""

from __future__ import annotations

import numpy as np


def _vectors(value, name):
    """Return a finite, nonempty float array whose final dimension is three."""
    if np.any(np.ma.getmaskarray(value)):
        raise ValueError(f"{name} must not contain masked values.")
    array = np.array(value, dtype=np.float64, copy=True)
    if array.ndim < 1 or array.shape[-1] != 3 or array.size == 0:
        raise ValueError(f"{name} must have a nonempty final dimension of length 3.")
    if not np.all(np.isfinite(array)):
        raise ValueError(f"{name} must contain only finite values.")
    return array


def validate_vectors(a, n, *, atol=1e-7):
    """Check and return tangent orientations and sightlines as float copies.

    Parameters
    ----------
    a, n : array-like, shape (N, 3)
        Unit orientation vectors and unit line-of-sight vectors.  Every ``a``
        must be perpendicular to its matching ``n``.
    atol : float, optional
        Absolute tolerance for unit norms and tangency.  Departures within
        this tolerance are normalized/projected away as numerical roundoff;
        genuinely nonunit or nontangent inputs are rejected, not repaired.

    Returns
    -------
    a, n : ndarray, shape (N, 3)
        Independent float64 arrays.  Caller-owned input arrays are not changed.
    """
    if not np.isscalar(atol) or not np.isfinite(atol) or atol < 0:
        raise ValueError("atol must be finite and nonnegative.")
    a = _vectors(a, "a")
    n = _vectors(n, "n")
    if a.ndim != 2 or n.ndim != 2 or a.shape != n.shape:
        raise ValueError("a and n must have the same nonempty shape (N, 3).")
    anorm = np.linalg.norm(a, axis=1)
    nnorm = np.linalg.norm(n, axis=1)
    if np.any(anorm == 0) or np.any(nnorm == 0):
        raise ValueError("a and n must have nonzero norms.")
    if np.any(np.abs(anorm - 1) > atol) or np.any(np.abs(nnorm - 1) > atol):
        raise ValueError("a and n must be unit vectors within atol.")
    if np.any(np.abs(np.einsum("ij,ij->i", a, n)) > atol):
        raise ValueError("Each orientation a must be tangent to its sightline n.")
    # Correct only the roundoff-level departures that passed the checks above.
    n /= nnorm[:, None]
    a -= np.einsum("ij,ij->i", a, n)[:, None] * n
    a /= np.linalg.norm(a, axis=1)[:, None]
    return a, n


def sky_to_vectors(ra, dec, pa, *, degrees=True, convention="east_of_north"):
    """Convert sky position and axial position angle to ``(a, n)``.

    ``ra``, ``dec`` and ``pa`` are broadcast together and flattened; the result
    always has shape (N, 3), including scalar input.  Angles are degrees unless
    ``degrees=False``.  PA is axial, so adding 180 degrees only reverses ``a``.

    The default astronomical convention, ``east_of_north``, is
    ``a = cos(PA)*north + sin(PA)*east``.  The historical notebook convention
    ``west_ccw`` is exactly ``a = sin(PA)*north - cos(PA)*east``.  It must be
    selected explicitly; these conventions cannot be interchanged without
    transforming the input PA.
    """
    if convention not in {"east_of_north", "west_ccw"}:
        raise ValueError("convention must be 'east_of_north' or 'west_ccw'.")
    if any(np.any(np.ma.getmaskarray(x)) for x in (ra, dec, pa)):
        raise ValueError("Sky coordinates and PAs must not contain masked values.")
    ra, dec, pa = np.broadcast_arrays(
        np.asarray(ra, dtype=float),
        np.asarray(dec, dtype=float),
        np.asarray(pa, dtype=float),
    )
    if ra.size == 0 or not all(np.all(np.isfinite(x)) for x in (ra, dec, pa)):
        raise ValueError("Sky coordinates and PAs must be nonempty and finite.")
    if degrees:
        ra, dec, pa = (np.deg2rad(x) for x in (ra, dec, pa))
    ra, dec, pa = (x.ravel() for x in (ra, dec, pa))
    if np.any(np.abs(dec) > np.pi / 2):
        raise ValueError("Declination must lie between -90 and +90 degrees.")
    n = np.column_stack((np.cos(dec) * np.cos(ra), np.cos(dec) * np.sin(ra), np.sin(dec)))
    east = np.column_stack((-np.sin(ra), np.cos(ra), np.zeros_like(ra)))
    north = np.column_stack((-np.sin(dec) * np.cos(ra), -np.sin(dec) * np.sin(ra), np.cos(dec)))
    if convention == "east_of_north":
        a = np.cos(pa)[:, None] * north + np.sin(pa)[:, None] * east
    else:
        a = np.sin(pa)[:, None] * north - np.cos(pa)[:, None] * east
    return validate_vectors(a, n)


def canonical_axis(axis):
    """Normalize axes and choose a deterministic northern representative.

    Accept shape (3,) or (..., 3).  Prefer z > 0; on the exact equator prefer
    y > 0, and if z=y=0 prefer x > 0.  This sign choice is a reporting convention,
    not a distinction between physically different axes.
    """
    axis = _vectors(axis, "axis")
    norm = np.linalg.norm(axis, axis=-1, keepdims=True)
    if np.any(norm == 0) or not np.all(np.isfinite(norm)):
        raise ValueError("axis must have finite nonzero norm.")
    axis /= norm
    flip = (
        (axis[..., 2] < 0)
        | ((axis[..., 2] == 0) & (axis[..., 1] < 0))
        | ((axis[..., 2] == 0) & (axis[..., 1] == 0) & (axis[..., 0] < 0))
    )
    return axis * np.where(flip, -1.0, 1.0)[..., None]


def vector_to_radec(vector):
    """Return (RA, Dec) in degrees for finite nonzero Cartesian vectors.

    This function does not change an axis to its antipode.  Use
    :func:`canonical_axis` first when a canonical axial representative is wanted.
    """
    vector = _vectors(vector, "vector")
    norm = np.linalg.norm(vector, axis=-1)
    if np.any(norm == 0) or not np.all(np.isfinite(norm)):
        raise ValueError("vector must have finite nonzero norm.")
    ra = np.mod(np.rad2deg(np.arctan2(vector[..., 1], vector[..., 0])), 360.0)
    dec = np.rad2deg(np.arcsin(np.clip(vector[..., 2] / norm, -1, 1)))
    if vector.ndim == 1:
        return float(ra), float(dec)
    return ra, dec


def axial_separation(first, second, *, degrees=True):
    """Return the acute separation of axes, treating either sign as equivalent.

    Inputs have broadcast-compatible shapes (..., 3); their nonzero vectors
    are normalized.  The result lies in [0, 90] degrees by default, or
    [0, pi/2] radians when ``degrees=False``.
    """
    first, second = np.broadcast_arrays(_vectors(first, "first"), _vectors(second, "second"))
    norm_first = np.linalg.norm(first, axis=-1)
    norm_second = np.linalg.norm(second, axis=-1)
    if (
        np.any(norm_first == 0)
        or np.any(norm_second == 0)
        or not np.all(np.isfinite(norm_first))
        or not np.all(np.isfinite(norm_second))
    ):
        raise ValueError("Both axes must have finite nonzero norms.")
    first = first / norm_first[..., None]
    second = second / norm_second[..., None]
    cosine = np.abs(np.sum(first * second, axis=-1))
    sine = np.linalg.norm(np.cross(first, second), axis=-1)
    angle = np.arctan2(sine, cosine)
    if degrees:
        angle = np.rad2deg(angle)
    return float(angle) if np.ndim(angle) == 0 else angle
