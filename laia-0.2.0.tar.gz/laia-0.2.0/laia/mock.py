"""Minimal phenomenological LAIA mocks and saturated axial-signal injection.

These utilities demonstrate the estimator. They do not model cosmological
clustering, correlated intrinsic alignments, physical gravitational shear, or
the survey-specific calibration and inference pipeline of the LAIA paper.
All angular quantities in the numerical API are in radians.
"""

from __future__ import annotations

import operator

import healpy as hp
import numpy as np

from .geometry import canonical_axis, sky_to_vectors, validate_vectors


def _generator(rng=None, seed=None):
    """Resolve exactly one random stream without touching NumPy's global RNG."""
    if rng is not None and seed is not None:
        raise ValueError("Pass either rng or seed, not both.")
    if rng is not None:
        if not isinstance(rng, np.random.Generator):
            raise TypeError("rng must be a numpy.random.Generator.")
        return rng
    return np.random.default_rng(seed)


def _positive_integer(value, name):
    if np.any(np.ma.getmaskarray(value)) or isinstance(value, (bool, np.bool_)):
        raise ValueError(f"{name} must be a positive integer.")
    try:
        result = operator.index(value)
    except TypeError as exc:
        raise ValueError(f"{name} must be a positive integer.") from exc
    if result < 1:
        raise ValueError(f"{name} must be a positive integer.")
    return result


def _map_array(value, name):
    source = np.ma.asarray(value, dtype=float)
    missing = np.ma.getmaskarray(source)
    result = np.asarray(source.filled(np.nan))
    if result.ndim != 1:
        raise ValueError(f"{name} must be a one-dimensional HEALPix map.")
    try:
        nside = hp.npix2nside(result.size)
    except ValueError as exc:
        raise ValueError(f"{name} does not have a valid HEALPix length.") from exc
    if not hp.isnsideok(nside, nest=True):
        raise ValueError(f"{name} must have a power-of-two NSIDE.")
    return result, int(nside), missing


def sample_positions(
    n_objects,
    *,
    mask=None,
    overdensity=None,
    nside=None,
    nest=True,
    subpixel_factor=256,
    rng=None,
    seed=None,
):
    """Sample sky positions as Cartesian unit vectors of shape ``(N, 3)``.

    With no maps, positions are continuously uniform in solid angle over the
    full sky. If a mask or overdensity map is supplied, all maps must have the
    same HEALPix NSIDE and ordering. Finite positive mask values select pixels;
    their magnitudes are **not** probability weights. Zero, NaN and UNSEEN mask
    pixels are excluded. Explicit masked-array entries in either the mask or
    the overdensity map are excluded as well. Negative mask values other than
    UNSEEN are invalid.

    ``overdensity`` means delta, not a direct density: selected parent pixels
    are sampled with probabilities proportional to ``1 + delta``. Valid zero
    overdensity values are retained. Delta must be finite and at least -1 in
    every selected pixel, with positive total probability. Excluded pixels may
    contain arbitrary map sentinels. If only overdensity is given, the initial
    mask is full sky, so invalid overdensities must be explicitly masked out.

    Within each selected pixel, this minimal sampler chooses an equal-area
    NESTED child-pixel center uniformly. ``subpixel_factor`` is the ratio of
    child NSIDE to parent NSIDE and must be a power of two. This is a documented
    finite-resolution approximation to continuous sampling within the mask,
    not a cosmological spatial point process. The child remains inside its
    selected parent by construction. ``nside``, if given, checks map resolution;
    it does not discretize the map-free full-sky case.

    Pass one ``rng`` or ``seed`` to reproduce all sampling. No global random
    state is used, and the number of objects need not exceed the pixel count.
    """
    count = _positive_integer(n_objects, "n_objects")
    if not isinstance(nest, (bool, np.bool_)):
        raise ValueError("nest must explicitly be True or False.")
    random = _generator(rng, seed)
    factor = _positive_integer(subpixel_factor, "subpixel_factor")
    if factor & (factor - 1):
        raise ValueError("subpixel_factor must be a power of two.")
    if nside is not None:
        nside = _positive_integer(nside, "nside")
        if not hp.isnsideok(nside, nest=True):
            raise ValueError("nside must be a valid power-of-two HEALPix NSIDE.")

    if mask is None and overdensity is None:
        longitude = random.uniform(0.0, 2.0 * np.pi, size=count)
        z = random.uniform(-1.0, 1.0, size=count)
        radius = np.sqrt(np.maximum(0.0, 1.0 - z * z))
        return np.column_stack((radius * np.cos(longitude), radius * np.sin(longitude), z))

    map_nside = None
    if mask is not None:
        mask_values, map_nside, mask_missing = _map_array(mask, "mask")
        unseen = hp.mask_bad(mask_values)
        if np.any((mask_values < 0) & ~unseen):
            raise ValueError("mask values must be nonnegative or HEALPix UNSEEN.")
        selected = np.isfinite(mask_values) & (mask_values > 0) & ~unseen & ~mask_missing

    if overdensity is not None:
        delta, delta_nside, delta_missing = _map_array(overdensity, "overdensity")
        if map_nside is not None and delta_nside != map_nside:
            raise ValueError("mask and overdensity must have matching HEALPix lengths.")
        map_nside = delta_nside
        if mask is None:
            selected = np.ones(delta.size, dtype=bool)
        selected &= ~delta_missing

    if nside is not None and nside != map_nside:
        raise ValueError("nside does not match the supplied map resolution.")
    parent_pixels = np.flatnonzero(selected)
    if parent_pixels.size == 0:
        raise ValueError("The mask contains no selected pixels.")
    density = np.ones(parent_pixels.size, dtype=float)
    if overdensity is not None:
        chosen_delta = delta[parent_pixels]
        if np.any(~np.isfinite(chosen_delta)) or np.any(chosen_delta < -1.0):
            raise ValueError("overdensity must be finite and >= -1 in selected pixels.")
        density += chosen_delta
    # Rescaling prevents overflow for large, otherwise valid density weights.
    maximum = float(density.max())
    if maximum <= 0:
        raise ValueError("Selected pixels have zero total sampling probability.")
    probabilities = density / maximum
    probabilities /= probabilities.sum()
    chosen_parents = random.choice(parent_pixels, size=count, p=probabilities)
    if not nest:
        chosen_parents = hp.ring2nest(map_nside, chosen_parents)
    child_nside = map_nside * factor
    if not hp.isnsideok(child_nside, nest=True):
        raise ValueError("The requested child-pixel NSIDE exceeds HEALPix limits.")
    children_per_parent = factor * factor
    # integers' upper bound is exclusive: never leak into the next parent.
    offsets = random.integers(0, children_per_parent, size=count, dtype=np.int64)
    child_pixels = chosen_parents.astype(np.int64) * children_per_parent + offsets
    return np.column_stack(hp.pix2vec(child_nside, child_pixels, nest=True))


def _random_orientations(n, rng):
    """Draw axial PAs uniformly in [0, pi), east of local north."""
    longitude = np.arctan2(n[:, 1], n[:, 0])
    latitude = np.arctan2(n[:, 2], np.hypot(n[:, 0], n[:, 1]))
    pa = rng.uniform(0.0, np.pi, size=n.shape[0])
    axes, _ = sky_to_vectors(longitude, latitude, pa, degrees=False)
    return axes


def uniform_catalog(n_objects, *, rng=None, seed=None):
    """Return ``{'a': axes, 'n': sightlines}`` for an isotropic, noiseless toy sky.

    Sightlines are uniform in solid angle and axial PAs are uniform in
    ``[0, pi)`` independently. Both stages share the supplied random stream.
    """
    random = _generator(rng, seed)
    n = sample_positions(n_objects, rng=random)
    return {"a": _random_orientations(n, random), "n": n}


def inject_alignment(a, n, direction, theta_ia_rad, *, eps=1e-12):
    """Inject the paper's saturated, headless axial-alignment prescription.

    If phi is the acute angle between an input axis and the local projection
    of ``direction``, the output has ``phi_new = max(phi - theta_ia_rad, 0)``.
    ``theta_ia_rad`` must be in ``[0, pi/2]``. Unit, tangent input vectors are
    checked and converted to floating point before the Rodrigues rotation.

    Target directions are axial: replacing ``direction`` by its antipode
    changes nothing. Input orientation sign flips only flip the corresponding
    output sign. At the exactly orthogonal tie, canonical representatives of
    the target and input axis choose a deterministic one of the two shortest
    paths. When the target projection has norm <= ``eps`` (line of sight
    parallel to the target), the orientation is left unchanged because the
    local target direction is undefined.

    This is a phenomenological injection, not a model of gravitational shear.
    """
    axes, sightlines = validate_vectors(a, n)
    if np.any(np.ma.getmaskarray(theta_ia_rad)):
        raise ValueError("theta_ia_rad must not be masked.")
    theta = np.asarray(theta_ia_rad, dtype=float)
    if theta.ndim != 0 or not np.isfinite(theta) or not 0 <= theta <= np.pi / 2:
        raise ValueError("theta_ia_rad must be a finite scalar in [0, pi/2].")
    if np.any(np.ma.getmaskarray(eps)) or np.ndim(eps) != 0 or not np.isfinite(eps) or eps <= 0:
        raise ValueError("eps must be finite and positive.")
    target_axis = canonical_axis(direction)
    if target_axis.shape != (3,):
        raise ValueError("direction must be a finite nonzero vector of shape (3,).")
    reference_axes = canonical_axis(axes)
    original_sign = np.where(np.einsum("ij,ij->i", axes, reference_axes) < 0, -1.0, 1.0)

    # The equivalent subtraction d - (d.n)n loses relative precision when
    # the sightline is nearly parallel to d. The double cross product keeps
    # the tiny projected direction tangent even after normalization.
    projection = np.cross(np.cross(sightlines, target_axis), sightlines)
    projection_norm = np.linalg.norm(projection, axis=1)
    valid = projection_norm > eps
    target = reference_axes.copy()
    target[valid] = projection[valid] / projection_norm[valid, None]
    cosine = np.einsum("ij,ij->i", reference_axes, target)
    target[cosine < 0] *= -1
    cosine = np.clip(np.einsum("ij,ij->i", reference_axes, target), 0.0, 1.0)
    signed_sine = np.einsum("ij,ij->i", sightlines, np.cross(reference_axes, target))
    angle = np.arctan2(np.abs(signed_sine), cosine)
    rotation = np.where(signed_sine < 0, -1.0, 1.0) * np.minimum(angle, theta)
    result = (
        reference_axes * np.cos(rotation)[:, None]
        + np.cross(sightlines, reference_axes) * np.sin(rotation)[:, None]
    )
    saturated = valid & (angle <= theta)
    result[saturated] = target[saturated]
    result[~valid] = reference_axes[~valid]
    result /= np.linalg.norm(result, axis=1, keepdims=True)
    return result * original_sign[:, None]


def _sigma_array(sigma_pa_rad, n_objects):
    if np.any(np.ma.getmaskarray(sigma_pa_rad)):
        raise ValueError("sigma_pa_rad must not contain masked uncertainties.")
    sigma = np.asarray(sigma_pa_rad, dtype=float)
    if sigma.ndim == 0:
        sigma = np.full(n_objects, float(sigma))
    if sigma.shape != (n_objects,):
        raise ValueError("sigma_pa_rad must be a scalar or an array of length N.")
    if np.any(~np.isfinite(sigma)) or np.any(sigma < 0):
        raise ValueError("sigma_pa_rad must contain finite, nonnegative radians.")
    return sigma.copy()


def add_pa_noise(a, n, sigma_pa_rad, *, rng=None, seed=None):
    """Rotate each tangent axis by an independent zero-mean Gaussian PA error.

    ``sigma_pa_rad`` is a nonnegative scalar or an array of length N; masked
    uncertainties are rejected. Return a new array without mutating inputs.
    The caller must retain these sigma values to supply the estimator's
    weights and PA-attenuation correction.
    """
    axes, sightlines = validate_vectors(a, n)
    random = _generator(rng, seed)
    sigma = _sigma_array(sigma_pa_rad, axes.shape[0])
    error = random.normal(0.0, sigma, size=axes.shape[0])
    result = axes * np.cos(error)[:, None] + np.cross(sightlines, axes) * np.sin(error)[:, None]
    return result / np.linalg.norm(result, axis=1, keepdims=True)


def generate_mock(
    n_objects=10000,
    *,
    direction,
    theta_ia_rad,
    sigma_pa_rad=0.0,
    seed=None,
    rng=None,
    mask=None,
    overdensity=None,
    nside=None,
    nest=True,
    subpixel_factor=256,
):
    """Return a reproducible minimal catalog with a known injected signal.

    Output keys are ``a``, ``n``, ``sigma_pa`` and ``metadata``. ``sigma_pa`` is
    an N-array in radians when any PA noise is applied, or ``None`` for a
    truly noiseless mock. For the latter, estimate with explicit uniform
    weights and C-bar = 1 rather than inventing an uncertainty. Positions,
    initial PAs and errors all use the same random generator. Optional mask
    and overdensity maps follow :func:`sample_positions` conventions.

    The output is not a DES emulator or a cosmological null ensemble. The
    injected amplitude is a user-chosen demonstration parameter, not a
    published measurement or significance.
    """
    count = _positive_integer(n_objects, "n_objects")
    random = _generator(rng, seed)
    n = sample_positions(
        count,
        mask=mask,
        overdensity=overdensity,
        nside=nside,
        nest=nest,
        subpixel_factor=subpixel_factor,
        rng=random,
    )
    a = _random_orientations(n, random)
    a = inject_alignment(a, n, direction, theta_ia_rad)
    sigma = _sigma_array(sigma_pa_rad, count)
    if np.any(sigma > 0):
        a = add_pa_noise(a, n, sigma, rng=random)
        sigma_output = sigma
    else:
        sigma_output = None
    metadata = {
        "model": "minimal_saturated_axial_injection",
        "n_objects": count,
        "direction": canonical_axis(direction).tolist(),
        "theta_ia_rad": float(theta_ia_rad),
        "seed": int(seed) if isinstance(seed, (int, np.integer)) else None,
        "bit_generator": type(random.bit_generator).__name__,
        "position_sampling": "uniform_solid_angle"
        if mask is None and overdensity is None
        else "equal_area_subpixel_centers",
        "has_pa_noise": sigma_output is not None,
        "map_ordering": "NESTED" if nest else "RING",
        "subpixel_factor": int(subpixel_factor),
    }
    return {"a": a, "n": n, "sigma_pa": sigma_output, "metadata": metadata}
