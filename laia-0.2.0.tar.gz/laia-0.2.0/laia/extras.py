"""Optional complex-field diagnostics and estimator-map PSF projections.

The complex-field amplitude is not the paper's ``theta_IA``.  The real PSF
projection implements the *map-level* algebra, not the catalogue-level
residualisation, empirical-null construction, or complete survey pipeline.
"""

from __future__ import annotations

from collections.abc import Mapping

import healpy as hp
import numpy as np

from .geometry import canonical_axis, vector_to_radec


def _map_array(values, *, complex_values=False):
    """Copy map data and retain masked, non-finite and HEALPix-bad pixels."""
    masked = np.ma.asarray(values)
    dtype = np.complex128 if complex_values else np.float64
    if not complex_values and np.iscomplexobj(masked):
        raise ValueError("A real estimator map was required.")
    array = np.asarray(np.ma.getdata(masked), dtype=dtype)
    if array.ndim != 1 or array.size == 0:
        raise ValueError("Maps must be nonempty one-dimensional arrays.")
    valid = ~np.ma.getmaskarray(masked) & np.isfinite(array)
    valid &= ~hp.mask_bad(array.real)
    if complex_values:
        valid &= ~hp.mask_bad(array.imag)
    return array.copy(), valid


def _common_maps(*maps, valid_mask=None, complex_values=False):
    arrays = []
    mask = None
    for values in maps:
        array, valid = _map_array(values, complex_values=complex_values)
        if arrays and array.shape != arrays[0].shape:
            raise ValueError("All maps must have the same shape and ordering.")
        arrays.append(array)
        mask = valid if mask is None else mask & valid
    if valid_mask is not None:
        explicit = np.asarray(valid_mask)
        if explicit.shape != mask.shape or explicit.dtype.kind != "b":
            raise ValueError("valid_mask must be a boolean array matching the maps.")
        mask &= explicit
    if not np.any(mask):
        raise ValueError("The maps have no common valid pixels.")
    return arrays, mask


def complex_field(Ea, Eb, Eab, *, valid_mask=None):
    r"""Return the extra diagnostic field ``(Ea - Eb) + 1j * Eab``.

    All input maps must use the same grid, ordering, sample and weights.
    Invalid pixels are returned as complex NaNs.  A zero value is valid and
    is never used to infer a mask.  This function does not find the paper's
    preferred axis: that is obtained by maximizing the selected real map.
    """
    (a, b, cross), mask = _common_maps(Ea, Eb, Eab, valid_mask=valid_mask)
    result = np.full(a.shape, complex(np.nan, np.nan))
    result[mask] = (a[mask] - b[mask]) + 1j * cross[mask]
    return result


def complex_diagnostic(maps, *, valid_mask=None):
    r"""Find the axial maximum of the modulus of the optional complex field.

    Parameters
    ----------
    maps : mapping
        Normally the result of :func:`laia.estimator.compute_maps`, containing
        ``Ea``, ``Eb``, ``Eab``, ``c_bar``, ``nside`` and ``nest``.  Alternatively,
        supply ``complex_map`` and the same metadata, for example after an
        explicit complex-template projection.
    valid_mask : array-like of bool, optional
        Additional mask, intersected with ``maps['valid_mask']`` if present.

    Returns
    -------
    dict
        The canonical axial direction, selected pixel, complex value at the
        peak, its modulus, and ``A_complex = modulus_peak / c_bar``.  This
        dimensionless extra amplitude is **not** ``theta_IA`` and is not a
        detection significance.  The original peak pixel can be the antipode
        of the returned canonical direction.
    """
    if not isinstance(maps, Mapping):
        raise TypeError("maps must be a mapping of fields and metadata.")
    supplied_mask = maps.get("valid_mask")
    if valid_mask is not None:
        explicit = np.asarray(valid_mask)
        if explicit.dtype.kind != "b":
            raise ValueError("valid_mask must be boolean.")
        if supplied_mask is not None:
            original = np.asarray(supplied_mask)
            if original.shape != explicit.shape or original.dtype.kind != "b":
                raise ValueError("Both valid masks must have matching shapes.")
            supplied_mask = original & explicit
        else:
            supplied_mask = explicit

    if "complex_map" in maps:
        (field,), mask = _common_maps(
            maps["complex_map"], valid_mask=supplied_mask, complex_values=True
        )
    else:
        field = complex_field(maps["Ea"], maps["Eb"], maps["Eab"], valid_mask=supplied_mask)
        (field,), mask = _common_maps(field, complex_values=True)

    inferred_nside = hp.npix2nside(field.size)
    nside = maps.get("nside", inferred_nside)
    if isinstance(nside, (bool, np.bool_)) or int(nside) != nside:
        raise ValueError("nside must be an integer.")
    nside = int(nside)
    if nside != inferred_nside:
        raise ValueError("nside does not match the map length.")
    nest = maps.get("nest", True)
    if not isinstance(nest, (bool, np.bool_)):
        raise ValueError("nest must explicitly be True or False.")
    if not hp.isnsideok(nside, nest=bool(nest)):
        raise ValueError("Invalid nside for the requested HEALPix ordering.")
    c_bar = float(maps["c_bar"])
    if not np.isfinite(c_bar) or not 0 < c_bar <= 1:
        raise ValueError("c_bar must be finite and satisfy 0 < c_bar <= 1.")

    pixel = int(np.argmax(np.where(mask, np.abs(field), -np.inf)))
    axis = canonical_axis(np.asarray(hp.pix2vec(nside, pixel, nest=bool(nest))))
    ra_deg, dec_deg = vector_to_radec(axis)
    peak = complex(field[pixel])
    return {
        "axis": axis,
        "ra_deg": float(ra_deg),
        "dec_deg": float(dec_deg),
        "pixel": pixel,
        "complex_peak": peak,
        "modulus_peak": float(abs(peak)),
        "A_complex": float(abs(peak) / c_bar),
        "c_bar": c_bar,
        "nside": nside,
        "nest": bool(nest),
        "valid_mask": mask,
        "complex_map": field,
    }


def _project_template(y, x, mask):
    """Centered least squares without replacing zero variance by an epsilon."""
    if np.count_nonzero(mask) < 2:
        raise ValueError("Template projection requires at least two valid directions.")
    yy, xx = y[mask], x[mask]
    mean_y, mean_x = yy.mean(), xx.mean()
    yc, xc = yy - mean_y, xx - mean_x
    denominator = float(np.vdot(xc, xc).real)
    if not np.isfinite(denominator):
        raise ValueError("Template variance overflowed; check the map values.")
    # A constant array can have a tiny nonzero centered value due to rounding.
    # Detect the constant input explicitly, not by an arbitrary variance floor.
    constant = bool(np.all(xx == xx[0])) or denominator == 0.0
    eta = 0j if np.iscomplexobj(y) else 0.0
    if not constant:
        eta = np.vdot(xc, yc) / denominator
        if not np.iscomplexobj(y):
            eta = float(np.real(eta))
    residual = yc - eta * xc
    if not np.all(np.isfinite(residual)) or not np.isfinite(eta):
        raise ValueError("Template projection produced non-finite values.")
    corrected = np.full(y.shape, np.nan, dtype=y.dtype)
    corrected[mask] = residual
    return {
        "corrected_map": corrected,
        "eta": eta,
        "valid_mask": mask,
        "centered": True,
        "template_variance": 0.0 if constant else denominator / yy.size,
        "template_mean": mean_x.item(),
        "input_mean": mean_y.item(),
        "n_directions": int(yy.size),
        "fit_applied": not constant,
        "status": "constant_template" if constant else "ok",
    }


def project_psf_map(observed, psf, *, null_mean=None, centered=False, valid_mask=None):
    r"""Subtract a supplied null base level and project out a real PSF template.

    ``centered=False`` means that *all* input maps are raw estimator maps with
    isotropic reference ``1/2``.  ``centered=True`` means that *all* inputs
    already represent contrasts above that reference.  ``null_mean`` is an
    optional mean null map, not an ensemble, and must follow the same convention.

    Over the common valid directions, form ``y = E_obs - E_null`` (or the
    observed contrast if no null map is provided), subtract the grid means of
    ``y`` and the PSF template ``x``, and return ``y_centered - eta*x_centered``
    with ``eta = cov(y, x)/var(x)``.  Output is always a **centered contrast**:
    use ``measurement_from_map(..., centered=True)`` for amplitude inversion.

    A constant template is explicitly reported with ``fit_applied=False`` and
    ``eta=0``; no division by an arbitrary small variance is performed.
    NaN, masked and ``healpy.UNSEEN`` pixels are excluded; zeros remain valid.
    The caller is responsible for a common grid/ordering and matching samples.

    This helper implements only the paper's estimator-level projection.  It
    does not perform catalogue-level residualisation, create empirical nulls,
    or establish that an arbitrary PSF correction is unbiased for a survey.
    """
    if not isinstance(centered, (bool, np.bool_)):
        raise ValueError("centered must explicitly be True or False.")
    inputs = [observed, psf] if null_mean is None else [observed, psf, null_mean]
    arrays, mask = _common_maps(*inputs, valid_mask=valid_mask)
    offset = 0.0 if centered else 0.5
    y, x = arrays[0] - offset, arrays[1] - offset
    if null_mean is not None:
        y = y - (arrays[2] - offset)
    result = _project_template(y, x, mask)
    result["null_subtracted"] = null_mean is not None
    result["input_centered"] = bool(centered)
    return result


def project_complex_psf(observed, psf, *, null_mean=None, valid_mask=None):
    r"""Optional centered complex projection using conjugate least squares.

    Inputs are complex fields, for example ``(Ea-Eb) + 1j*Eab``, whose reference
    is already zero.  After any supplied complex mean-null subtraction and
    removal of grid means, ``eta = vdot(x, y) / vdot(x, x)``.  The returned
    contrast is a diagnostic field; its modulus is not the paper's real-map
    peak or ``theta_IA``.  No real-map ``1/2`` baseline is added or subtracted.
    """
    inputs = [observed, psf] if null_mean is None else [observed, psf, null_mean]
    arrays, mask = _common_maps(*inputs, valid_mask=valid_mask, complex_values=True)
    y, x = arrays[0], arrays[1]
    if null_mean is not None:
        y = y - arrays[2]
    result = _project_template(y, x, mask)
    result["null_subtracted"] = null_mean is not None
    return result
